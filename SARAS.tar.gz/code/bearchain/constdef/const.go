package constdef

const (
// log
INFO=0
DEBUG=1

// data channel size
Dc_Size=2000
// error channel size
Ec_Size=1000


// consensus type
POW="POW"
POS="POS"
LLFC="LLFC" //work1 
LFC="LFC"  //work2
OFC="OFC" //work3

// consensus message
//VRF
Block_Selected_Broadcast=0

// block-chosed message
Block_Chosed=0
// block_qeury 
Block_Query=1
// block_question
Block_Question=2

// gossip node state
Alive = "Alive"
Suspect = "Suspect"
Dead = "Dead"

All = "All"
AllAlive = "AllAlive"
Part = "Part"
PartAlive = "PartAlive"

MILLS="MILLS"
SECOND="SECOND"
MINITUE="MINITUE"

//contract execute flag
CLIENT="CLIENT"
NODEP="NODEP"
DEP="DEP"

// Gossip Message type
TX="TX" //client Tx
NEWPROPOSER="NEWPROPOSER" //client Tx
NEWINTRA="NEWINTRA" //broadcast a new intra block
CONSENSUS="CONSENSUS" //broadcast a consensus block
IBLOCK="IBLOCK"
BLOCK="BLOCK"
MISSBLOCK="MISSBLOCK" //broadcast missing a block
MILICIOUS="MILICIOUS" //malicious node create two blok

// Consensus Message
NEWINTRAC="NEWINTRAC"
QUERY="QUERY" //query a block 
RESPONE="RESPONE" // respone to a block query
ACK="ACK"   // 
NOACK="NOACK" //
)
