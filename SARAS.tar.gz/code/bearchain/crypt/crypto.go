package crypt

//
//type config struct{
//    hash_lever string
//    crypto_level string
//    crypto_algo string
//}
//
//
//func Generate(conf *config) (*Crypto, error){
////    if conf.crypto_algo=="ecdas"{
////        ecd,err := EcdsaGenerate()
////        if err!=nil {
////            return ecd,nil
////        }
////        return nil, err
////    }
//    return nil,nil
//}
//
//var localCrypto *Crypto
//
//
//func InitlocalCrypto(conf *config) (*Crypto,error) {
//    localCrypto,err:=Generate(conf)
//    return localCrypto,err
//}
