package crypt

import (
	"bufio"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"io/ioutil"
	"os"
)

func EncodeSk(privateKey *ecdsa.PrivateKey) string {
	x509Encoded, _ := x509.MarshalECPrivateKey(privateKey)
	pemEncoded := pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: x509Encoded})
	return string(pemEncoded)
}

func EncodePk(publicKey *ecdsa.PublicKey) string {
	x509EncodedPub, _ := x509.MarshalPKIXPublicKey(publicKey)
	pemEncodedPub := pem.EncodeToMemory(&pem.Block{Type: "PUBLIC KEY", Bytes: x509EncodedPub})
	return string(pemEncodedPub)
}

func DecodeSk(pemEncoded string) *ecdsa.PrivateKey {
	block, _ := pem.Decode([]byte(pemEncoded))
	x509Encoded := block.Bytes
	privateKey, _ := x509.ParseECPrivateKey(x509Encoded)
	return privateKey
}

func DecodePk(pemEncodedPub string) *ecdsa.PublicKey {
	blockPub, _ := pem.Decode([]byte(pemEncodedPub))
	x509EncodedPub := blockPub.Bytes
	genericPublicKey, _ := x509.ParsePKIXPublicKey(x509EncodedPub)
	publicKey := genericPublicKey.(*ecdsa.PublicKey)

	return publicKey
}

func SaveKey(skpath string, pkpath string, privateKey *ecdsa.PrivateKey, publicKey *ecdsa.PublicKey) {
	sk := EncodeSk(privateKey)
	pk := EncodePk(publicKey)
	file1, err := os.OpenFile(skpath, os.O_WRONLY|os.O_CREATE, 0666)
	if err != nil {
		fmt.Println("文件打开失败", err)
	}
	defer file1.Close()

	//写入文件时，使用带缓存的 *Writer
	write1 := bufio.NewWriter(file1)
	write1.WriteString(sk)
	//	for i := 0; i < 5; i++ {
	//		write1.WriteString(sk)
	//	}
	write1.Flush()

	file2, err := os.OpenFile(pkpath, os.O_WRONLY|os.O_CREATE, 0666)
	if err != nil {
		fmt.Println("文件打开失败", err)
	}
	defer file2.Close()

	//写入文件时，使用带缓存的 *Writer
	write2 := bufio.NewWriter(file2)
	write2.WriteString(pk)
	//	for i := 0; i < 5; i++ {
	//		write2.WriteString(pk)
	//	}
	write2.Flush()
}

//func LoadKey(skpath string, pkpath string) (*ecdsa.PrivateKey, *ecdsa.PublicKey, error){
func LoadKey(skpath string, pkpath string, errchan chan<- error) (string, string) {
	//file, err := os.Open(skpath)
	s, err := os.ReadFile(skpath)
	if err != nil {
		fmt.Fprintf(os.Stdout,"Error: fail to read the sk at %s,detail: %v\n", skpath, err)
		//e := fmt.Errorf("Error: fail to read the sk at %s,detail: %v\n", skpath, err)
		//errchan <- e
		return "", ""
	}
//	defer file.Close()
//	fileread := bufio.NewReader(file)
	p, err := ioutil.ReadFile(pkpath)
	if err != nil {
		fmt.Fprintf(os.Stdout,"Error: fail to read the pk at %s,detail: %v\n", pkpath, err)
		//e := fmt.Errorf("Error: fail to read the pk at %s,detail: %v\n", pkpath, err)
		//errchan <- e
		return "", ""
	}
	return string(s), string(p)
}

type EcdsaKey struct {
	sk *ecdsa.PrivateKey
	pk *ecdsa.PublicKey
}

func (e *EcdsaKey) GetSk() *ecdsa.PrivateKey {
	return e.sk
}

func (e *EcdsaKey) GetPk() *ecdsa.PublicKey {
	return e.pk
}

var localEcdsa *EcdsaKey

func Init(skpath string, pkpath string, errchan chan<- error) *EcdsaKey {
	localEcdsa = new(EcdsaKey)
	_, err := os.Stat(skpath)
	if os.IsNotExist(err) {
		//err := fmt.Errorf("Warning: Missing PrivateKey at %v, generate new sk,pk at %v,%v\n", skpath, skpath, pkpath)
		fmt.Fprintf(os.Stdout,"Warning: Missing PrivateKey at %v, generate new sk,pk at %v,%v\n", skpath, skpath, pkpath)
	//	errchan <- err
		sk, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
		pk := sk.PublicKey
		localEcdsa.sk = sk
		localEcdsa.pk = &pk
		SaveKey(skpath, pkpath, sk, &pk)
	}
	sk, pk := LoadKey(skpath, pkpath, errchan)
	//sk, pk, err := LoadKey(skpath, pkpath, errchan)
	if err != nil {
		e := fmt.Errorf("Error: LoadKey, para %s, %s\n", skpath, pkpath)
		errchan <- e
		return nil
	}
	s := DecodeSk(sk)
	p := DecodePk(pk)
	localEcdsa.sk = s
	localEcdsa.pk = p
	return localEcdsa
}

func New(skpath string, pkpath string) *EcdsaKey {
    key := new(EcdsaKey)
	_, err := os.Stat(skpath)
	if os.IsNotExist(err) {
		//err := fmt.Errorf("Warning: Missing PrivateKey at %v, generate new sk,pk at %v,%v\n", skpath, skpath, pkpath)
		fmt.Fprintf(os.Stdout,"Warning: Missing PrivateKey at %v, generate new sk,pk at %v,%v\n", skpath, skpath, pkpath)
	//	errchan <- err
		sk, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
		pk := sk.PublicKey
		key.sk = sk
		key.pk = &pk
		SaveKey(skpath, pkpath, sk, &pk)
	}
	sk, pk := LoadKey(skpath, pkpath,nil)
	//sk, pk, err := LoadKey(skpath, pkpath, errchan)
	if err != nil {
		fmt.Fprintf(os.Stdout,"Error: LoadKey, para %s, %s\n", skpath, pkpath)
		//e := fmt.Errorf("Error: LoadKey, para %s, %s\n", skpath, pkpath)
		//errchan <- e
		return nil
	}
	s := DecodeSk(sk)
	p := DecodePk(pk)
	key.sk = s
	key.pk = p
	return key
}


//func EcdsaGenerate() (*Ecdsa,error){
//    var ecd *Ecdsa
//    ecd=new(Ecdsa)
//    return ecd,nil
//}

//func (ecd *Ecdsa) Print(){
//    fmt.Printf("ecdsa point %p\n", ecd)
//    fmt.Printf("priv key point: %p\n", ecd.priv)
//    fmt.Printf("priv key value: %+v\n", *ecd.priv)
//}

func GenerateKey() (sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
	// to be completed.
	sk, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		fmt.Println("error when load key")
		return nil, nil
	}
	pk = &sk.PublicKey
	return sk, pk
}

func Hash(data []byte) ([]byte, error) {
	hash := sha256.Sum256(data)
	return hash[:], nil
}

func Sign(sk *ecdsa.PrivateKey, hash []byte) ([]byte, error) {
	sig, err := ecdsa.SignASN1(rand.Reader, sk, hash)
	if err != nil {
		fmt.Printf("Error when Sign with ecdsa")
		return nil, err
	}
	return sig, nil
}

func Verify(pk *ecdsa.PublicKey, hash []byte, sig []byte) (bool, error) {
	valid := ecdsa.VerifyASN1(pk, hash, sig)
	return valid, nil
}
