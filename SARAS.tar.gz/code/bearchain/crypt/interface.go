package crypt

//type Crypto interface{
//    Hash([]byte) ([]byte, error)
//    Sign([]byte) ([]byte, error)
//    Verify(hash []byte, sig []byte) (bool, error)
//}
