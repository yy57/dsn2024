package errorp

import (
	"fmt"
	"os"
)

type Err struct {
	err chan error
}

var localErr *Err

func Init() {
	localErr = new(Err)
}

func (e *Err) Serve() {
	for {
		err := <-e.err
		fmt.Fprintf(os.Stdout, "(Error)\t %v\n", err)
	}
}

func NewErr(err chan error) *Err {
	localErr = new(Err)
	localErr.err = err
	return localErr
}

func GetErr() *Err {
	return localErr
}

func GetErrChan() chan error {
	return localErr.err
}
