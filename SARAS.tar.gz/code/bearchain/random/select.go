package random

import (
	"math"
	"math/big"
)

func factorial(n int64) int64 {
	var f int64
	f = 1
	var i int64
	i = 1
	for i = 1; i <= n; i++ {
		if f == 0 {
			panic("Error")
		}
		f = f * i
	}
	return f
}

func binomial(k int64, n int64, p float64) float64 {
	fn := float64(factorial(n))
	fk := float64(factorial(k))
	fn_k := float64(factorial(n - k))
	result := fn / fk / fn_k * float64(math.Pow(p, float64(k))) * float64(math.Pow(1-p, float64(n-k)))
	return result
}

func interval(k int64, weight int64, p float64) (float64, float64) {
	lbn := k
	upk := k + 1
	lb := float64(0)
	if lbn < 0 {
		lb = 0
	} else {
		var i int64
		for i = 0; i <= lbn; i++ {
			lb = lb + binomial(i, weight, p)
		}
	}
	ub := float64(0)
	var i int64
	for i = 0; i <= upk; i++ {
		ub = ub + binomial(i, weight, p)
	}
	return lb, ub
}

// hash: random num
// tau: choose probability
// weight: node weight
func Select(hash []byte, tau float64, weight int) bool {
    bits:=hash[:8]
    //bits:=hash[:16]
    data := uint64(big.NewInt(0).SetBytes(bits).Uint64())

    //fmt.Printf("data: %v\n",float64(data))
	//data:=binary.BigEndian.Uint64(hash)
	l := len(bits)
	scale := float64(float64(data) / math.Pow(float64(2), float64(8*l)))
	//	j := -1
	//lb := binomial(0, int64(weight), tau)
    lb:=1-tau*float64(weight)
	if scale <= lb {
		return false
	}
	return true
}
