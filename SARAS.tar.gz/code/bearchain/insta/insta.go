package insta

import (
	"bearchain/config"
	"bearchain/consensus"
	"bearchain/contract"
	"bearchain/crypt"
	"bearchain/gossip"
	"bearchain/ledger"
	"bearchain/ledgercache"
	"crypto/ecdsa"
	"fmt"
	"math/rand"
	"net"
	"os"
	"strconv"
	"time"
)


type Node struct {
    sk *ecdsa.PrivateKey
    pk *ecdsa.PublicKey
    l *ledger.Ledger
    g *gossip.GossipImp
    consensus *consensus.MyConsensus
    contract *contract.Contract
}
   
func (n *Node)SetMalicious() {
    n.consensus.SetMalicious()
}

func (n *Node)SetGossipLatency(ltype string,latency int) {
    n.g.SetLatency(ltype,latency)
}

func (n *Node)SetTcpMsg(msg chan gossip.MessageImp, flag bool) {
    n.g.SetUpstream(msg,flag)
}

func (n *Node)SetType(s string) {
    n.consensus.SetType(s)
}

func (n *Node)SetStakeScale(l int) {
    n.consensus.SetLength(l)
}

//func (ins *Insta)SetNodeNum(tao int,total int, taonode int, weight int)
func (n *Node)SetNodeNum(total int, expect int, nextRound int, weight int) {
    n.consensus.SetNodeNum(total,expect,nextRound,weight)
}

func (n *Node)SetWeight(weight int) {
    n.consensus.SetWeight(weight)
}

func (n *Node)SetProb(thres float64,thresack int, thresprob float64) {
    n.consensus.SetProb(thres,thresack,thresprob)
}

//
func (n *Node)SetExpectProposer(i int) {
    n.consensus.SetExpectProposer(i)
}

func (n *Node)SetExpectCommittee(i int) {
    n.consensus.SetExpectCommittee(i)
}

func (n *Node)SetAlgorandlatency(ltype string,latency int) {
    n.consensus.SetAlgorandlatency(ltype,latency)
}

func (n *Node)SetAlgorandWaitingtime(ltype string,latency int) {
    n.consensus.SetAlgorandWaitingtime(ltype,latency)
}

func (n *Node)SetConsensusLatency(ltype string,latency int) {
    //n.consensus.SetProb(thres,thresack,thresprob)
    n.consensus.SetKnownLatency(ltype,latency)
}

//laska
func (n *Node)Setlaska(q int, fenweidian map[int][]float64, selection [][]int) {
    //n.consensus.SetProb(thres,thresack,thresprob)
    n.consensus.Setlaska(q, fenweidian,selection)
}


// Create config
// Create consensus Config
func GenerateConsensus(boot bool,thresh float32,threshack int, thresprob float64, interval int, maxsize int, maxnum int) *config.ConsensusConfig {
    config:=new(config.ConsensusConfig)
    config.Bootstrap=boot
    config.Thresh=thresh
    config.Threshack=threshack
    config.ThresProb=thresprob
    config.Condition.Interval=interval
    config.Condition.Maxsize=maxsize
    config.Condition.Maxnum=maxnum
    return config
}

// Create VRF config
func GenerateVRF(tao int, taonode int, weight int, total int) *config.VRF{
    config:=new(config.VRF)
    config.Tao=tao
    config.Taonode=taonode
    config.Weight=weight
    config.Total=total
    return config
}

// Create gossip channel
func CreateCommChannel(num int) []chan gossip.MessageImp{
    chanlist:=make([]chan gossip.MessageImp, num)
    for i:=0;i<num;i++ {
	    chanlist[i]= make(chan gossip.MessageImp, 4096)
    }
    return chanlist
}

func NewNode(index string, Cconfig *config.ConsensusConfig, vconfig *config.VRF) *Node {
    node:=new(Node)
    // set sk pk
    node.sk,node.pk=crypt.GenerateKey()


    // set gossip
	consensus_to_gossip := make(chan *gossip.MessageImp, 4096)
	gossip_to_consensus := make(chan *gossip.MessageImp, 4096)
	//resend:= make(chan *gossip.MessageImp, 4096)
    node.g=gossip.NewGossip()
    // set node config
    // useless
	//err = gsp.Set(nodeconf.GetGossipConfig())
    // use!
    node.g.Setchan(consensus_to_gossip, gossip_to_consensus,nil)
	//gsp.Setchan(consensus_to_gossip, gossip_to_consensus, resend)
    // useless
	//addr1 := nodeconf.GetGossipUdpAddr()
    // useless
	//addr2 := nodeconf.GetGossipTcpAddr()
    //TBC
	//go gsp.Serve()

    // set ledger
	// init Ledger server for data update
	//ledgerconf := nodeconf.GetLedgerConfig()
	//err = ledger.InitLedger(ledgerconf)
    ledgerconf:=new(config.LedgerConfig)
    ledgerconf.Filepath=index
    ledgerconf.Size=200
    ledger,err:=ledger.NewLedger(ledgerconf)
    if err !=nil {
        fmt.Fprintf(os.Stdout," Node %v | Error | When init Ledger, info: %v\n",index, err)
    }
    node.l=ledger
	//defer ledger.Close()

    // set cache ledger
	cacheledger := ledgercache.New()
	cacheledger.SetLedger(ledger)

    // set contract
	// init contract server
	//contract.InitContract()
    sc:=contract.NewContract()
	//contract.SetLedgerHandler(ledger)
	sc.SetLedgerHandler(ledger)
	sc.SetCacheLedgerHandler(cacheledger)
    node.contract=sc

    // set  consensus
	// init consensus server
	c := consensus.New()
	c.SetConsensus(Cconfig)
	c.SetRecvchan(gossip_to_consensus)
	c.SetSendchan(consensus_to_gossip)
	c.SetContract(sc)
	c.SetLedger(ledger)
	c.SetCacheLedger(cacheledger)
	c.SetVRF(vconfig.GetTao(),vconfig.GetTaoNode(),vconfig.GetWeight())
    c.RecvMsg2active=true
    c.Index=index
    node.consensus=c
    return node
}

//TBC
func SetComm(nodes []*Node,chanlist []chan gossip.MessageImp){
    for i,node:=range nodes{
        node.g.Comm.Recvchan=chanlist[i]
        node.consensus.SetRecvchan2(chanlist[i])

        node.g.Comm.Index=i
        node.g.Comm.SendChan=chanlist
    }
}

func (n *Node)Start(){
    //fmt.Fprintf(os.Stdout,"Node start\n")
	defer n.l.Close()
	go n.g.Serve()
    go n.consensus.Serve(n.sk,n.pk)
    for {
		time.Sleep(100 * time.Second)
    }
}



func GenerateNode(num int,indexbias int) []*Node {
//func GenerateConsensus(boot bool,thresh float32,threshack int, thresprob float64, interval int, maxsize int, maxnum int) *config.ConsensusConfig {
    // boot bool : if the bootstrap node
    // thresh : ratio of ack in total respone
    //  
    Cconfig:=GenerateConsensus(false,0.5,1,0.0001,3,1,500)
    //Cconfig:=GenerateConsensus(false,0.5,50,0.0001,3,1,500)
    VRFconfig:=GenerateVRF(num,num,1,num)
    channellist:=CreateCommChannel(num)
    nodes:=make([]*Node,num)
    for i:=0;i<num;i++ {
        nodes[i]=NewNode(strconv.Itoa(i+indexbias),Cconfig,VRFconfig)
    }
    SetComm(nodes,channellist)
    return nodes
}

//func Start(num int) {
//    nodes:=GenerateNode(num)
//    for i:=1;i<num;i++ {
//        go nodes[i].Start()
//    } 
//
//    timer:=time.NewTimer(3*time.Second) 
//    <-timer.C
//    nodes[0].consensus.SetBootStrap(true)
//    go nodes[0].Start()
//
//    tricker:=time.NewTicker(3*time.Second)
//    for {
//        select {
//        case <-tricker.C:
//            //nothing to do
//        }
//    }
//}


type Insta struct {
    ttype string 
    //consensus type
    // my 
    // algorand

    maliciousNum int

    nodes []*Node
    hasboot bool
    // gossip latency
    ltype string
    latency int

    //  consensus latency
    cltype string
    clatency int

    // Random Selection
    total int
    expect int
    weight int
    nextRount int
    stakelength int

    weightlist []int
    weightlistl int

    thres float64
    threshack int
    thresprob float64

    tcp net.Listener 
    addr  string
    nodelist  []string
    msgstream chan gossip.MessageImp
    isMulti bool


    indexbias int

    //algorand
    expectproposer int
    expectCommittee int
    algorandlatencytype string
    algorandlatency int
    algorandwaitingtype string
    algorandwaiting int


    // LaSKA setting
    q int
    expectedRound int
    fenweidian map[int][]float64
    //fenweidian []float64
}

func (ins *Insta)SetIndexBias(indexbias int){
    ins.indexbias=indexbias
}

func (ins *Insta)HashBoot(flag bool){
    ins.hasboot=flag
}

func (ins *Insta)SetStakeScale(l int) {
    ins.stakelength=l
}


func (ins *Insta)SetWeightBatch(weightlist []int, n int){
    ins.weightlist=weightlist
    ins.weightlistl=n
    //for k,v:=range ins.nodes{
    //    i:=k % n
    //    v.SetWeight(weightlist[i])
    //}
}

//func (ins *Insta)SetTcpMsg(size int, flag bool) {
//    if flag==true {
//        ins.msgstream=make(chan gossip.MessageImp,size)
//    }
//}

// Set network(gossip) latency
func (ins *Insta)SetLatency(ltype string, latency int) {
    ins.ltype=ltype
    ins.latency=latency
}

// Set Consensus known network latency
func (ins *Insta)SetConsensusLatency(cltype string, clatency int) {
    ins.cltype=cltype
    ins.clatency=clatency
}

// Set node num and weight
func (ins *Insta)SetNodeNum(total int, expect int, nextRound int, weight int){
    ins.total=total
    ins.expect =expect
    ins.weight=weight
    ins.nextRount=nextRound
}

func (ins *Insta)SetProb(thres float64, thresack int,thresprob float64){
    //ins.Node.consensus.SetProb(ins.thres,ins.threshack,ins.thresprob)
    ins.thres=thres
    ins.threshack=thresack
    ins.thresprob=thresprob
}

func (ins *Insta)SetType(s string){
    ins.ttype=s
}

func (ins *Insta)SetMaliciousNum(n int) {
    ins.maliciousNum=n
}

//algorand
func (ins *Insta)SetExpectProposer(i int) {
    ins.expectproposer=i
}

func (ins *Insta)SetExpectCommittee(i int) {
    ins.expectCommittee=i
}

func (ins *Insta)SetAlgorandlatency(cltype string, clatency int) {
    ins.algorandlatencytype=cltype
    ins.algorandlatency=clatency
}

func (ins *Insta)SetAlgorandWaitingtime(cltype string, clatency int) {
    ins.algorandwaitingtype=cltype
    ins.algorandwaiting=clatency
}


// laska
func (ins *Insta)SetLaSKA(q int, expectedRound int) {
    ins.q=q
    ins.expectedRound=expectedRound
    ins.fenweidian=make(map[int][]float64)
}

func (ins *Insta)SetFenweidian(k int, fenweidian []float64){
    ins.fenweidian[k]=fenweidian
}

func Shuffle(num int) []int {
    list:=make([]int, num)
    for i:=0;i<num;i++{
        list[i]=i
    }
    rand.Shuffle(len(list),func(i,j int){
        list[i],list[j]=list[j],list[i]
    })
    fmt.Printf("list: %v\n",list)                                                                                                                                   
    return list
}

func  Randomselection(num int, top int, times int) [][]int{
    ret:=[][]int{}
    for i:=0;i<times;i++ {
        l:=Shuffle(num)
        ret=append(ret, l[0:top])
    }
    return ret
}
 
func (ins *Insta)Start(num int) {
    //ins.msgstream=make(chan gossip.MessageImp,10240)
    //msgstream chan gossip.MessageImp
    if ins.isMulti {
        ins.msgstream=make(chan gossip.MessageImp,10240)
        ins.SetTCPServer()
        go ins.TcpServe()
    }

    var selection [][]int
    if ins.ttype=="laska" {
        selection=Randomselection(ins.total,ins.q,2000)
    }

    nodes:=GenerateNode(num,ins.indexbias)
    //go sendTx(nodes)
    ins.nodes=nodes
    if ins.maliciousNum!=0 {
        for i:=0;i<ins.maliciousNum;i++ {
            nodes[i+1].SetMalicious()
        }
    }
    for i:=0;i<num;i++ {
        nodes[i].SetType(ins.ttype)
        if ins.ttype=="algorand" {
            nodes[i].SetExpectProposer(ins.expectproposer)
            nodes[i].SetExpectCommittee(ins.expectCommittee)
            nodes[i].SetAlgorandlatency(ins.algorandlatencytype,ins.algorandlatency)
            nodes[i].SetAlgorandWaitingtime(ins.algorandwaitingtype,ins.algorandwaiting)
        }
        if ins.ttype=="laska" {
            nodes[i].Setlaska(ins.q,ins.fenweidian,selection)
        }
        nodes[i].SetGossipLatency(ins.ltype,ins.latency)
        if ins.isMulti {
            nodes[i].SetTcpMsg(ins.msgstream,ins.isMulti)
        } else {
            nodes[i].SetTcpMsg(nil,false)
        }
        //nodes[i].SetTcpMsg(ins.msgstream,ins.isMulti)
        nodes[i].SetConsensusLatency(ins.cltype,ins.clatency)
        nodes[i].SetProb(ins.thres,ins.threshack,ins.thresprob)
        nodes[i].SetNodeNum(ins.total,ins.expect,ins.nextRount,ins.weight)
        nodes[i].SetStakeScale(ins.stakelength)
    } 
    for k,v:=range ins.nodes{
        i:=k % ins.weightlistl
        v.SetWeight(ins.weightlist[i])
    }
    if ins.hasboot{
        for i:=1;i<num;i++ {
            go nodes[i].Start()
        } 

        timer:=time.NewTimer(3*time.Second) 
        <-timer.C
        nodes[0].consensus.SetBootStrap(true)
        go nodes[0].Start()

        tricker:=time.NewTicker(3*time.Second)
        for {
            select {
            case <-tricker.C:
            //nothing to do
            }
        }
    } else {
        for i:=0;i<num;i++ {
            go nodes[i].Start() 
        }

        tricker:=time.NewTicker(3*time.Second)
        for {
            select {
            case <-tricker.C:
                //nothing to do
            }
        }
    } 
}
