package insta

import (
	"bearchain/client"
	"bearchain/constdef"
	"bearchain/crypt"
	"encoding/json"
	"fmt"
	"os"
	"time"
)

func sendtx(sk string, pk string, sc client.ScInvoke, node *Node){
    //tricker:=time.NewTicker(100*time.Millisecond)
    //<-tricker.C
	tx := client.NewTx(pk,sc.Name, sc.SplitPare())
    err:=tx.Complete(sk)
    if err != nil {
        fmt.Fprintf(os.Stdout," CreatTx | Fait to complete Tx, error: %v\n",err)
	}
	bs, err := json.Marshal(tx)
	if err != nil {
        fmt.Fprintf(os.Stdout," CreatTx | Fait to marshal Tx, error: %v\n",err)
	}
	msg := client.ToMessage(bs, constdef.TX)
    node.g.RecvUpstream(msg)
}

func sendTx(nodes []*Node){

    sk,pk:=crypt.GenerateKey()
    sks:=crypt.EncodeSk(sk)
    pks:=crypt.EncodePk(pk)

    var sc client.ScInvoke
    sc.Name="CreateMotor"
    sc.Para="car1;300ac;green;voge;xh"

    timer:=time.NewTimer(10*time.Second)
    <-timer.C

    tricker:=time.NewTicker(30*time.Second)
    go func([]*Node,string,string,client.ScInvoke) {
        for {
            tricker:=time.NewTicker(100*time.Millisecond)
            <-tricker.C
            for _,v:=range nodes {
                //go sendtx(sks,pks,sc,v)
                sendtx(sks,pks,sc,v)
            }
        }
    }(nodes,sks,pks,sc)//    go func() {
    <-tricker.C
}

