package insta

import (
	"bearchain/gossip"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"os"
	"time"
)

// Recv
func (ins *Insta) processRecv(conn net.Conn) {
	data := make([]byte, 0, 20480)
	defer conn.Close()
	for {
		var msgSize int32
		err := binary.Read(conn, binary.BigEndian, &msgSize)
		if err != nil {
            //fmt.Fprintf(os.Stdout," TCP | Recv | Error when Recving %v\n",err)
			break
		}
        //fmt.Fprintf(os.Stdout," TCP | Recv | Recv data %v from remote %v\n",msgSize,conn.RemoteAddr().String())
		buf := make([]byte, msgSize)
		_, err = io.ReadFull(conn, buf)
		if err != nil {
            //fmt.Fprintf(os.Stdout," TCP | Recv | Error when Recving %v\n",err)
			break
		}
        //fmt.Fprintf(os.Stdout," TCP | Recv | Recv data %v from remote %v\n",buf,conn.RemoteAddr().String())
		//fmt.Printf("recv: %s len %d, remote %v\n", string(buf), len(buf), conn.RemoteAddr())
		data = append(data, buf...)
	}

    var b gossip.MessageImp
    l := len(data)
    err := json.Unmarshal(data[:l], &b)
    if err != nil {
            fmt.Fprintf(os.Stdout, " TCP | Recv unknom Msg\n")
            return
    }
    //fmt.Fprintf(os.Stdout, " TCP | TCP Recv data from remote addr:%v\n", conn.RemoteAddr())
    //TBC
    // push msg to different node insta
    //g.recvchan <- &b
    //var timer *time.Timer
    //switch ins.ltype{
    //case "Mil":
    //    timer=time.NewTimer(time.Duration(ins.latency)*time.Millisecond)
    //case "Sec":
    //    timer=time.NewTimer(time.Duration(ins.latency)*time.Second)
    //case "Min":
    //    timer=time.NewTimer(time.Duration(ins.latency)*time.Minute)
    //}
    //<-timer.C 
    for _,v:=range ins.nodes {
        //fmt.Fprintf(os.Stdout, " Put recv message to  node %d\n", k)
        v.g.RecvUpstream(b)
    }
}

func (ins *Insta) Recv() {
//func (g *GossipImp) Recv(ctx context.Context) {
	//locallog:=log.GetlocalLog()
	for {
		conn, err := ins.tcp.Accept()
		if err != nil {
			//fmt.Errorf("accept failed,err:%v",err)
			fmt.Fprintf(os.Stdout, " ERROR | TCP accept failed,err:%v", err)
			return
		}
		go ins.processRecv(conn)
	}
}

// Send
func (ins *Insta) send(m []byte, d string) {
	var b gossip.MessageImp
    var err error
    var timer *time.Timer
    switch ins.ltype{
    case "Mil":
        timer=time.NewTimer(time.Duration(ins.latency)*time.Millisecond)
    case "Sec":
        timer=time.NewTimer(time.Duration(ins.latency)*time.Second)
    case "Min":
        timer=time.NewTimer(time.Duration(ins.latency)*time.Minute)
    }
    <-timer.C 
    err = json.Unmarshal(m, &b)
    conn, err :=net.Dial("tcp",d)
    if err!=nil {
        fmt.Fprintf(os.Stdout, " TCP | Failt to dial remote %v, err: %v\n",d,err)
        panic("Fail to dial " + d)
    }

    //fmt.Fprintf(os.Stdout, " TCP | Send Message %v to remote %v, local address %v\n",b,d,conn.LocalAddr().String())
	defer conn.Close() // 关闭连接
	l := len(m)
	p := 0
	q := 0
	var senddata []byte
	for {
		if p > l {
			break
		}
		q = p + 1024
		if q > l {
			senddata = m[p:l]
		} else {
			senddata = m[p:q]
		}
		var buf [4]byte
		bufs := buf[:]
		sendlen := len(senddata)
		//fmt.Printf("Len of send data %d\n",sendlen)
		binary.BigEndian.PutUint32(bufs, uint32(sendlen))
		//if _, err :=tcpCon.Write(bufs); err != nil {
		if _, err := conn.Write(bufs); err != nil {
			//fmt.Printf("write failed , err : %v\n", err)
			fmt.Fprintf(os.Stdout, " TCP | Error | Send msg error %v\n", err)
			break
		}
	//	if _, err = tcpCon.Write(senddata); err != nil {
		if _, err = conn.Write(senddata); err != nil {
			//fmt.Printf("write failed , err : %v\n", err)
			fmt.Fprintf(os.Stdout, " TCP | Error | Send msg error %v\n", err)
			break
        } else {
     //       fmt.Fprintf(os.Stdout, "GOSSIP | send to %s some data\n",d)
        }
		p = p + 1024
	}
	return
}

func (ins *Insta) Send() {
//func (g *GossipImp) Send(ctx context.Context) {
	//tricker:=time.NewTicker(300*time.Millisecond)
	for {
		select {
		case msg := <-ins.msgstream:
			bs, err := msg.ToBytes()
            //g.msglck.Lock()
			if err != nil {
				fmt.Fprintf(os.Stdout, "error to marshal message %v\nerror info: %v\n", msg, err)
				//return  err
			}
			for _, v := range ins.nodelist {
					go ins.send(bs,v)
				}
			}
        }
}

func (ins *Insta)IsMulti(flag bool){
    ins.isMulti=flag
}

func (ins *Insta)SetAddr(str string) {
    ins.addr=str
}

func (ins *Insta)SetMulti(str string) {
    if ins.nodelist == nil {
        ins.nodelist=make([]string, 0)
    }
    ins.nodelist=append(ins.nodelist, str)
}

func (ins *Insta)SetTCPServer(){
    var err error
    ins.tcp,err =net.Listen("tcp",ins.addr)
    if err!=nil {
        panic("Fail to Create TCP Server")
    }
}

func (ins *Insta)TcpServe(){
    go ins.Recv()
    go ins.Send()
}
