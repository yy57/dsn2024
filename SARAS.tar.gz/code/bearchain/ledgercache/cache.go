package ledgercache

import (
	"bearchain/block"
	"bearchain/constdef"
	"bearchain/ledger"
	"bearchain/ledger/kvdb"
	"bytes"
	"fmt"
	"sync"
)

type rwset struct {
	r []block.KV
	w []block.KV
}

//type version struct {
//    mod_block []byte
//    mod_block_height int
//    mod_tx []byte
//}
//
//type Value struct {
//    value []byte
//    ver version
//}

//type cacheKV struct {
//    Key []byte
//    value Value
//}

//ddtype

type Cache struct {
	l    *ledger.Ledger
    committedKV map[string]*kvdb.Value  // the committed state of ledger
    tbc_blockhash []byte
    blockcacheKV map[string]*kvdb.Value // the cache state of ledger with a to-be-committed block, create a new blockcache KV
    txcacheKV map[string]*kvdb.Value // the cache state of ledger with simulated TXs

	lock sync.Mutex
	TxR  map[string]rwset //cache the execute result of each tx

	depgraph   map[string][]string //the depend graph of tx in blockchain
	blockcache map[string]string   // the cache result of tx in blockchain
}

var localcache *Cache

func Init() *Cache {
	localcache = new(Cache)
	localcache.TxR = make(map[string]rwset)
	return localcache
}

func New() *Cache {
    cache:= new(Cache)
	cache.TxR = make(map[string]rwset)
	return cache
}

func (c *Cache) SetLedger(l *ledger.Ledger) {
	c.l = l
}

// if tx has been executed
func (c *Cache) IsExecuted(id string) bool {
	c.lock.Lock()
	_, ok := c.TxR[id]
	c.lock.Unlock()
	return ok
}

func exist(set []block.KV, key string) bool {
	for _, v := range set {
		if v.Key == key {
			return true
		}
	}
	return false
}

// if the tx
func (c *Cache) getKeyfromCache(id string, k string) ([]byte, error) {
	//    dep:=c.depgraph[id]
	//    for k,v:=dep {
	//        for
	//    }
	return nil, nil
}

// updata NODEP tx result to cache
func (c *Cache) NODEPToCache(txhs string) {
	w := c.TxR[txhs].w
	for _, v := range w {
		k := v.Key
		v := v.Val
		c.blockcache[k] = v
	}
}

func (c *Cache) Get(flag string, txhs []byte, key []byte) ([]byte, error) {
	// depend on some tx
	// execute it even if it has been executed
	if flag == constdef.DEP {
		val, ok := c.blockcache[string(key)]
		if !ok {
			val, err := c.l.Get(key)
			if err != nil {
				return nil, err
			}
			c.blockcache[string(key)] = string(val)
		}
		return []byte(val), nil
	}

	//Not executed and from CLIENT
	// execute it
	if flag == constdef.CLIENT {
		r, err := c.l.Get(key)
		if err != nil {
			return nil, err
		}
		c.lock.Lock()
		txr := c.TxR[string(txhs)]
		txr.r = make([]block.KV, 0)
		txr.r = append(txr.r, block.KV{Key: string(key), Val: string(r)})
		c.TxR[string(txhs)] = txr
		c.lock.Unlock()
		return r, nil
	}
	return nil, fmt.Errorf("Error execute flag")
}

func (c *Cache) Put(flag string, txhs []byte, key []byte, value []byte) {
	// if tx executed depend on some txhs
	// update the cache
	if flag == constdef.DEP {
		c.blockcache[string(key)] = string(value)
	}

	if flag == constdef.CLIENT {
		c.lock.Lock()
		r := c.TxR[string(txhs)]
		r.w = make([]block.KV, 0)
		r.w = append(r.w, block.KV{Key: string(key), Val: string(value)})
		//txr.w = append(txr.r, block.KV{string(key),string(value)})
		c.TxR[string(txhs)] = r
		c.lock.Unlock()
	}
}

func (c *Cache) GetTxSimulate(id []byte) (*block.Simulated, error) {
	c.lock.Lock()
	defer c.lock.Unlock()
	if _, ok := c.TxR[string(id)]; !ok {
		return nil, fmt.Errorf("Tx %v not simulated\n", id)
	}
	sim := new(block.Simulated)
	sim.Result.Txid = make([]byte, 0)
	sim.Result.Txid = append(sim.Result.Txid, id...)
	sim.Result.Rset = make([]block.KV, 0)
	r := c.TxR[string(id)]
	//c.lock.Unlock()
	rset := r.r
	wset := r.w
	sim.Result.Rset = make([]block.KV, 0)
	sim.Result.Rset = append(sim.Result.Rset, rset...)

	sim.Result.Wset = make([]block.KV, 0)
	sim.Result.Wset = append(sim.Result.Wset, wset...)
	return sim, nil
}

func (c *Cache) Update(*block.IBlock) {
}

// VerifyNewBlock
// Verify signature
// Verify tx conflict
// if all pass and is to-be-committed block, create a new blockcache KV
// judge if it is a to-be-committed block is complete in up-stream
//func (c *Cache)VerifyNewBlock(block *block.Block) error {
//    if block.Verify()!=true {
//        return nil
//    }
//    return nil
//}



// Run tx in to-be-committed block
// verify tx simulated result 
// if pass the verification
// Create a new blockcache KV
//func (c *Cache)CreateBlockCacheKV(block block.Block) bool {
//    fmt.Fprint(os.Stdout, " LedgerCache | CreateBlockCacheKV | Recerve a new tbc block, Create a new blockcache KV, time: %v\n",time.Now().String())
//    if c.tbc_blockhash!=nil {
//        //TBC
//        panic("BFT situation")
//    }
//    c.tbc_blockhash=block.Header.BlockHash 
//    for k,v:=range block.Txs {
//        //TBC
//    }
//    return true
//}

func (c *Cache) Commit(b *block.Block) {
    c.l.WriteABlock(b)
    // Write KV 
    // TBC
    for k,v:=range c.blockcacheKV {
        vbs:=v.ToBytes()
        c.l.Put([]byte(k),vbs)
    }
    c.blockcacheKV=make(map[string]*kvdb.Value)
}

// AsyncCommit
func (c *Cache) AsyncCommit(b *block.Block) {
    if bytes.Compare(c.tbc_blockhash,b.Header.BlockHash)==0 {
        c.l.WriteABlock(b)
        for k,v:=range c.blockcacheKV {
            vbs:=v.ToBytes()
            c.l.Put([]byte(k),vbs)
        }
        c.blockcacheKV=make(map[string]*kvdb.Value)
        c.tbc_blockhash=nil
    } else {
        //TBC
        // BFT situation
        panic("BFT situation")
    }
}
