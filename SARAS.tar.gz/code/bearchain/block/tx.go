package block

import (
	"bearchain/crypt"
	"bytes"
	"crypto/sha256"
	"fmt"
	"os"
	"time"
)

type ClientInput struct {
    Sig []byte `json:"sign"`
    Pk string `json:"pk"`
    Sc string `json:"Sc"`
    Para []string `json:"Para"`
}

func (c *ClientInput) toBytes() []byte {
    sc_b := []byte(c.Sc)
    for _,v:=range c.Para{
        sc_b=append(sc_b,[]byte(v)...)
    }
    return sc_b
}

func (c *ClientInput) Sign(sk string) error {
    s:=crypt.DecodeSk(sk)
    bs:=c.toBytes()
    hash,_:=crypt.Hash(bs)
    sig,err:=crypt.Sign(s,hash)
    if err!= nil {
        return err
    }
    c.Sig=sig
    return nil
}

func (c *ClientInput) Verify() (bool,error) {
    bs:=c.toBytes()
    hash,err:=crypt.Hash(bs)
    if err!=nil {
        return false, err
    }
    pk:=crypt.DecodePk(c.Pk)
    flag,err:=crypt.Verify(pk,hash, c.Sig)
    return flag,err
}


type Transaction struct{
    Inner  *ClientInput `json:"Inner"`
    Tx_ID []byte `json:"ID"`
}

func (tx *Transaction) Sign(sk string) error {
    return tx.Inner.Sign(sk)
}


func (tx *Transaction) computeID() error {
    inner_bt:=tx.Inner.toBytes()
    bs:=make([]byte, 256)
    bs=append(bs,tx.Inner.Sig...)
    bs=append(bs,[]byte(tx.Inner.Pk)...)
    bs=append(bs,inner_bt...)
    tx_ID:=sha256.Sum256(bs)
    tx.Tx_ID=tx_ID[:]
    return nil
}

func (tx *Transaction) Complete(sk string) error {
    err:=tx.Sign(sk)
    if err!=nil {
        return err
    }
    err=tx.computeID()
    if err!=nil {
        return err
    }
    return nil
}

func (tx *Transaction) Verify() (bool,error) {
    flag,err:=tx.Inner.Verify()
    if err!=nil {
        fmt.Fprintf(os.Stdout, " Block | tx.Verify | Failed to Verify tx %v ,time: %v\n",tx.Tx_ID,time.Now().String())
        return false,err
    }
    if flag==false{
        return false,nil
    }
    inner_bt:=tx.Inner.toBytes()
    bs:=make([]byte, 256)
    bs=append(bs,tx.Inner.Sig...)
    bs=append(bs,[]byte(tx.Inner.Pk)...)
    bs=append(bs,inner_bt...)
    tx_ID:=sha256.Sum256(bs)
    if bytes.Compare(tx_ID[:],tx.Tx_ID)!=0 {
        return false,nil
    }
    return true,nil
}
