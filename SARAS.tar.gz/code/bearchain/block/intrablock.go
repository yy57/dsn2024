package block

import (
	"bearchain/crypt"
	"crypto/ecdsa"
	"encoding/json"
	"fmt"
	"os"

	"github.com/vechain/go-ecvrf"
)

type IntraBlock struct {
	Pk       []byte        `json:"Pk"`
	Hash     []byte        `json:"Selected"`
	Proof    []byte        `json:"Proof"`
	Prev     []byte        `json:"Prev"`
	Root     []byte        `json:"Root"`
	Txs      []Transaction `json:"Txs"`
	TxResult []TxResult    `json:"TxResult"`
}

//func NewIntraBlock(prev []byte,txs []Transaction,txresult []TxResult) *IntraBlock {
func NewIntraBlock(prev []byte, simulated []Simulated) *IntraBlock {
	l := len(simulated)
	intra := new(IntraBlock)
	intra.Prev = prev
	intra.Txs = make([]Transaction, 0)
	intra.TxResult = make([]TxResult, 0)
	for i := 0; i < l; i++ {
		intra.Txs = append(intra.Txs, simulated[i].Tx)
		intra.TxResult = append(intra.TxResult, simulated[i].Result)
	}
	return intra
}

func (intra *IntraBlock) Complete(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
	l := len(intra.Txs)
	var leaf [][]byte
	for i := 0; i < l; i++ {
		leaf = append(leaf, ComputeLeafHash(intra.Txs[i], intra.TxResult[i]))
	}
	root := ComputeMerkleRoot(leaf)
	intra.Root = root

	bs := make([]byte, 0, 1024)
	bs = append(bs, intra.Prev...)
	bs = append(bs, intra.Root...)
	//bs=append(bs, intra.Root...)
	fmt.Fprintf(os.Stdout, "ecvrf data %s \t sk: %v\n", bs, sk)
	hash, proof, err := ecvrf.P256Sha256Tai.Prove(sk, bs)
	if err != nil {
		fmt.Fprintf(os.Stdout, " ERROR | ERROR to generate intrablock, info: %v\n", err)
	}
	intra.Hash = hash
	intra.Proof = proof
	p := crypt.EncodePk(pk)
	intra.Pk = []byte(p)
}

func (intra *IntraBlock) Verify() bool {
	//TBC
	return false
}

func (intra *IntraBlock) VerifyProof() bool {
	//TBC
	return true
}

func (intra *IntraBlock) ToByte() []byte {
	bs, err := json.Marshal(*intra)
	if err != nil {
		return nil
	}
	return bs
}
