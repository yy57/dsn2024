package block

import (
	"encoding/json"
	"fmt"
	"os"
)

type KV struct{
    Key string  `json:"key"`
    Val string `json:"val"`
}

func (kv *KV)ToBytes() []byte {
    //return json.Marshal(*kv)
    bs,err:=json.Marshal(*kv)
    if err!=nil {
        fmt.Fprintf(os.Stdout,"error to conv KV to byte: %v\n",err)
        return nil
    }
    return bs
}

type RSet struct {
    Kv []KV
}

type WSet struct {
    Kv []KV
}

type TxResult struct {
    Txid []byte `json:"ID"`
    Rset []KV `json:"Rset"`
    Wset []KV `json:"Wset"`
    //Err error
}

func (tr *TxResult)ToBytes() []byte{
    data:=make([]byte,1024)
    data=append(data,tr.Txid...)
    for _,v:=range tr.Rset {
        bs:=v.ToBytes()
        data=append(data,bs...)
    }
    for _,v:=range tr.Wset {
        bs:=v.ToBytes()
        data=append(data,bs...)
    }
    return data
}



type Simulated struct {
    Tx Transaction
    Result TxResult
}
