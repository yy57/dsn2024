package block

import (
	"bearchain/crypt"
	"bytes"
	"crypto/ecdsa"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"time"

	"github.com/vechain/go-ecvrf"
)

type Header struct {
	// previous block head
	Prev []byte `json:"Prev" yaml:"Prev"`

	// block info
	BlockType          string `json:"Type" yaml:"Type"`
	Sig                []byte `json:"Sig" yaml:"Sig"`
    Proof              []byte `json:"Proof"`
	Pk                 []byte `json:"Pk" yaml:"Pk"`
	MerkleRoot         []byte `json:"MerkleRoot" yaml:"MerkleRoot"`
	ProposerMerkleRoot []byte `json:"ProposerMerkleRoot"`
	Height             int    `json:"Height" yaml:"Height"`
    Weight             int    `json:"Weight"`


	// block hash computed with prev sig cert merkle_root height
	BlockHash []byte `json:"BlockHash" yaml:"BlockHash"`
}

type Proposer struct {
	Prev  []byte `json:"Prev"`
	Hash  []byte `json:"Hash"`
	Proof []byte `json:"Proof"`
	Pk    []byte `json:"Pk"`
}

func (p *Proposer) StartVerify() bool {
	if p.Hash == nil {
		panic("Empty Proposer Hash")
	}
	if len(p.Hash) == 0 {
		panic("Empty Proposer Hash")
	}
	if p.Proof == nil {
		panic("Empty Proposer Proof")
	}
	if len(p.Proof) == 0 {
		panic("Empty Proposer Proof")
	}
	if p.Pk == nil {
		panic("Empty Proposer Pk")
	}
	if len(p.Pk) == 0 {
		panic("Empty Proposer Pk")
	}
	pk := crypt.DecodePk(string(p.Pk))
	beta, err := ecvrf.P256Sha256Tai.Verify(pk, []byte("start"), p.Proof)
	//beta, err := ecvrf.Secp256k1Sha256Tai.Verify(pk, []byte("start"), p.Proof)
	fmt.Fprintf(os.Stdout, " Block | Proposer.Verify | Verify result beta %v,err: %v, time: %v\n", beta, err, time.Now().String())
	if err != nil {
		fmt.Fprintf(os.Stdout, " Block | Proposer.Verify | fail to verify proposer with pk %v, proof and pk unmatched, error info: %v, time: %v\n", pk, err, time.Now().String())
		return false
	}
	if bytes.Compare(beta, p.Hash) != 0 {
		fmt.Fprintf(os.Stdout, " Block | Proposer.Verify | fail to verify proposer with pk %v, proof and hash unmatched, time: %v\n", pk, time.Now().String())
		return false
	}
	return true
}

func (p *Proposer) Verify() bool {
	if p.Prev == nil {
		panic("Empty Proposer Prev")
	}
	if len(p.Prev) == 0 {
		panic("Empty Proposer Prev")
	}
	if p.Hash == nil {
		panic("Empty Proposer Hash")
	}
	if len(p.Hash) == 0 {
		panic("Empty Proposer Hash")
	}
	if p.Proof == nil {
		panic("Empty Proposer Proof")
	}
	if len(p.Proof) == 0 {
		panic("Empty Proposer Proof")
	}
	if p.Pk == nil {
		panic("Empty Proposer Pk")
	}
	if len(p.Pk) == 0 {
		panic("Empty Proposer Pk")
	}
	pk := crypt.DecodePk(string(p.Pk))
	beta, err := ecvrf.P256Sha256Tai.Verify(pk, p.Prev, p.Proof)
	if err != nil {
		fmt.Fprintf(os.Stdout, " Block | Proposer.Verify | fail to verify proposer with pk %v, proof and pk unmatched, error info: %v, time: %v\n", pk, err, time.Now().String())
		return false
	}
	if bytes.Compare(beta, p.Hash) != 0 {
		fmt.Fprintf(os.Stdout, " Block | Proposer.Verify | fail to verify proposer with pk %v, proof and hash unmatched, time: %v\n", pk, time.Now().String())
		return false
	}
	return true
}

func (p *Proposer) ToBytes() []byte {
	bs, err := json.Marshal(p)
	if err != nil {
		panic(err)
	}
	return bs
}

func (h *Header) Complete() {
	var data []byte
	data = append(data, h.Prev...)
	data = append(data, []byte(h.BlockType)...)
	data = append(data, h.Sig...)
	data = append(data, h.Proof...)
	data = append(data, h.Pk...)
	data = append(data, h.MerkleRoot...)
	//data=append(data, byte(h.Height)...)
	hash := sha256.Sum256(data)
	h.BlockHash = hash[:]
}

func (h *Header) Sign(sk *ecdsa.PrivateKey) error {
	var data []byte
	data = append(data, h.Prev...)
	data = append(data, []byte(h.BlockType)...)
	data = append(data, h.Pk...)
	data = append(data, h.MerkleRoot...)
	//data=append(data, byte(h.Height)...)
	sig, err := crypt.Sign(sk, data)
	if err != nil {
		fmt.Fprintf(os.Stdout, "error: %v\n", err)
		return err
	}
	h.Sig = sig
	return nil
}

type Payload struct {
	Transcations []Transaction
}

type Block struct {
	Header Header `json:"Header" yaml:"Header"`
	// Payload *Payload `json:"Body" yaml:"Body"`

	Txs      []Transaction `json:"Txs" yaml:"Txs"`
	TxResult []TxResult    `json:"TxResult" yaml:"TxResult"`
	Proposer []Proposer    `json:"Proposer"`
}

func ComputeLeafHash(tx Transaction, result TxResult) []byte {
	data := make([]byte, 0, 1024)
	data = append(data, tx.Tx_ID...)
	bs := result.ToBytes()
	data = append(data, bs...)
	ret := sha256.Sum256(data)
	return ret[:]
}

func ToEven(data [][]byte) [][]byte {
	l := len(data)
	if l%2 == 1 {
		dup := data[l-1][:]
		data = append(data, dup)
	}
	return data
}

// compute one level node to up level
func LevelCompute(level [][]byte) [][]byte {
	var uplevel [][]byte
	for i := 0; i < len(level); i = i + 2 {
		left := level[i][:]
		right := level[i+1][:]
		left = append(left, right...)
		hash := sha256.Sum256(left)
		uplevel = append(uplevel, hash[:])
	}
	return uplevel
}

func ComputeMerkleRoot(leaf [][]byte) []byte {
	if len(leaf) == 1 {
		return leaf[0][:]
	}
	leaf = ToEven(leaf)
	leaf = LevelCompute(leaf)
	return ComputeMerkleRoot(leaf)
}

func AlgorandNewBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey, prev []byte, height int, weight int, simulated []Simulated, proposer []*Proposer) *Block {
	//TBC
	b := new(Block)

	// complete block body
	l := len(simulated)
	//	for i := 0; i < l; i++ {
	//		b.Txs = append(b.Txs, simulated[i].Tx)
	//		b.TxResult = append(b.TxResult, simulated[i].Result)
	//	}
	for _, v := range simulated {
		b.Txs = append(b.Txs, v.Tx)
		b.TxResult = append(b.TxResult, v.Result)
	}

//	for _, v := range proposer {
//		b.Proposer = append(b.Proposer, *v)
//	}

	// complete block header
	b.Header = *new(Header)

	//    lt:=len(txs)
	//    lr:=len(result)
	//    if lt!=lr {
	//        fmt.Fprintf(os.Stdout,"error of tx and tx result: number not matched\n")
	//        return nil
	//    }
	var leaf [][]byte
	for i := 0; i < l; i++ {
		leaf = append(leaf, ComputeLeafHash(simulated[i].Tx, simulated[i].Result))
	}
	var root []byte
	if len(leaf) == 0 {
		root = nil
	} else {
		root = ComputeMerkleRoot(leaf)
	}

	b.Header.Prev = prev
	b.Header.BlockType = "tx"
	b.Header.Height = height
	b.Header.MerkleRoot = root
	p := crypt.EncodePk(pk)
	b.Header.Pk = []byte(p)

	var data []byte
	data = append(data, b.Header.Prev...)
	data = append(data, []byte(b.Header.BlockType)...)
	data = append(data, b.Header.Pk...)
	data = append(data, b.Header.MerkleRoot...)
	//data=append(data, byte(b.Header.b.Headereigb.Headert)...)
    sig,proof,err:=ecvrf.P256Sha256Tai.Prove(sk,data)
    fmt.Fprintf(os.Stdout,"data: %v,len %d, proof: %v len %d, beta: %v len %d\n",data,len(data),proof,len(proof),sig,len(sig))
	if err != nil {
		fmt.Fprintf(os.Stdout, "error: %v\n", err)
		return nil
	}
	b.Header.Sig = sig
    b.Header.Proof=proof
	//err := b.Header.Sign(sk)
	if err != nil {
		fmt.Fprintf(os.Stdout, "error: %v\n", err)
		return nil
	}
	b.Header.Complete()
    b.Header.Weight=weight
	return b
}

func NewBlockWithWeght(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey, prev []byte, height int, weight int, simulated []Simulated, proposer []*Proposer) *Block {
	//TBC
	b := new(Block)

	// complete block body
	l := len(simulated)
	//	for i := 0; i < l; i++ {
	//		b.Txs = append(b.Txs, simulated[i].Tx)
	//		b.TxResult = append(b.TxResult, simulated[i].Result)
	//	}
	for _, v := range simulated {
		b.Txs = append(b.Txs, v.Tx)
		b.TxResult = append(b.TxResult, v.Result)
	}

	for _, v := range proposer {
		b.Proposer = append(b.Proposer, *v)
	}

	// complete block header
	b.Header = *new(Header)

	//    lt:=len(txs)
	//    lr:=len(result)
	//    if lt!=lr {
	//        fmt.Fprintf(os.Stdout,"error of tx and tx result: number not matched\n")
	//        return nil
	//    }
	var leaf [][]byte
	for i := 0; i < l; i++ {
		leaf = append(leaf, ComputeLeafHash(simulated[i].Tx, simulated[i].Result))
	}
	var root []byte
	if len(leaf) == 0 {
		root = nil
	} else {
		root = ComputeMerkleRoot(leaf)
	}

	b.Header.Prev = prev
	b.Header.BlockType = "tx"
	b.Header.Height = height
	b.Header.MerkleRoot = root
    b.Header.Weight=weight
	p := crypt.EncodePk(pk)
	b.Header.Pk = []byte(p)

	err := b.Header.Sign(sk)
	if err != nil {
		fmt.Fprintf(os.Stdout, "error: %v\n", err)
		return nil
	}
	b.Header.Complete()
	return b
}

func NewBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey, prev []byte, height int, simulated []Simulated, proposer []*Proposer) *Block {
	//TBC
	b := new(Block)

	// complete block body
	l := len(simulated)
	//	for i := 0; i < l; i++ {
	//		b.Txs = append(b.Txs, simulated[i].Tx)
	//		b.TxResult = append(b.TxResult, simulated[i].Result)
	//	}
	for _, v := range simulated {
		b.Txs = append(b.Txs, v.Tx)
		b.TxResult = append(b.TxResult, v.Result)
	}

	for _, v := range proposer {
		b.Proposer = append(b.Proposer, *v)
	}

	// complete block header
	b.Header = *new(Header)

	//    lt:=len(txs)
	//    lr:=len(result)
	//    if lt!=lr {
	//        fmt.Fprintf(os.Stdout,"error of tx and tx result: number not matched\n")
	//        return nil
	//    }
	var leaf [][]byte
	for i := 0; i < l; i++ {
		leaf = append(leaf, ComputeLeafHash(simulated[i].Tx, simulated[i].Result))
	}
	var root []byte
	if len(leaf) == 0 {
		root = nil
	} else {
		root = ComputeMerkleRoot(leaf)
	}

	b.Header.Prev = prev
	b.Header.BlockType = "tx"
	b.Header.Height = height
	b.Header.MerkleRoot = root
	p := crypt.EncodePk(pk)
	b.Header.Pk = []byte(p)

	err := b.Header.Sign(sk)
	if err != nil {
		fmt.Fprintf(os.Stdout, "error: %v\n", err)
		return nil
	}
	b.Header.Complete()
	return b
}

// Verify:
// tx signature
// MerkleRoot
// block hash
// Proposer signature
func (b *Block) AlgorandVerify() bool {
	// verify tx hash and sign	fmt.Fprintf(os.Stdout, " Block | Block.Verify | Verify block %v, height %d, time: %v\n", b.Header.BlockHash, b.Header.Height, time.Now().String())
	for _, tx := range b.Txs {
		flag, err := tx.Verify()
		if err != nil {
			fmt.Fprintf(os.Stdout, " Block | Block.Verify | Failed to Verify tx %v in block %v, height %d, time: %v\n", tx.Tx_ID, b.Header.BlockHash, b.Header.Height, time.Now().String())
			return false
		}
		if flag != true {
			fmt.Fprintf(os.Stdout, " Block | Block.Verify | Failed to Verify tx %v in block %v, height %d, time: %v\n", tx.Tx_ID, b.Header.BlockHash, b.Header.Height, time.Now().String())
			return false
		}
	}

	// Verify MerkleRoot
	l := len(b.Txs)
	var leaf [][]byte
	for i := 0; i < l; i++ {
		//leaf = append(leaf, ComputeLeafHash(simulated[i].Tx, simulated[i].Result))
		leaf = append(leaf, ComputeLeafHash(b.Txs[i], b.TxResult[i]))
	}
	var root []byte
	if len(leaf) == 0 {
		root = nil
	} else {
		root = ComputeMerkleRoot(leaf)
	}
	if bytes.Compare(root, b.Header.MerkleRoot) != 0 {
		return false
	}

	// Verify Proposer signature
//	if bytes.Compare(b.Header.Prev, []byte("start")) == 0 {
//		for _, v := range b.Proposer {
//			flag := v.StartVerify()
//			if flag == false {
//				return flag
//			}
//		}
//	} else {
//		for _, v := range b.Proposer {
//			flag := v.Verify()
//			if flag == false {
//				return flag
//			}
//		}
//	}

	// Verify block creator signature
	pk := crypt.DecodePk(string(b.Header.Pk))
	var d1 []byte
	d1 = append(d1, b.Header.Prev...)
	d1 = append(d1, []byte(b.Header.BlockType)...)
	d1 = append(d1, b.Header.Pk...)
	d1 = append(d1, b.Header.MerkleRoot...)
    beta,err:=ecvrf.P256Sha256Tai.Verify(pk,d1,b.Header.Proof)
    //beta,err:=ecvrf.Secp256k1Sha256Tai.Verify(pk,d1,b.Header.Proof)
    //beta,err:=ecvrf.Secp256k1Sha256Tai.Verify(pk,b.Header.Proof,d1)
    //fmt.Fprintf(os.Stdout,"d1: %v,len %d, proof: %v len %d, beta: %v len %d\n",d1,len(d1),b.Header.Proof,len(b.Header.Proof),b.Header.Sig,len(b.Header.Sig))
	//flag, err := crypt.Verify(pk, d1, b.Header.Sig)
	if err != nil {
		return false
	}
    if 0!=bytes.Compare(beta,b.Header.Sig){
        return false
    }

	// Verify Block Hash
	var data []byte
	data = append(data, b.Header.Prev...)
	data = append(data, []byte(b.Header.BlockType)...)
	data = append(data, b.Header.Sig...)
	data = append(data, b.Header.Proof...)
	data = append(data, b.Header.Pk...)
	data = append(data, b.Header.MerkleRoot...)
	//data=append(data, byte(h.Height)...)
	hash := sha256.Sum256(data)
	if bytes.Compare(hash[:], b.Header.BlockHash) != 0 {
		return false
	}
	return true
}

// Verify:
// tx signature
// MerkleRoot
// block hash
// Proposer signature
func (b *Block) Verify() bool {
	// verify tx hash and sign	fmt.Fprintf(os.Stdout, " Block | Block.Verify | Verify block %v, height %d, time: %v\n", b.Header.BlockHash, b.Header.Height, time.Now().String())
	for _, tx := range b.Txs {
		flag, err := tx.Verify()
		if err != nil {
			fmt.Fprintf(os.Stdout, " Block | Block.Verify | Failed to Verify tx %v in block %v, height %d, time: %v\n", tx.Tx_ID, b.Header.BlockHash, b.Header.Height, time.Now().String())
			return false
		}
		if flag != true {
			fmt.Fprintf(os.Stdout, " Block | Block.Verify | Failed to Verify tx %v in block %v, height %d, time: %v\n", tx.Tx_ID, b.Header.BlockHash, b.Header.Height, time.Now().String())
			return false
		}
	}

	// Verify MerkleRoot
	l := len(b.Txs)
	var leaf [][]byte
	for i := 0; i < l; i++ {
		//leaf = append(leaf, ComputeLeafHash(simulated[i].Tx, simulated[i].Result))
		leaf = append(leaf, ComputeLeafHash(b.Txs[i], b.TxResult[i]))
	}
	var root []byte
	if len(leaf) == 0 {
		root = nil
	} else {
		root = ComputeMerkleRoot(leaf)
	}
	if bytes.Compare(root, b.Header.MerkleRoot) != 0 {
		return false
	}

	// Verify Proposer signature
	if bytes.Compare(b.Header.Prev, []byte("start")) == 0 {
		for _, v := range b.Proposer {
			flag := v.StartVerify()
			if flag == false {
				return flag
			}
		}
	} else {
		for _, v := range b.Proposer {
			flag := v.Verify()
			if flag == false {
				return flag
			}
		}
	}

	// Verify block creator signature
	pk := crypt.DecodePk(string(b.Header.Pk))
	var d1 []byte
	d1 = append(d1, b.Header.Prev...)
	d1 = append(d1, []byte(b.Header.BlockType)...)
	d1 = append(d1, b.Header.Pk...)
	d1 = append(d1, b.Header.MerkleRoot...)
	flag, err := crypt.Verify(pk, d1, b.Header.Sig)
	if err != nil {
		return false
	}
	if flag == false {
		return false
	}

	// Verify Block Hash
	var data []byte
	data = append(data, b.Header.Prev...)
	data = append(data, []byte(b.Header.BlockType)...)
	data = append(data, b.Header.Sig...)
	data = append(data, b.Header.Pk...)
	data = append(data, b.Header.MerkleRoot...)
	//data=append(data, byte(h.Height)...)
	hash := sha256.Sum256(data)
	if bytes.Compare(hash[:], b.Header.BlockHash) != 0 {
		return false
	}
	return true
}

func (b *Block) ContainProposer() bool {
	//TBC
	if b.Proposer == nil {
		return false
	}
	return true
}
