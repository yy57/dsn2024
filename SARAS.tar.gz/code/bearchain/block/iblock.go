package block

import "crypto/ecdsa"

type IBlock struct {
	Header Header `json:"Header" yaml:"Header"`
	// Payload *Payload `json:"Body" yaml:"Body"`

	IntraBlock []IntraBlock `json:"IntraBlock"`
}

func NewIBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey, prev []byte, intras []*IntraBlock) (*IBlock, error) {
	ib := new(IBlock)
	ib.IntraBlock = make([]IntraBlock, 0)
    for _,v:=range intras {
        ib.IntraBlock = append(ib.IntraBlock, *v)
    }
	//ib.IntraBlock = append(ib.IntraBlock, *intras...)
	ib.Header.Prev = make([]byte, 0)
	ib.Header.Prev = append(ib.Header.Prev, prev...)
	//ib.Header.Prev=make([]byte, 0)
	//for
	l := len(intras)
	leaf := make([][]byte, l)
	for i := 0; i < len(intras); i++ {
		leaf[i] = make([]byte, 0)
		leaf[i] = append(leaf[i], intras[i].Hash...)
	}
	//leaf[0]
	mtr := ComputeMerkleRoot(leaf)
	ib.Header.MerkleRoot = mtr
	ib.Header.Complete()
	return ib, nil
	//return nil,nil
}

func (ib *IBlock) Verify() bool {
	//    txidmap:=make(map[int]string)
	//    //idlist:= make([]int, 0)
	//    for _,v := range ib.IntraBlock{
	//        for _,v:=range v.Txs
	//    }
	//    return false
	return true
}

