num=100

list=($(seq 0 1 ${num}))

src=out


for elem in  ${list[@]}
do
    #grep -a "index ${elem} " $src | grep -a " Static " > static${elem}
    grep -a "index ${elem} " $src > out${elem}
    grep -a "Static | commitblock" out${elem} > static${elem}
done
