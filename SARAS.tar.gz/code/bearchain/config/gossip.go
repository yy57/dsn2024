package config

import (
	"fmt"
	"os"
)

type Nodeaddr struct {
    Addr string `yaml:"addr"`
    Udp string `yaml:"udp"`
    Tcp string `yaml:"tcp"`
}

func (n Nodeaddr) Print() {
    fmt.Fprintf(os.Stdout,"\t address: %s\n",n.Addr)
    fmt.Fprintf(os.Stdout,"\t udp address: %s\n",n.Udp)
    fmt.Fprintf(os.Stdout,"\t tcp address: %s\n",n.Tcp)
}

func (n *Nodeaddr) GetAddr() string {
    return n.Addr
}
 

func (n *Nodeaddr) GetUdpaddr() string {
    return n.Udp
}

func (n *Nodeaddr) GetTcpaddr() string {
    return n.Tcp
}

type Server struct {
    Addr string `yaml:"addr"`
    Udp string `yaml:"udp"`
    Tcp string `yaml:"tcp"`
}


type Client struct {
    Addr string `yaml:"addr"`
    Udp string `yaml:"udp"`
    Tcp string `yaml:"tcp"`
}

type GossipConfig struct {
    Latency int `yaml:"latency"`
    Unit string `yaml:"unit"`
    Interval uint16 `yaml:"interval"`
    UInterval uint16 `yaml:"uinterval"`
    Livetime uint16 `yaml:"livetime"`
    Deadtime uint16 `yaml:"deadtime"`
    Server Server   `yaml:"server"`
    Client Client   `yaml:"client"`
    //Addr string `yaml:"addr"`
	//Udp   string   `yaml:"udp"`
    //Tcp   string   `yaml:"tcp"`
    Bootstrap []Nodeaddr`yaml:"bootstrap"`
    SendStrategy string `yaml:"sendstrategy"`
    Ratio float32 `yaml:"ratio"`
} 

func (gconf *GossipConfig) GetServer() (string,string,string) {
    return gconf.Server.Addr,gconf.Server.Udp,gconf.Server.Tcp
}

func (gconf *GossipConfig) GetClient() (string,string,string) {
    return gconf.Client.Addr,gconf.Client.Tcp,gconf.Client.Udp
}

func (gspConfig *GossipConfig) Print() {
    fmt.Fprintf(os.Stdout,"Gossip config:\n")
    fmt.Fprintf(os.Stdout,"\tInterval: %d\n",gspConfig.Interval)
    fmt.Fprintf(os.Stdout,"\tlivetime: %d\n",gspConfig.Livetime)
    fmt.Fprintf(os.Stdout,"\tdeadtime: %d\n",gspConfig.Deadtime)
    //fmt.Fprintf(os.Stdout,"\tUdpaddr: %s\n",gspConfig.Udp)
    //fmt.Fprintf(os.Stdout,"\tTcpaddr: %s\n",gspConfig.Tcp)
    fmt.Fprintf(os.Stdout,"\tBootstrap: \n")
    for v :=range gspConfig.Bootstrap{
        gspConfig.Bootstrap[v].Print()
    }
    fmt.Fprintf(os.Stdout,"\tSenStrategy: %s\n",gspConfig.SendStrategy)
    fmt.Fprintf(os.Stdout,"\tRatio: %f\n",gspConfig.Ratio)
}

