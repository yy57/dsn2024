package config


type KeySave struct {
    SkPath string `yaml:"sk"`
    PkPath string `yaml:"pk"`
}
