package config

type VRF struct {
    Tao int `yaml:"tao"`
    Taonode int `yaml:"taonode"`
    Weight int `yaml:"weight"`
    Total int   `yaml:"total"`
}

func (v VRF)GetTao() float64 {
    //return float64(v.Tao)
    return float64(float64(v.Tao)/float64(v.Total))
}

func (v VRF)GetTaoNode() float64 {
    //return float64(v.Taonode)
    return float64(float64(v.Taonode)/float64(v.Total))
}
func (v VRF)GetTotal() int{
    return v.Total
}

func (v VRF)GetWeight() int {
    return v.Weight
}


