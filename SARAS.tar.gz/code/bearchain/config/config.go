package config

import (
	"fmt"
	"io/ioutil"
	"os"

	"gopkg.in/yaml.v3"
)

//gossip:
//    udpaddr:
//    tcpaddr:
//    bootstrap:
//
//ledger:
//    filepath:
//
//consensus:
//    type:

//func (lconfig *LedgerConfig) GetCondition() *Condition {
//    return &lconfig.C
//}



type Config struct {
    KeySave KeySave `yaml:"key"`

	Gossip GossipConfig `yaml:"gossip"`

    Ledger LedgerConfig `yaml:"ledger"`

    Consensus ConsensusConfig `yaml:"consensus"`

    Log LogConfig `yaml:"log"`

    V VRF `yaml:"VRF"`
}

func ReadConfig(path string) (*Config, error) {
	_, err := os.Stat(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, fmt.Errorf("%s not exist", path)
		}
	}
	file, err := ioutil.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var config Config
	err = yaml.Unmarshal(file, &config)
	if err != nil {
		return nil, err
	}
	return &config, nil
}

func (conf *Config) Print() {
    conf.Gossip.Print()
    conf.Ledger.Print()
    conf.Consensus.Print()
}

func (conf *Config) GetGossipConfig() *GossipConfig {
    return &conf.Gossip
}

func (conf *Config) GetGossipUdpAddr() string {
    //return conf.Gossip.Udp
    return conf.Gossip.Server.Addr+":"+conf.Gossip.Server.Udp
}
func (conf *Config) GetGossipTcpAddr() string {
    //return conf.Gossip.Tcp
    return conf.Gossip.Server.Addr+":"+conf.Gossip.Server.Tcp
}

func (conf *Config) GetLedgerConfig() *LedgerConfig {
    return &conf.Ledger
}

func (conf *Config) GetConsensusConfig() *ConsensusConfig {
    return &conf.Consensus
}

func (conf *Config) GetLogConfig() *LogConfig{
    return &conf.Log
}

func (c *Config) GetKeyStore() (string,string) {
    return c.KeySave.SkPath,c.KeySave.PkPath
}

func (c *Config)GetVRF() *VRF{
    return &c.V
}

func (c *Config)GetTao() float64 {
    return c.V.GetTao()
}

func (c *Config)GetTaoNode() float64 {
    return c.V.GetTaoNode()
}

func (c *Config)GetWeight() int{
    return c.V.GetWeight()
}
