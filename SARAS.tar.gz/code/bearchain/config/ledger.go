package config

import (
	"fmt"
	"os"
)

type Condition struct {
    Interval int `yaml:"interval"`
    Maxsize int `yaml:"maxsize"`
    Maxnum int `yaml:"maxnum"`
}

func (c *Condition) Print() {
    fmt.Fprintf(os.Stdout,"\t condition to produce a block\n")
    fmt.Fprintf(os.Stdout,"\t\t maxsize: %d",c.Maxsize)
    fmt.Fprintf(os.Stdout,"\t\t maxnum: %d",c.Maxnum)
    fmt.Fprintf(os.Stdout,"\t\t interval: %d",c.Interval)
}

type LedgerConfig struct{
    Filepath string `yaml:"filepath"`
    Size int `yam:"size"`
    //C Condition `yaml:"condition"`
}

func (lconfig *LedgerConfig) Print() {
    fmt.Fprintf(os.Stdout,"Ledger Config:\n")
    fmt.Fprintf(os.Stdout,"\tFilepath: %s\n",lconfig.Filepath)
    //lconfig.C.Print()
}

func (lconfig *LedgerConfig) GetFilePath() string {
    return lconfig.Filepath
}

func (lconfig *LedgerConfig) GetSize() int{
    return lconfig.Size
}
