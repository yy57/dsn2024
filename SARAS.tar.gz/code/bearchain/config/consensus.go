package config

import (
	"fmt"
	"os"
)

type ConsensusConfig struct{
    Bootstrap bool `yaml:"bootstrap"`
    Thresh float32 `yam:"thresh"`
    Threshack int `yaml:"threshack"`
    ThresProb float64 `yaml:"thresprob"`
    Tyype string `yaml:"type"`
    Condition Condition `yaml:"condition"`
}

func (cconfig *ConsensusConfig) Print() {
    fmt.Fprintf(os.Stdout,"Consensus Config:\n")
    fmt.Fprintf(os.Stdout,"\ttype: %s\n",cconfig.Tyype)
    cconfig.Condition.Print()
}

func (cconfig *ConsensusConfig)Isbootstrap() bool {
    return cconfig.Bootstrap
}

func (cconfig *ConsensusConfig) GetType() string {
    return cconfig.Tyype
}

func (cconfig *ConsensusConfig) GetCondition()  *Condition {
    return &cconfig.Condition
}
