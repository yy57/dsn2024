package config

import (
	"bearchain/constdef"
	"fmt"
	"os"
)

type LogConfig struct {
    Level string `yaml:"level"`
}

func (logconfig LogConfig) Print() {
    fmt.Fprintf(os.Stdout,"Log Config:\n")
    fmt.Fprintf(os.Stdout,"\tlevel: %s\n",logconfig.Level)
}

func (logconfig LogConfig) GetLevel() int {
    if logconfig.Level == "INFO" {
        return constdef.INFO
    }
    if logconfig.Level == "DEBUG" {
        return constdef.DEBUG
    }
    // log warn
    return constdef.INFO
}
