package main

import (
	"bearchain/insta"
	_ "net/http/pprof"
)


func main() {
    totalnum:=500
	nodenum := 100
	expect := 20
    nextRount := 10
	weight := 1
	ins := new(insta.Insta)
	// Mil
	// Sec
	// Min
	ins.SetLatency("Mil", 100)
	ins.SetConsensusLatency("Sec", 1)
	ins.SetNodeNum(totalnum, expect, nextRount, weight)
	ins.SetProb(0.3, 1, 0.0000000001)
    ins.SetMaliciousNum(40)
    weightbatch:=[]int{1,2,3,4,5}
    ins.SetWeightBatch(weightbatch,5)
    ins.SetStakeScale(10)

    //set node weight

	ins.IsMulti(false)
	//ins.IsMulti(true)
	ins.SetAddr("192.168.88.160:7666")
	ins.SetMulti("114.214.169.173:7666")
	ins.HashBoot(true)

    // algorand
    ins.SetType("my")
    //ins.SetType("algorand")
    //ins.SetExpectProposer(10)
    //ins.SetExpectCommittee(10)
    //ins.SetAlgorandlatency("Mil",100)
    //ins.SetAlgorandWaitingtime("Sec", 5)
	ins.Start(nodenum)

	// Read Conf file
	//file:=os.Getenv("BC_CONFIG")
	//go func() {
	//    if err := http.ListenAndServe(":6060", nil); err != nil {
	//        //log.Fatal(err)
	//        fmt.Fprintf(os.Stdout,"%v\n",err)
	//    }
	//    os.Exit(0)
	//}()
	//file := "./config.yaml"
	//nodeconf, err := config.ReadConfig(file)
	//if err != nil {
	//	fmt.Fprintf(os.Stderr, "%v\n", err)
	//}
	////nodeconf.Print()
	//last := strings.Split(nodeconf.Gossip.Server.Addr, ".")
	//l1, er := strconv.Atoi(last[3])
	//if er != nil {
	//	panic("Err")
	//}
	//l2, er := strconv.Atoi(nodeconf.Gossip.Server.Udp)
	//if er != nil {
	//	panic("Err")
	//}
	//l1 = l1 + l2
	//rand.Seed(time.Now().UnixNano())
	//// error information channel
	//errchan := make(chan error, 1024)
	//errinfo := errorp.NewErr(errchan)
	//go errinfo.Serve()

	//// init Key
	//skpath, pkpath := nodeconf.GetKeyStore()
	//key := crypt.Init(skpath, pkpath, errchan)
	//sk := key.GetSk()
	//pk := key.GetPk()

	//// init Log
	//loglevel := nodeconf.GetLogConfig().GetLevel()
	//log := log.InitlocalLog(loglevel)

	//// create channel used for communication between modules
	//consensus_to_gossip := make(chan *gossip.MessageImp, 4096)
	//gossip_to_consensus := make(chan *gossip.MessageImp, 4096)
	//resend := make(chan *gossip.Failsendmsg, 4096)

	//// init gossip server for node communication
	////gossip setting
	//log.Print("Init Gossip server", constdef.INFO)
	//gossip.InitLocalGossip()
	//gsp := gossip.GetlocalGossip()
	//err = gsp.Set(nodeconf.GetGossipConfig())
	//gsp.Setchan(consensus_to_gossip, gossip_to_consensus, resend)
	//addr1 := nodeconf.GetGossipUdpAddr()
	//addr2 := nodeconf.GetGossipTcpAddr()

	//udpaddr, err := net.ResolveUDPAddr("udp", addr1)
	//if err != nil {
	//	return
	//}
	//udpserver, err := net.ListenUDP("udp", udpaddr)
	////fmt.Fprintf(os.Stdout,"udp listen at %s", addr)
	//if err != nil {
	//	fmt.Println(err)
	//}
	////fmt.Fprintf(os.Stdout, "udp listen at %s\n", addr1)
	//log.Print("udp listen at "+addr1, constdef.INFO)
	//gsp.Setudp(udpserver)

	//tcpaddr, err := net.ResolveTCPAddr("tcp", addr2)
	//if err != nil {
	//	return
	//}
	//tcpserver, err := net.ListenTCP("tcp",tcpaddr)
	////tcpserver, err := net.Listen("tcp", tcpaddr.String())
	////fmt.Fprintf(os.Stdout,"udp listen at %s", addr)
	//if err != nil {
	//	fmt.Println(err)
	//}
	////fmt.Fprintf(os.Stdout, "tcp listen at %s\n", addr1)
	//log.Print("tcp listen at "+addr2, constdef.INFO)
	//gsp.Settcp(tcpserver)
	//log.Print("Start Gossip server", constdef.INFO)
	//go gsp.Serve()

	//// init Ledger server for data update
	//ledgerconf := nodeconf.GetLedgerConfig()
	//err = ledger.InitLedger(ledgerconf)
	//ledger := ledger.GetLedger()
	//defer ledger.Close()

	//cacheledger := ledgercache.Init()
	//cacheledger.SetLedger(ledger)

	//// init contract server
	//contract.InitContract()
	////contract.SetLedgerHandler(ledger)
	//sc := contract.GetLocalContract()
	//sc.SetLedgerHandler(ledger)
	//sc.SetCacheLedgerHandler(cacheledger)

	//// init consensus server
	//c := consensus.Init()
	//c.SetConsensus(nodeconf.GetConsensusConfig())
	//c.SetRecvchan(gossip_to_consensus)
	//c.SetSendchan(consensus_to_gossip)
	//c.SetContract(sc)
	//c.SetLedger(ledger)
	//c.SetCacheLedger(cacheledger)
	//fmt.Printf("tao: %v, tao: %v, weight: %v\n", nodeconf.GetTao(), nodeconf.GetTaoNode(), nodeconf.GetWeight())
	//c.SetVRF(nodeconf.GetTao(), nodeconf.GetTaoNode(), nodeconf.GetWeight())

	//log.Print("Start Consensus server", constdef.INFO)
	//pks := crypt.EncodePk(pk)
	//fmt.Fprintf(os.Stdout, "Start | My pk is %v\n", pks)
	//go c.Serve(sk, pk)

	//for {
	//	time.Sleep(100 * time.Second)
	//}

}
