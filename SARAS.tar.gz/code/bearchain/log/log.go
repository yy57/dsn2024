package log

import (
	"bearchain/constdef"
	"fmt"
	"os"
	"time"
)

type Log struct {
    level int
    // debug > normal
    // display info when Print function level <= Log level
    //stream string
}

func (l Log) SetLevel(level int) {
    l.level=level
}

func (l Log) Print(str string, lev int) {
    if l.level>=lev {
        if lev==constdef.INFO {    
            //fmt.Fprintf(os.Stderr,"\033[1;34;40%s | %v | %s\033[0m\n"," INFO",time.Now().Format("2006-01-02 15:04:05"),str)
            fmt.Fprintf(os.Stderr,"%s | %v | %s\n"," INFO",time.Now().Format("2006-01-02 15:04:05"),str)
        }
        if lev==constdef.DEBUG {    
            fmt.Fprintf(os.Stderr,"%s | %v | %s\n"," DEBUG",time.Now().Format("2006-01-02 15:04:05"),str)
        }
    }
}

func (l Log) Warn(str string) {
    fmt.Fprintf(os.Stderr,"%s | %v | %s\n"," WARN",time.Now().Format("2006-01-02 15:04:05"),str)
}

func (l Log) Error(str string) {
    fmt.Fprintf(os.Stderr,"%s | %v | %s\n"," ERROR",time.Now().Format("2006-01-02 15:04:05"),str)
}


var locallog Log

func InitlocalLog(level int) Log {
    locallog.SetLevel(level)
    return locallog
}

func GetlocalLog() Log {
    return locallog
}
