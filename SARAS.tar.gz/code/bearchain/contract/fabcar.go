package contract

import (
	"fmt"
	"os"
)

type Motor struct {
    Name string `json:"name"`
    Color string `json:"color"`
    Manu string `json:"manu"`
    Owner string `json:"owner"`
}

func (m Motor) toStrings() string {
    val:=m.Name+";"+m.Color+";"+m.Manu+";"+m.Owner
//    val:=make([]string, 4)
//    val=append(val,m.Name)
//    val=append(val,m.Color)
//    val=append(val,m.Manu)
//    val=append(val,m.Owner)
    return val
}


//func (c *Contract)CreateMotor(flag string,key string, name string, color string, manu string, owner string) (*block.Simulated,error){
//    simulated:=new(block.Simulated)
//    val:=Motor{
//        Name:name,
//        Color:color,
//        Manu:manu,
//        Owner:owner,
//    }
//
//
//    err:=c.l.SimulatePut(flag,simulated,[]byte(key),[]byte(val.toStrings()))
//
//
//    return simulated,err
//}
func (c *Contract)CreateMotor(flag string,txid []byte,key string, name string, color string, manu string, owner string){
    val:=Motor{
        Name:name,
        Color:color,
        Manu:manu,
        Owner:owner,
    }
    c.lc.Put(flag,txid,[]byte(key),[]byte(val.toStrings()))
    //c.lc.Put(txid,[]byte(key),[]byte(val.toStrings()))
    //err:=c.l.SimulatePut(flag,simulated,[]byte(key),[]byte(val.toStrings()))
    //return err
}

//func (c *Contract)QeuryMotor(key string) (*RSet,*WSet,error){
func (c *Contract)QueryMotor(key string) ([]byte,error) {
//    val:=Motor{
//        Name:name,
//        Color:color,
//        Manu:manu,
//        Owner:owner,
//    }
//    kv1:=KV{
//        key:key,
//        val:val.toStrings(),
//    }
//    rset:=RSet{}
//    rset.kv=make([]KV,1)
//    rset.kv=append(rset.kv, kv1)
//    wset:=WSet{}
//    valbs,err:=json.Marshal(val)
//    if err!=nil {
//        fmt.Fprintf(os.Stdout,"%v", err)
//        //return err
//    }
    bs,err:=c.l.Get([]byte(key))
    if err !=nil {
        fmt.Fprintf(os.Stdout,"error when read %s: %v\n",key,err)
    } 
    fmt.Fprintf(os.Stdout,"Query key:%s, val:%v\n",key,bs)
    return bs,nil
    //return &rset,&wset,nil
}

func QueryAllMotors() {

}


func BuyMotor() {
    //Create
}

func ChangeMotor() {

}
