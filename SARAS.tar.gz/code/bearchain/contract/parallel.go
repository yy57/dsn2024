package contract

import (
	"bearchain/block"
)

type edge struct {
    v_tx int
    e_tx  []int
}


func computeEdger(r block.TxResult,w block.TxResult) bool {
    rset:=r.Rset
    wset:=w.Wset
    for _,rk:=range rset {
        for _,wk:=range wset {
            if rk.Key==wk.Key {
                return true
            }
        }
    }
    return false
}
//
//
//func getinGraph(TxR []rwset) (map[int][]int,map[int][]int) {
//    outgraph:=make(map[int][]int)
//    ingraph:=make(map[int][]int)
//    for  i,w:=range TxR {
//        for j,r:=range TxR {
//            if computeEdger(w,r) {
//                outgraph[i]=append(outgraph[i], j)
//                ingraph[j]=append(outgraph[j], j)
//            }
//        }
//    }
//    return ingraph,outgraph
//}

func GetGraph(TxR map[string]block.TxResult) (map[string][]string,map[string][]string) {
    outgraph:=make(map[string][]string)
    ingraph:=make(map[string][]string)
    for  k1,r:=range TxR {
        for k2,w:=range TxR {
            if computeEdger(r,w) {
                outgraph[k1]=append(outgraph[k1], k2)
                ingraph[k2]=append(outgraph[k2], k1)
            }
        }
    }
    return ingraph,outgraph
}
//
//func removeNode(i int,ingraph map[interface{}][]interface{},outgraph map[interface{}][]interface{}) {
//
//}


func ParallelVefiry(ib *block.IBlock) bool {
    txids:=make(map[string]block.TxResult)
    for _,intra:=range ib.IntraBlock {
        for  _,tx:=range intra.TxResult {
            txids[string(tx.Txid)]=tx
        }
    }

    //ingraph,outgraph:=getinGraph(txids)
    return true
}
