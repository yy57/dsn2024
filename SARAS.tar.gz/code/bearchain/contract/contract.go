package contract

import (
	"bearchain/block"
	"bearchain/constdef"
	"bearchain/ledger"
	"bearchain/ledgercache"
	"fmt"
	"os"
	"time"

	"github.com/looplab/tarjan"
)

type Contract struct {
	txchan          chan<- block.Transaction
	verifyblcokchan chan block.Block
	update          chan block.Block
	errchan         chan error
	l               *ledger.Ledger
	lc              *ledgercache.Cache

	txcache  map[string]*block.Transaction
	ingraph  map[string][]string
	outgraph map[string][]string
	exechan  chan string
}

var localcontract *Contract

//func (c *)
func InitContract() *Contract {
	localcontract = new(Contract)
	return localcontract
}

func NewContract() *Contract {
    contract := new(Contract)
	return contract
}
//func GetLocalContract()
func GetLocalContract() *Contract {
	//localcontract:=new(Contract)
	return localcontract
}

func (c *Contract) SetCacheLedgerHandler(lc *ledgercache.Cache) {
	c.lc = lc
}

func (c *Contract) SetLedgerHandler(l *ledger.Ledger) {
	c.l = l
}

func GetContract(txchan chan block.Transaction, verifyblock chan block.Block, update chan block.Block) *Contract {
	c := new(Contract)
	c.txchan = txchan
	c.verifyblcokchan = verifyblock
	c.update = update
	return c
}

// user predefine
//func (c *Contract) smartcontract(flag string,txid []byte, sc string, para []string) (*block.Simulated, error) {
func (c *Contract) smartcontract(flag string, txid []byte, sc string, para []string) (*block.Simulated, error) {
	switch sc {
	//case "QuerySC":
	case "CreateMotor":
		l := len(para)
		if l != 5 {
			return nil, nil
		}
		c.CreateMotor(flag, txid, para[0], para[1], para[2], para[3], para[4])
		return c.lc.GetTxSimulate(txid)
	case "QueryMotor":
		l := len(para)
		if l != 1 {
			return nil, nil
		}
		c.QueryMotor(para[0])
		return nil, nil
	case "QueryAllMotors":
	case "BuyMotor":
	case "ChangeMotor":
	}
	return nil, nil
}

func (c *Contract) ExecTx(flag string, tx block.Transaction, txresult chan<- *block.Simulated) error {
//    errchan:=errorp.GetErrChan()
	// Client tx
	// execute it
	if flag == constdef.CLIENT {
		if c.lc.IsExecuted(string(tx.Tx_ID)) {
            fmt.Fprintf(os.Stdout," Contract | Recv existed transaction from client %v\n",tx)
			return nil
		}
		simulated, err := c.smartcontract(flag, tx.Tx_ID, tx.Inner.Sc, tx.Inner.Para)
		if err != nil {
            fmt.Fprintf(os.Stdout," Contract | Error | Fail to simulated tx,error: %v\n,time: %v\n",err,time.Now().String())
			//errchan <- err
			return err
		}
		simulated.Tx = tx
		txresult <- simulated
	}

	// used when verify block and commit block
	// if tx is nodependent to any tx
	// if it hasnt been executed, executed it
	// else used the executed result
	if flag == constdef.NODEP {
		if c.lc.IsExecuted(string(tx.Tx_ID)) {
			//_, err := c.smartcontract(flag, tx.Tx_ID, tx.Inner.Sc, tx.Inner.Para)
			return nil
		}
		_, err := c.smartcontract(flag, tx.Tx_ID, tx.Inner.Sc, tx.Inner.Para)
		if err != nil {
            fmt.Fprintf(os.Stdout," Contract | Error | Fail to simulated tx,error: %v\n,time: %v\n",err,time.Now().String())
			//errchan <- err
			return err
		}
		//c.lc.NODEPToCache(string(tx.Tx_ID))
        return nil
	}
	// if tx is nodependent to any tx
	// re-execute it
	if flag == constdef.DEP {
		//if !c.lc.IsExecuted(string(tx.Tx_ID)) {
		//	_, err := c.smartcontract(flag, tx.Tx_ID, tx.Inner.Sc, tx.Inner.Para)
		//	if err != nil {
		//		errchan <- err
		//		return err
		//	}
		//}
		_, err := c.smartcontract(flag, tx.Tx_ID, tx.Inner.Sc, tx.Inner.Para)
		if err != nil {
            fmt.Fprintf(os.Stdout," Contract | Error | Fail to simulated tx,error: %v\n,time: %v\n",err,time.Now().String())
			//errchan <- err
			return err
		}
		c.lc.NODEPToCache(string(tx.Tx_ID))
		return nil
	}
	//	_, err := c.smartcontract(flag,tx.Tx_ID, tx.Inner.Sc, tx.Inner.Para)
	//    return err
    return nil
}

func deletTx(tx string, txs []string) []string {
	for k, v := range txs {
		if v == tx {
			txs = append(txs[:k], txs[k+1:]...)
			return txs
		}
	}
	return txs
}

func (c *Contract) updategraph() {
	for {
		select {
		case RunTx := <-c.exechan:
			{
				dponRuntx := c.ingraph[RunTx]
				for _, v := range dponRuntx {
					c.outgraph[v] = deletTx(RunTx, c.outgraph[v])
				}
				delete(c.ingraph, RunTx)
				delete(c.outgraph, RunTx)
			}
		}
	}
}

func (c *Contract) deletTx(tx string) {
	dponRuntx := c.ingraph[tx]
	for _, v := range dponRuntx {
		c.outgraph[v] = deletTx(tx, c.outgraph[v])
	}
	delete(c.ingraph, tx)
	delete(c.outgraph, tx)
}

func (c *Contract) stage1Execute(txid string) {
	c.ExecTx(constdef.NODEP, *c.txcache[txid], nil)
	c.exechan <- txid
}

func IsNocycle(c []int) bool {
	for i := range c {
		if c[i] != 0 {
			return false
		}
	}
	return true
}

func countTx(c []int, tx []int) int {
	res := 0
	for _, ci := range tx {
		res = res + c[ci]
	}
	return res
}

// parallel execute stages:
// stage1:
// for
//     execute nodependent tx
//     update graph
// untill there are cycles in left txs
// stage2:
//      mark some tx to break the cycles
// statge3:
//      execute left txs
func (c *Contract) parallel() {
	//stage1
	//flag:=true
	for {
		flag := false
		for k, v := range c.outgraph {
			if len(v) == 0 {
				//go c.ExecTx(constdef.NODEP,*c.txcache[k],nil,c.errchan)
				go c.stage1Execute(k)
				// update graph
				//TBC
				flag = true
			}
		}
		c.updategraph()
		// there are cycles in left txs
		if flag == false && len(c.outgraph) != 0 {
			break
		}
	}

	// stage 2
	// obtain the cycle
	tarGraph := make(map[interface{}][]interface{})
	for k, v := range c.outgraph {
		if _, ok := tarGraph[k]; !ok {
			tarGraph[k] = make([]interface{}, 0)
		}
		tarGraph[k] = append(tarGraph[k], v)
	}
	cs := tarjan.Connections(tarGraph)
	cn := len(cs)
	clist := make([]int, 0, cn)
	for i := range cs {
		clist[i] = 1
	}
	// count the tx in which cycle
	txinc := make(map[string][]int)
	tx_count := make(map[string]int)
	//tx_count:=make([]int,0,cn)
	// record tx in which cycle
	for i, ci := range cs {
		for _, txid := range ci {
			if _, ok := txinc[txid.(string)]; !ok {
				txinc[txid.(string)] = make([]int, 0, cn)
			}
			txinc[txid.(string)] = append(txinc[txid.(string)], i)
		}
	}
	for k := range c.outgraph {
		tx_count[k] = countTx(clist, txinc[k])
	}
	for {
		if IsNocycle(clist) {
			break
		}
		max := 0
		var dtx string
		for k := range tx_count {
			if tx_count[k] >= max {
				//delet tx k
				dtx = k
			}
		}
		for _, i := range txinc[dtx] {
			clist[i] = 0
		}
		c.deletTx(dtx)
	}

	// stage 3 execute tx
	for {
		flag := false
		for k, v := range c.outgraph {
			if len(v) == 0 {
				//go c.ExecTx(constdef.NODEP,*c.txcache[k],nil,c.errchan)
				go c.stage1Execute(k)
				// update graph
				//TBC
				flag = true
			}
		}
		c.updategraph()
		// there are cycles in left txs
		if flag == false && len(c.outgraph) != 0 {
			break
		}
	}
}

func (c *Contract) ParallelExecuteBlock(ib *block.IBlock) {
	txs := make(map[string]block.TxResult)
	for _, intra := range ib.IntraBlock {
		for _, txr := range intra.TxResult {
			txs[string(txr.Txid)] = txr
		}
		for _, tx := range intra.Txs {
			c.txcache[string(tx.Tx_ID)] = &tx
		}
	}
	c.ingraph, c.outgraph = GetGraph(txs)
	c.parallel()
}
