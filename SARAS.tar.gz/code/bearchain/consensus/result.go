package consensus

type algoquery struct {
    weight int
    prev []byte
    hash []byte
    height int
    pk string
    done bool
}

type algoresult struct {
    prev []byte
    blockhash []byte
    height int
    weight int
    vote int
    pk string
    pks []string
    choosed bool
}

type result struct {
    pk []byte
    id []byte
    prev []byte
    //nowid []byte
    height int
    count int
    ack bool
    weight int
}

func (r *result)ToBytes() []byte {
    bs:=append(r.pk,r.id...)
    bs=append(bs,r.prev...)
    //bs=append(bs,r.nowid...)
    //bs=append()
    return bs
}


type query struct {
    //pk []byte
    id []byte
    prev []byte
    count int
    height int
    ifresp bool
}

//func (q *query)Size() int {
//    return 
//}

func (q *query)ToBytes() []byte {
    return append(q.id,q.prev...)
}

type statistic struct {
    //time.Now()
}

func GetNow() *statistic {
    return nil
}

func (s *statistic)ToString() string{
    return ""
}
