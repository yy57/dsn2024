package consensus

import (
	"bearchain/block"
	"bytes"
)

type intraCache []*block.IntraBlock

func (ic intraCache)Len() int {
    return len(ic)
}

func (ic intraCache)Less(i int,j int) bool {
    cmp:=bytes.Compare(ic[i].Hash,ic[j].Hash)
    if cmp==-1 || cmp==0{
        return true
    }
    return false
}

func (ic intraCache)Swap(i int,j int) {
    temp:=ic[i]
    ic[i]=ic[j]
    ic[j]=temp
}

type iblockcache []block.IBlock
func (ic iblockcache)Len() int {
    return len(ic)
}

func (ic iblockcache)Less(i int,j int) bool {
    cmp:=bytes.Compare(ic[i].Header.BlockHash,ic[j].Header.BlockHash)
    if cmp==-1 || cmp==0{
        return true
    }
    return false
}

func (ic iblockcache)Swap(i int,j int) {
    temp:=ic[i]
    ic[i]=ic[j]
    ic[j]=temp
}
