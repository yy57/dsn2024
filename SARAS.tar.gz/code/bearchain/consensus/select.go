package consensus

import (
	"encoding/binary"
	"math"
)

func factorial(n int) int {
    f:=1
    for i:=1;i<=n;i++ {
        f=f*i
    }
    return f
}

func binomial(k int, n int,p float64) float64 {
    fn:=float64(factorial(n))
    fk:=float64(factorial(k))
    fn_k:=float64(factorial(n-k))
    result := fn/fk/fn_k * float64(math.Pow(p,float64(k))) *float64(math.Pow(p,float64(n-k)))
    return result
}

func interval(k int, n int,p float64) (float64,float64) {
    lb:=float64(0)
    for i:=0;i<=k;i++ {
        lb=lb+binomial(i,n,p)
    }
    ub:=float64(0)
    for i:=0;i<=k+1;i++ {
        ub=ub+binomial(i,n,p)
    }
    return lb,ub
}

func Selected(hash []byte, l int, tau float64, n int) bool {
    data:=binary.BigEndian.Uint64(hash)
    scale:=float64(float64(data)/math.Pow(float64(2),float64(l)))
    j:=0
    for j=0;j<n;j++ {
        lb,ub:=interval(j,n,tau)
        if scale>=lb && scale < ub  {
            break
        }
    }
    if j>=0 {
        return true
    }
    return false
}
