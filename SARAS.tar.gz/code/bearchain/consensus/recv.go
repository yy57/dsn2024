package consensus

import (
	"bearchain/block"
	"bearchain/constdef"
	"bearchain/crypt"
	"bearchain/random"
	"bytes"
	"crypto/ecdsa"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"time"

	"github.com/vechain/go-ecvrf"
)

func (c *MyConsensus) RecvProposer(bs []byte) {
	//TBC
	//check validatiy TBC
	//
    c.lck.Lock()
	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvProposer | Get lock, Time: %v\n",  c.Index, time.Now().String())
    defer c.lck.Unlock()
    //c.proposercachelck.Lock()
    //defer c.proposercachelck.Unlock()
	proposer := new(block.Proposer)
    //fmt.Fprintf(os.Stdout," CONSENSUS | RecvProposer | recv proposer %v, prev %v, time: %v\n",proposer, proposer.Prev, time.Now().String())
	err := json.Unmarshal(bs, proposer)
	if err != nil {
		panic(err)
	}
    pk:=crypt.DecodePk(string(proposer.Pk))
    beta,err:=ecvrf.P256Sha256Tai.Verify(pk,proposer.Prev,proposer.Proof)
    if err!=nil {
        //fmt.Fprintf(os.Stdout," index %v |  CONSENSUS | RecvProposer | recv Wrong proposer, err %v, pk %v, prev %v, time: %v\n",c.Index, err,proposer.Pk, proposer.Prev, time.Now().String())
        return
    }
    if 0!=bytes.Compare(beta,proposer.Hash) {
        //fmt.Fprintf(os.Stdout," index %v |  CONSENSUS | RecvProposer | recv Wrong proposer,  pk %v, prev %v, time: %v\n",c.Index, proposer.Pk, proposer.Prev, time.Now().String())
        return
    }
    
    prob:=float64(c.nextRound)/float64(c.total)
    if !random.Select(proposer.Hash,prob,c.weight) {
        //fmt.Fprintf(os.Stdout," index %v |  CONSENSUS | RecvProposer | recv Wrong proposer,  pk %v, prev %v, time: %v\n",c.Index, proposer.Pk, proposer.Prev, time.Now().String())
        return
    }
    //fmt.Fprintf(os.Stdout," index %v |  CONSENSUS | RecvProposer | recv proposer, pk %v, prev %v, time: %v\n",c.Index, proposer.Pk, proposer.Prev, time.Now().String())
    fmt.Fprintf(os.Stdout," index %v |  CONSENSUS | RecvProposer | recv proposer block height %d, time: %v\n",c.Index, c.height, time.Now().String())
	if bytes.Compare(proposer.Prev, c.prev) == 0 {
        ////fmt.Fprintf(os.Stdout,"index %v |  CONSENSUS | RecvProposer | proposer %v is in the next block, prev %v, time: %v\n",c.Index, proposer, proposer.Prev, time.Now().String())
		c.proposercache = append(c.proposercache, proposer)
	    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvProposer | release lock, Time: %v\n",  c.Index, time.Now().String())
		return
	}
	// a committed
	if c.isACommitBlock(proposer.Prev) {
        //fmt.Fprintf(os.Stdout,"index %v |  CONSENSUS | RecvProposer | proposer %v is in committed block, prev %v, time: %v\n",c.Index ,proposer, proposer.Prev, time.Now().String())
	    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvProposer | release lock, Time: %v\n",  c.Index, time.Now().String())
		return
	}
    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvProposer | proposer %v is in future block, prev %v, time: %v\n",c.Index, proposer, proposer.Prev, time.Now().String())
	c.proposerfuture = append(c.proposerfuture, proposer)
	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvProposer | release lock, Time: %v\n",  c.Index, time.Now().String())
}

func (c *MyConsensus) RecvBlock(bs []byte, sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
    c.lck.Lock()
    defer c.lck.Unlock()
    //var ifquery bool
    //ifquery=false
	newblock := new(block.Block)
    //c.choosedlock.Lock()
    //defer c.choosedlock.Unlock()
    //fmt.Fprintf(os.Stdout, "index %v | Consensus | Recv new block, block hash %v, block height %d, block prev %v, time: %v\n",c.Index, newblock.Header.BlockHash,newblock.Header.Height,newblock.Header.Prev, time.Now().String())
	err := json.Unmarshal(bs, newblock)
	if err != nil {
		panic(err)
	}
    //fmt.Fprintf(os.Stdout, "index %v | Consensus | RecvBlock | Recv new block, block hash %v, block height %d, block prev %v, time: %v\n", c.Index, newblock.Header.BlockHash,newblock.Header.Height,newblock.Header.Prev, time.Now().String())
	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Get lock, Time: %v\n",  c.Index, time.Now().String())
	//defer fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Release lock, Time: %v\n",c.Index,  time.Now().String())
	if !newblock.Verify() {
        //fmt.Fprintf(os.Stdout, "index %v | Consensus | RecvBlock | New block verify fail drop it, block hash %v, block height %d, block prev %v, time: %v\n", c.Index, newblock.Header.BlockHash,newblock.Header.Height,newblock.Header.Prev, time.Now().String())
		return
	}

	if bytes.Compare(newblock.Header.Prev, []byte("start")) == 0 {
        //fmt.Fprintf(os.Stdout, "index %v | Consensus | RecvBlock | Block(hash %v) is a start block, time: %v\n",c.Index, newblock.Header.BlockHash, time.Now().String())
		c.Bootstrap(newblock,sk,pk)
        return
	}
    //c.lck.Lock()
	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Get lock, Time: %v\n",  c.Index, time.Now().String())
    //defer c.lck.Unlock()
	// is a committed block
    //fmt.Fprintf(os.Stdout, "index %v | Consensus | Block(hash %v) is a committed block, time: %v\n", newblock.Header.BlockHash, time.Now().String())
	if c.isACommitBlock(newblock.Header.BlockHash) {
        //fmt.Fprintf(os.Stdout, "index %v | Consensus | RecvBlock | Block(hash %v) is a committed block, height %d, time: %v\n",c.Index, newblock.Header.BlockHash,newblock.Header.Height, time.Now().String())
	    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Release lock, Time: %v\n",c.Index,  time.Now().String())
		return
	}


	// is a to-be-committed block and we dont have a to-be-committed block
	if bytes.Compare(newblock.Header.Prev, c.prev) == 0 {
        //fmt.Fprintf(os.Stdout, "index %v | Consensus | Block(hash %v) is a start block, time: %v\n", newblock.Header.BlockHash, time.Now().String())
		if c.choosed == nil {
			//if c.choosed != nil {
            //fmt.Fprintf(os.Stdout, "index %v | Consensus | RecvBlock | Block(hash %v) is a to-be-committed block, height %d, Set choosed block to it And Query to ths Block, time: %v\n", c.Index, newblock.Header.BlockHash, newblock.Header.Height, time.Now().String())
            //fmt.Fprintf(os.Stdout, "index %v | Consensus | RecvBlock | Set choosed block %v, block height %d, time: %v\n", c.Index, newblock.Header.BlockHash, newblock.Header.Height, time.Now().String())
			//TBC
	//		c.choosedlock.Lock()
            c.newBlockTime=time.Now()
			c.choosed = newblock
            c.blockcache=append(c.blockcache, newblock)
	//		c.choosedlock.Unlock()
			//TBC
            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | (RecvBlock) push this block to query channel for block query, time: %v\n",c.Index,  time.Now().String())
            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | (RecvBlock) push this block to query channel for block query, time: %v\n",c.Index,  time.Now().String())
            c.QueryBlock(sk,pk)
            //if len(c.blockquerychan)==0 {
            //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | (RecvBlock) push this block to query channel for block query, time: %v\n",c.Index,  time.Now().String())
            //    ifquery=true
            //    c.blockquerychan <- newblock
            //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | (RecvBlock) push this block to query channel Success!!!!, time: %v\n",c.Index,  time.Now().String())
            //}
            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | (RecvBlock) push this block to query channel Success!!!!, time: %v\n",c.Index,  time.Now().String())
			//c.blockresponechan <- newblock
	        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Release lock, Time: %v\n",c.Index,   time.Now().String())
            //if ifquery==true {
            //    if c.choosed == nil {
            //        fmt.Fprintf(os.Stdout, "index %v |  SumQueryResult | RecvBlock | Error: choosed is empty time: %v\n",c.Index,  time.Now().String())
            //        panic("SumQueryResult | Error: choosed is empty")
            //    }
            //}
			return
        } else {
            // recv same to-be-committed block
            if bytes.Compare(c.choosed.Header.BlockHash,newblock.Header.BlockHash) == 0 {
                //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Recv same to-be-committed block, height %d, block hash %v\n",c.Index, newblock.Header.BlockHash, newblock.Header.Height)
	            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Release lock, Time: %v\n",c.Index,   time.Now().String())
                return
            }  else {
			    // malicious node create two block
			    //  TBC
//                c.blockcache=append(c.blockcache, newblock)
//                if len(c.blockcache)>=2{
//                    //c.SendMalicious()
//                    panic("Two to be committed block")
//                }
//                return
            }
        }
//		if bytes.Compare(newblock.Header.Prev, c.choosed.Header.Prev) != 0 {
//			// malicious node create two block
//			// TBC
//		} else {
//	        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Release lock, Time: %v\n",  time.Now().String())
//			return
//		}
	} else {
		// is a future block
        fmt.Fprintf(os.Stdout, "index %v | Consensus | Block(hash %v) is a future block, height %d, time: %v\n",c.Index, newblock.Header.BlockHash,newblock.Header.Height, time.Now().String())
     //   c.waitingblocklck.Lock()
		if _, ok := c.waitingblock[string(newblock.Header.BlockHash)]; !ok {
			c.waitingblock[string(newblock.Header.BlockHash)] = newblock
		}
      //  c.waitingblocklck.Unlock()
	}
	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Release lock, Time: %v\n",c.Index,  time.Now().String())
}

// update cache
func (c *MyConsensus) isAMissingBlock(blockhash []byte) bool {
	for _, val := range c.blockcache {
		cmp := bytes.Compare(val.Header.BlockHash, blockhash)
		if cmp == 0 {
			return false
		}
	}
	return true
}

// update cache
func (c *MyConsensus) isACommitBlock(blockhash []byte) bool {
	for _, v := range c.commitblockhash {
		cmp := bytes.Compare([]byte(v), blockhash)
		if cmp == 0 {
			return true
		}
	}
	//TBC
	//for _, v := range c.commitblock {
	//	cmp := bytes.Compare(v.Header.BlockHash, blockhash)
	//	//cmp := bytes.Compare([]byte(v), blockhash)
	//	if cmp == 0 {
	//		return true
	//	}
	//}
	return false
}

func (c *MyConsensus) ExistALaterBlock(blockhash []byte) bool {
	//    //TBC
	//    for _,v:=range c.laterblock{
	//		cmp := bytes.Compare(v.Header.BlockHash, blockhash)
	//		//cmp := bytes.Compare([]byte(v), blockhash)
	//		if cmp == 0 {
	//			return true
	//		}
	//    }
	return false
}

func (c *MyConsensus) RecvQuery(cmsg *ConsensusMessage) {
    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvConsensusMsg | Recv Query Msg: Blockhash %v, Prev %v, Height %d, Count: %v, Msghash: %v, pk: %v, time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev,cmsg.Height,cmsg.Count,cmsg.MsgHash,cmsg.Pk,time.Now().String())
	blockhash := cmsg.BlockHash
	qmsg := new(query)
	qmsg.id = blockhash
	qmsg.prev = cmsg.Prev
	qmsg.ifresp = false
    qmsg.count=cmsg.Count
    qmsg.height=cmsg.Height
	//msghash := sha256.Sum256(qmsg.ToBytes())
	msghash := cmsg.MsgHash
    c.querymsglock.Lock()
    defer c.querymsglock.Unlock()
	if _, ok := c.query[string(msghash[:])]; !ok {
        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvConsensusMsg | Recv Query Msg is a new Query: Blockhash %v, Prev %v, Height %d, Count: %v, Msghash: %v, pk: %v, time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev,cmsg.Height,cmsg.Count,cmsg.MsgHash,cmsg.Pk,time.Now().String())
        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvConsensusMsg | it is a New Query Msg, save it, time: %v\n",c.Index, time.Now().String())
        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvConsensusMsg | Recv QUERY to block %v, block prev %v, time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev,time.Now().String())
		c.query[string(msghash[:])] = qmsg
	}
}

func (c *MyConsensus) RecvRespone(cmsg *ConsensusMessage) {
    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvConsensusMsg | Recv Respone Msg: Blockhash %v, Prev %v, Height %d, Count: %v, Msghash: %v, pk: %v, time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev,cmsg.Height,cmsg.Count,cmsg.MsgHash,cmsg.Pk,time.Now().String())
    bs:=make([]byte,0)
    bs=append(bs, []byte(cmsg.Ttype)...)
    bs=append(bs, cmsg.BlockHash...)
    bs=append(bs,cmsg.Prev...)

    cstr:=strconv.Itoa(cmsg.Count)
    //bs=append(bs,[]byte(hstr)...)
    bs=append(bs,[]byte(cstr)...)

    h:=sha256.Sum256(bs)


    if 0!=bytes.Compare(h[:],cmsg.MsgHash) {
        //fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | Error Respone message, compute hash %v, msg hash %v, time: %v\n",c.Index,h, cmsg.MsgHash,time.Now().String())
        return
    }

    //beta,proof,err:=ecvrf.P256Sha256Tai.Prove(sk,msg.MsgHash)
    pk:=crypt.DecodePk(string(cmsg.Pk))
    beta,err:=ecvrf.P256Sha256Tai.Verify(pk,h[:],cmsg.Proof)
    if err!=nil {
        //fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | Error Respone message %v, time: %v\n",c.Index, err,time.Now().String())
        return
    }
    if 0!=bytes.Compare(beta,cmsg.Sig) {
        //fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | Error Respone message %v, time: %v\n",c.Index, err,time.Now().String())
        return
    }


//    var prob float64
//    qmsg.count=cmsg.Count
//    if qmsg.Count ==0 {
//
//    } 
    var prob float64 
    if cmsg.Count==0 {
        prob=float64(c.expect)/float64(c.total)
    } else {
        prob=float64(c.expect)/float64(c.total)/float64(5)
    }
    //prob:=float64(c.expect)/float64(c.total)
    if !random.Select(beta, prob, c.weight) {
        //fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | This message is not selected, pk %v, time: %v\n",c.Index,cmsg.Pk,time.Now().String())
        return
    }

	blockhash := cmsg.BlockHash
	rmsg := new(result)
	rmsg.pk = cmsg.Pk
	rmsg.id = blockhash
	rmsg.prev = cmsg.Prev
    rmsg.height=cmsg.Height
    rmsg.ack=cmsg.ACK
    rmsg.weight=cmsg.Weight
    rmsg.count=cmsg.Count
//	if cmsg.ACK== true {
//		rmsg.ack = true
//    } else if cmsg.ACK==constdef.NOACK {
//
//    }
	//msghash := sha256.Sum256()
    data:=append(bs,cmsg.Pk...)
    msghash:=sha256.Sum256(data)
	//msghash := cmsg.MsgHash

    //if msghash == nil {
    //    panic("empty respone msg hash")
    //}
	//msghash := sha256.Sum256(rmsg.ToBytes())
	// respone to a committed block
	for _, v := range c.commitblock {
		cmp := bytes.Compare(v.Header.BlockHash, blockhash)
	    //cmp := bytes.Compare([]byte(v), blockhash)
		if cmp == 0 {
            //fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | Recv RESPONE to committed block  %v,  block prev %v, height %d, time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev,v.Header.Height,time.Now().String())
            return
		}
	}
    // respone to a to-be-commitblock or future block
    //c.resultlock.Lock()
    //defer c.resultlock.Unlock()
	if _, ok := c.result[string(msghash[:])]; !ok {
        if cmsg.ACK==true {
            ///fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | Recv ACK RESPONE to to-be-cimmitted or future block %v, block prev %v, height %d, time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev, cmsg.Height,time.Now().String())
        } else {
            //fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | Recv NO-ACK RESPONE to to-be-cimmitted or future block %v, block prev %v, height %d, time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev, cmsg.Height,time.Now().String())
        }
        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvConsensusMsg | Recv Respone Msg: Blockhash %v, Prev %v, Height %d, Count: %v, Msghash: %v, pk: %v, time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev,cmsg.Height,cmsg.Count,cmsg.MsgHash,cmsg.Pk,time.Now().String())
		c.result[string(msghash[:])] = rmsg
	}
}

//TBC
func (c *MyConsensus) RecvConsensusMsg(bs []byte, sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
	// first verify the sig of consensus message
	cmsg := new(ConsensusMessage)
	err := json.Unmarshal(bs, cmsg)
	if err != nil {
		return
	}
	ok := cmsg.Verify()
	//spk := cmsg.SPk
	if !ok {
		//fmt.Fprintf(os.Stdout, "index %v |  ERROR | Failed to verify consensus messge\n",c.Index )
		return
	}
    c.lck.Lock()
	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvConsensusMsg | Get lock, Time: %v\n",c.Index,  time.Now().String())
    defer c.lck.Unlock()
	if cmsg.Ttype == constdef.QUERY {
        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvConsensusMsg | Recv Query, Time: %v\n",c.Index,  time.Now().String())
		c.RecvQuery(cmsg)
	}

	// Recv respone
	if cmsg.Ttype == constdef.RESPONE {
        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvConsensusMsg | Recv Respone, Time: %v\n",c.Index,  time.Now().String())
		c.RecvRespone(cmsg)
	}
	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvConsensusMsg | Release lock, Time: %v\n",c.Index,  time.Now().String())
}
