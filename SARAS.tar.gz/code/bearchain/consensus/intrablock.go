package consensus

//
//import (
//	"bearchain/block"
//	"time"
//)
//
//func generate_IntraBlock(cache []contract.TxResult, size int) *Intra_Block{
//    return nil
//}
//
//func  (c *MyConsensus) Generate_intraBlock() {
//// Generate intra block for selection
//    ticker:=time.NewTicker(time.Duration(c.intraBlockTime)*time.Second)
//    cache:=make([]contract.TxResult,1000)
//    i:=0
//    for {
//        select {
//        case verified_tx:=<-c.exe_tx:
//            cache[i]=verified_tx
//            i=i+1
//        case <-ticker.C:
//            intraBlock:=generate_IntraBlock(cache,i)
//            i=0
//            c.lck.Lock()
//            c.intraBlock=intraBlock
//            c.lck.Unlock()
//        }
//    }
//}
//
//func generate_block(intrablock []Intra_Block,num int) *block.Block {
//    return nil
//}
//
//func (c *MyConsensus) Process_intraBlock() {
//// Process selected intra block to block
////    c.lck.Lock()
////    defer c.lck.Unlock()
//    cache:=make([]Intra_Block,1000)
//    ticker:=time.NewTicker(time.Duration(c.intraBlockTime)*time.Second)
//    i:=0
//    for {
//        select {
//            //intraBlockchan chan Intra_Block
//        case intra_block:=<-c.intraBlockchan:
//            cache[i]=intra_block
//            i++
//        case <-ticker.C:
//            c.block=generate_block(cache,i)
//            i=0
//        }
//    }
//}
//
//func (c *MyConsensus) Query_And_Commit_Block() {
//// Query and Commit Block
//}
