package consensus

import (
	"bearchain/block"
	"bearchain/constdef"
	"bearchain/crypt"
	"bearchain/gossip"
	"bearchain/random"
	"bytes"
	"crypto/ecdsa"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"strconv"

	"github.com/vechain/go-ecvrf"
)

type ConsensusMessage struct {
    Ttype string `json:"type"`
    BlockHash []byte`json:"blockhash"`
    Prev []byte `json:"Prev"`
    Height int  `json:"height"`
    Weight int  `json:"Weight"`
    Vote    int `json:"Vote"`
    Count int `json:"count"`

    Pk []byte `json:"pk"`
    Sig []byte `json:"sig"`
    Proof []byte `json:"proof"`
    MsgHash []byte `json:"msghash"`

    Data []byte  `json:"data"`
    NowID []byte `json:"Id"`
	//ttype int
    Resp string `json:"resp"`
    ACK bool `json:"ack"`
    SPk []byte `json:"spk"`
    Timestamp string `json:"timestamp"`
}

type MaliciousMsg struct {
    Pk string `json:"pk"`
    Header []block.Header `json:"header"`
    MsgHash []byte `json:"msghash"`
}

func (m MaliciousMsg)ToBytes() []byte{
    bs,err:=json.Marshal(m)
    if err!=nil {
        panic(" MaliciousMsg | Fail to mashal msg")
    }
    return bs
}

//func (m MaliciousMsg)ToMessag() (*gossip.MessageImp,error){
    //return nil, nil
//}

func (msg ConsensusMessage) ToBytes() ([]byte, error) {
	//TBC
	return json.Marshal(msg)
	//return msg.bs,nil
}

func (msg ConsensusMessage) Resolve() {

}

//
func ConsensusMessageResolve(bs []byte) (*ConsensusMessage, error) {
	var cMsg ConsensusMessage
	err := json.Unmarshal(bs[:], &cMsg)
	if err != nil {
		return nil, err
	}
	return &cMsg, nil
}

func (msg ConsensusMessage) Print() {

}

// verify VRF sig and if selected
// VRF verify failed or selected verify fail return false
func (msg *ConsensusMessage)VerifySelected(tau float64, m int, n int) bool {
//    bs := make([]byte,0)
//    bs=append(bs, msg.Data...)
//    bs=append(bs, []byte(msg.Ttype)...)
//    bs=append(bs, []byte(msg.Resp)...)
//    bs=append(bs, msg.SPk...)
//    p:=crypt.DecodePk(string(msg.Pk))
//    beta,err:=ecvrf.Secp256k1Sha256Tai.Verify(p,bs,msg.Proof)
//    if err!=nil {
//        return false
//    }
//    if bytes.Compare(beta,msg.Sig)!=0 {
//        return false
//    }
//    if !random.Select(beta,tau,m,n) {
//        return false
//    }
    return true
}

// verify sig
func (msg *ConsensusMessage)Verify() bool {
//    tmp:=new(ConsensusMessage)
//    tmp.Pk=msg.Pk
//    //tmp.Sig=make([]byte,0)
//    tmp.Data=msg.Data
//    tmp.Ttype=msg.Ttype
//    tmp.Resp=msg.Resp
//    tmp.SPk=msg.SPk
//    bs,err:=tmp.ToBytes()
//    if err!=nil {
//        panic(err)
//    }
//    hash,err:=crypt.Hash(bs)
//    if err!=nil {
//        panic(err)
//    }
//    pk:=crypt.DecodePk(string(msg.Pk))
//    ok,err:=crypt.Verify(pk,hash,msg.Sig)
//    if err!=nil {
//        panic(err)
//    }
//    return ok
    return true
}


func (msg *ConsensusMessage)Complete(){
    //TBC
//    tmp:=new(ConsensusMessage)
//    tmp.Pk=msg.Pk
//    //tmp.Sig=make([]byte,0)
//    tmp.Data=msg.Data
//    tmp.Ttype=msg.Ttype
//    tmp.Resp=msg.Resp
//    tmp.SPk=msg.SPk
//    bs,err:=tmp.ToBytes()
//    if err!=nil {
//        panic(err)
//    }
//    hash,err:=crypt.Hash(bs)
//    if err!=nil {
//        panic(err)
//    }
//    pk:=crypt.DecodePk(string(msg.Pk))
//    ok,err:=crypt.Verify(pk,hash,msg.Sig)
//    if err!=nil {
//        panic(err)
//    }
//    return ok
}

func (msg *ConsensusMessage)VRFComplete(){
    //TBC
//    tmp:=new(ConsensusMessage)
//    tmp.Pk=msg.Pk
//    //tmp.Sig=make([]byte,0)
//    tmp.Data=msg.Data
//    tmp.Ttype=msg.Ttype
//    tmp.Resp=msg.Resp
//    tmp.SPk=msg.SPk
//    bs,err:=tmp.ToBytes()
//    if err!=nil {
//        panic(err)
//    }
//    hash,err:=crypt.Hash(bs)
//    if err!=nil {
//        panic(err)
//    }
//    pk:=crypt.DecodePk(string(msg.Pk))
//    ok,err:=crypt.Verify(pk,hash,msg.Sig)
//    if err!=nil {
//        panic(err)
//    }
//    return ok
}

func  intraToMessage(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey,intra *block.IntraBlock) *gossip.MessageImp{
    bs:=intra.ToByte()
    gspmsg:=new(gossip.MessageImp)
    gspmsg.Bs=bs
    gspmsg.Ttype=constdef.NEWINTRA
    gspmsg.Dst=""
    return gspmsg
} 

func missingmsg(blockhash []byte) *gossip.MessageImp{
    //TBC
//    cmsg:=new(ConsensusMessage)
//    cmsg.Data=make([]byte, 0)
//    cmsg.Data = append(cmsg.Data, blockhash...)
//    bs,err:=cmsg.ToBytes()
//    if err!=nil {
//        panic(err)
//    }
    gmsp:=new(gossip.MessageImp)
    gmsp.Bs=make([]byte,0)
    gmsp.Bs=append(gmsp.Bs, blockhash...)
    gmsp.Ttype=constdef.MISSBLOCK
    return gmsp
}

//TBC
// Random Selection
func (c *MyConsensus)ackmsg2(flag string,blockhash []byte,prev []byte,height int,count int,sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) *gossip.MessageImp{
    if blockhash == nil {
        panic("ackmsg Empty blockhash")
    }
    msg:=new(ConsensusMessage)
    //Type
    msg.Ttype=constdef.RESPONE

    //Block hash
    msg.BlockHash=make([]byte, 0)
    msg.BlockHash = append(msg.BlockHash, blockhash...)
    //msg.BlockHash = append(msg.BlockHash, c.choosed.Header.BlockHash...)

    // Prev
    msg.Prev=make([]byte,0 )
    msg.Prev=append(msg.Prev,prev...)
    //msg.Prev=append(msg.Prev,c.choosed.Header.Prev...)

    // height
    msg.Height=height

    //weight 
    msg.Weight=c.weight
    // Index
    //msg.Index=c.Index
    // Count
    msg.Count=count

    // ifACK
    if flag==constdef.ACK {
        msg.ACK=true
    } else if flag==constdef.NOACK {
        msg.ACK=false
    }

    // Pk
    pks:=[]byte(crypt.EncodePk(pk))
    msg.Pk=make([]byte, 0)
    msg.Pk=append(msg.Pk, pks...)

    //msghash
    bs:=make([]byte,0)
    bs=append(bs, []byte(msg.Ttype)...)
    bs=append(bs, msg.BlockHash...)
    bs=append(bs, msg.Prev...)
    //hstr:=strconv.Itoa(msg.Height)
    cstr:=strconv.Itoa(msg.Count)
    //bs=append(bs,[]byte(hstr)...)
    bs=append(bs,[]byte(cstr)...)
    //bs=append(bs, pks...)
    h:=sha256.Sum256(bs)
    msg.MsgHash=make([]byte, 0)
    msg.MsgHash = append(msg.MsgHash, h[:]...)

    // Sig
    beta,proof,err:=ecvrf.P256Sha256Tai.Prove(sk,msg.MsgHash)
    if err!=nil {
        //fmt.Fprintf(os.Stdout," query msg error1\n")
        panic(err)
    }
    //TBC
    // Random Selction
    var prob float64
    //if count==0 {
    //    prob=float64(c.expect)/float64(c.total)
    //} else {
    //    prob=float64(c.expect)/float64(c.total)/float64(5)
    //}
    prob=float64(c.expect)/float64(c.total)
    if !random.Select(beta, prob, 1) {
    //if !random.Select(beta, prob, c.weight) {
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | ackmsg | my respone to Query hash %v, prev %d, height %d has not been selected, time: %v\n", c.Index, blockhash,prev,height, time.Now().String())
        return nil
    }
	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | ackmsg | my respone to Query hash %v, prev %d, height %d has been selected, time: %v\n", c.Index, blockhash,prev,height, time.Now().String())
    //fmt.Fprintf(os.Stdout," query msg: append proof sig\n")
    msg.Sig=make([]byte,0 )
    msg.Sig= append(msg.Sig, beta...)

    // Proof
    //fmt.Fprintf(os.Stdout," query msg: append proof\n")
    msg.Proof=make([]byte, 0)
    msg.Proof = append(msg.Proof, proof...)


    gmsp:=new(gossip.MessageImp)
    data,err:=msg.ToBytes()
    if err!=nil {
        //fmt.Fprintf(os.Stdout," query msg error2\n")
        panic(err)
    }
    gmsp.Bs=data
    gmsp.Ttype=constdef.CONSENSUS
    gmsp.Info=string(msg.BlockHash)
    return gmsp
}

func (c *MyConsensus)ackmsgLaska(flag string,blockhash []byte,prev []byte,height int,count int,sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) *gossip.MessageImp{
    if blockhash == nil {
        panic("ackmsg Empty blockhash")
    }
    msg:=new(ConsensusMessage)
    //Type
    msg.Ttype=constdef.RESPONE

    //Block hash
    msg.BlockHash=make([]byte, 0)
    msg.BlockHash = append(msg.BlockHash, blockhash...)
    //msg.BlockHash = append(msg.BlockHash, c.choosed.Header.BlockHash...)

    // Prev
    msg.Prev=make([]byte,0 )
    msg.Prev=append(msg.Prev,prev...)
    //msg.Prev=append(msg.Prev,c.choosed.Header.Prev...)

    // height
    msg.Height=height

    //weight 
    msg.Weight=c.weight
    // Index
    //msg.Index=c.Index
    // Count
    msg.Count=count

    // ifACK
    if flag==constdef.ACK {
        msg.ACK=true
    } else if flag==constdef.NOACK {
        msg.ACK=false
    }

    // Pk
    pks:=[]byte(crypt.EncodePk(pk))
    msg.Pk=make([]byte, 0)
    msg.Pk=append(msg.Pk, pks...)

    //msghash
    bs:=make([]byte,0)
    bs=append(bs, []byte(msg.Ttype)...)
    bs=append(bs, msg.BlockHash...)
    bs=append(bs, msg.Prev...)
    //hstr:=strconv.Itoa(msg.Height)
    cstr:=strconv.Itoa(msg.Count)
    //bs=append(bs,[]byte(hstr)...)
    bs=append(bs,[]byte(cstr)...)
    //bs=append(bs, pks...)
    h:=sha256.Sum256(bs)
    msg.MsgHash=make([]byte, 0)
    msg.MsgHash = append(msg.MsgHash, h[:]...)

    // Sig
    beta,proof,err:=ecvrf.P256Sha256Tai.Prove(sk,msg.MsgHash)
    if err!=nil {
        //fmt.Fprintf(os.Stdout," query msg error1\n")
        panic(err)
    }
    //TBC
    // Random Selction
	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | ackmsg | my respone to Query hash %v, prev %d, height %d has been selected, time: %v\n", c.Index, blockhash,prev,height, time.Now().String())
    //fmt.Fprintf(os.Stdout," query msg: append proof sig\n")
    msg.Sig=make([]byte,0 )
    msg.Sig= append(msg.Sig, beta...)

    // Proof
    //fmt.Fprintf(os.Stdout," query msg: append proof\n")
    msg.Proof=make([]byte, 0)
    msg.Proof = append(msg.Proof, proof...)


    gmsp:=new(gossip.MessageImp)
    data,err:=msg.ToBytes()
    if err!=nil {
        //fmt.Fprintf(os.Stdout," query msg error2\n")
        panic(err)
    }
    gmsp.Bs=data
    gmsp.Ttype=constdef.CONSENSUS
    gmsp.Info=string(msg.BlockHash)
    return gmsp
}

// return a gossip.Message 
// ack/noack to a block query
// flag  ack noack
// askid to-be-committed block-id
// TBC
//func (c *MyConsensus)ackmsg2(flag string,blockhash []byte,prev []byte,height int,count int,sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) *gossip.MessageImp{
func (c *MyConsensus)ackmsg(flag string,blockhash []byte,prev []byte,height int,count int,sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) *gossip.MessageImp{
    if blockhash == nil {
        panic("ackmsg Empty blockhash")
    }
    msg:=new(ConsensusMessage)
    //Type
    msg.Ttype=constdef.RESPONE

    //Block hash
    msg.BlockHash=make([]byte, 0)
    msg.BlockHash = append(msg.BlockHash, blockhash...)
    //msg.BlockHash = append(msg.BlockHash, c.choosed.Header.BlockHash...)

    // Prev
    msg.Prev=make([]byte,0 )
    msg.Prev=append(msg.Prev,prev...)
    //msg.Prev=append(msg.Prev,c.choosed.Header.Prev...)

    // height
    msg.Height=height

    // Index
    //msg.Index=c.Index
    // Count
    msg.Count=count

    // ifACK
    if flag==constdef.ACK {
        msg.ACK=true
    } else if flag==constdef.NOACK {
        msg.ACK=false
    }

    // Pk
    pks:=[]byte(crypt.EncodePk(pk))
    msg.Pk=make([]byte, 0)
    msg.Pk=append(msg.Pk, pks...)

    //msghash
    bs:=make([]byte,0)
    bs=append(bs, []byte(msg.Ttype)...)
    bs=append(bs, msg.BlockHash...)
    bs=append(bs, msg.Prev...)
    //hstr:=strconv.Itoa(msg.Height)
    cstr:=strconv.Itoa(msg.Count)
    //bs=append(bs,[]byte(hstr)...)
    bs=append(bs,[]byte(cstr)...)
    //bs=append(bs, pks...)
    h:=sha256.Sum256(bs)
    msg.MsgHash=make([]byte, 0)
    msg.MsgHash = append(msg.MsgHash, h[:]...)
    //msghash
    //bs:=make([]byte,0)
    //bs=append(bs, []byte(msg.Ttype)...)
    //bs=append(bs, msg.BlockHash...)
    //bs=append(bs, msg.Prev...)
    //hstr:=strconv.Itoa(msg.Height)
    //cstr:=strconv.Itoa(msg.Count)
    //bs=append(bs,[]byte(hstr)...)
    //bs=append(bs,[]byte(cstr)...)
    //bs=append(bs, pks...)
    //h:=sha256.Sum256(bs)
    //msg.MsgHash=make([]byte, 0)
    //msg.MsgHash = append(msg.MsgHash, h[:]...)

    // Sig
    beta,proof,err:=ecvrf.P256Sha256Tai.Prove(sk,msg.MsgHash)
    if err!=nil {
        //fmt.Fprintf(os.Stdout," query msg error1\n")
        panic(err)
    }
    //fmt.Fprintf(os.Stdout," query msg: append proof sig\n")
    msg.Sig=make([]byte,0 )
    msg.Sig= append(msg.Sig, beta...)

    // Proof
    //fmt.Fprintf(os.Stdout," query msg: append proof\n")
    msg.Proof=make([]byte, 0)
    msg.Proof = append(msg.Proof, proof...)


    gmsp:=new(gossip.MessageImp)
    data,err:=msg.ToBytes()
    if err!=nil {
        //fmt.Fprintf(os.Stdout," query msg error2\n")
        panic(err)
    }
    gmsp.Bs=data
    gmsp.Ttype=constdef.CONSENSUS
    gmsp.Info=string(msg.BlockHash)
    return gmsp
}
    ////TBC 
    ////cmsg.Pk=pk
    //cmsg:=new(ConsensusMessage)
    //cmsg.Pk=make([]byte, 0)

    //p:=crypt.EncodePk(pk)
    //cmsg.Pk=append(cmsg.Pk, p...)

    //cmsg.Data=make([]byte,0)
    //cmsg.Data = append(cmsg.Data,askid...)

    //cmsg.Prev=make([]byte, 0)
    //cmsg.Prev=append(cmsg.Prev, c.prev...)

//  //  cmsg.NowID=make([]byte, 0)
//  //  cmsg.NowID=append(cmsg.NowID, c.choosed.Header.BlockHash...)

    //cmsg.Ttype=constdef.RESPONE

    //cmsg.Resp=flag

    //cmsg.SPk=make([]byte, 0)
    //cmsg.SPk=append(cmsg.SPk, spk...)
    //cmsg.Timestamp=time.Now().String()

    //bs:=make([]byte,0)
    //bs=append(bs, cmsg.Pk...)
    //bs=append(bs, cmsg.Data...)
    //bs=append(bs, cmsg.Prev...)
    //bs=append(bs, cmsg.NowID...)
    //bs=append(bs, []byte(cmsg.Ttype)...)
    //bs=append(bs, []byte(cmsg.Resp)...)
    ////cmsg.Complete()
    //hash,proof,err:=ecvrf.P256Sha256Tai.Prove(sk,bs)
    //if err!=nil {
    //    fmt.Fprintf(os.Stdout," Consensus | Error when VRF hash")
    //}
    //ok := random.Select(hash, c.taonode, c.totalnode) 
    //if !ok {
    //    return nil
    //}

    //cmsg.Sig=make([]byte, 0)
    //cmsg.Sig=append(cmsg.Sig, hash...)
    //cmsg.Proof=make([]byte, 0)
    //cmsg.Proof=append(cmsg.Proof, proof...)

    //cmsgbs,err:=cmsg.ToBytes()
    ////cmsg.NowID=c.choosed.Header.BlockHash
    //if err!=nil {
    //    panic(err)
    //}
    //msg:=new(gossip.MessageImp)
    //msg.Bs=make([]byte,0)
    //msg.Bs = append(msg.Bs, cmsgbs...)
    //msg.Ttype=constdef.CONSENSUS
    //
    //return msg
//}

//TBC
//func (c *MyConsensus)queryMsg(sk *ecdsa.PrivateKey,pk *ecdsa.PublicKey) *gossip.MessageImp {
//    msg:=new(ConsensusMessage)
//    fmt.Fprintf(os.Stdout," query msg: Create msg\n")
//    if msg==nil {
//        fmt.Fprintf(os.Stdout," query msg nil\n")
//        //panic(err)
//    }
//    //c.blocklck.Lock()
//    // query
//
//    // BlockHash
//
//    // Prev
//
//
//    // count
//
//    //Msghash
//
//    // pk
//
//    // sig
//
//    //Count field TBC
//    msg.Count=0
//
//    msg.Pk=make([]byte, 0)
//    p:=crypt.EncodePk(pk)
//    fmt.Fprintf(os.Stdout," query msg: append Pk\n")
//    msg.Pk=append(msg.Pk, p...)
//
//    msg.Sig=make([]byte, 0)
//
//    msg.Data=make([]byte, 0)
//
//    // Error TBC
//    fmt.Fprintf(os.Stdout," query msg: append block hash\n")
//    msg.Data = append(msg.Data, c.choosed.Header.BlockHash...)
//
//    msg.Prev=make([]byte, 0)
//    fmt.Fprintf(os.Stdout," query msg: append prev hash\n")
//    msg.Prev=append(msg.Prev, c.prev...)
//
//    msg.Ttype=constdef.QUERY
//    msg.Resp=""
//    msg.SPk=make([]byte, 0)
//    fmt.Fprintf(os.Stdout," query msg: append pk\n")
//    msg.SPk=append(msg.SPk, p...)
//     
//    bs:=make([]byte,0)
//
//    fmt.Fprintf(os.Stdout," query msg: bs append data\n")
//    bs=append(bs, msg.Data...)
//
//    fmt.Fprintf(os.Stdout," query msg: bs append prev hash\n")
//    bs=append(bs, msg.Prev...)
//
//    fmt.Fprintf(os.Stdout," query msg: bs append msg.Type\n")
//    bs=append(bs, []byte(msg.Ttype)...)
//
//    fmt.Fprintf(os.Stdout," query msg: bs append resp\n")
//    bs=append(bs, []byte(msg.Resp)...)
//
//    fmt.Fprintf(os.Stdout," query msg: bs append pk\n")
//    bs=append(bs, msg.SPk...)
//
//    beta,proof,err:=ecvrf.P256Sha256Tai.Prove(sk,bs)
//    if err!=nil {
//        fmt.Fprintf(os.Stdout," query msg error1\n")
//        panic(err)
//    }
//    fmt.Fprintf(os.Stdout," query msg: append proof\n")
//    msg.Proof = append(msg.Proof, proof...)
//
//    fmt.Fprintf(os.Stdout," query msg: append proof sig\n")
//    msg.Sig= append(msg.Sig, beta...)
//    msg.NowID=c.choosed.Header.BlockHash
//    msg.Timestamp=time.Now().String()
//    //c.blocklck.Unlock()
//
//    gmsp:=new(gossip.MessageImp)
//    data,err:=msg.ToBytes()
//    if err!=nil {
//        fmt.Fprintf(os.Stdout," query msg error2\n")
//        panic(err)
//    }
//    gmsp.Bs=data
//    gmsp.Ttype=constdef.CONSENSUS
//    return gmsp
//}


//TBC
func (c *MyConsensus)queryMsg(count int, sk *ecdsa.PrivateKey,pk *ecdsa.PublicKey) *gossip.MessageImp {
    msg:=new(ConsensusMessage)
    //fmt.Fprintf(os.Stdout," query msg: Create msg\n")
    if msg==nil {
        fmt.Fprintf(os.Stdout,"index %v | Error to create a new query msg\n",c.Index)
        //panic(err)
    }
    //c.blocklck.Lock()
    // query
    msg.Ttype=constdef.QUERY

    // BlockHash
    if c.choosed==nil {
        panic("Empty choosed block")
    }
    msg.BlockHash=make([]byte, 0)
    msg.BlockHash=append(msg.BlockHash, c.choosed.Header.BlockHash...)

    // Prev
    msg.Prev=make([]byte, 0)
    //fmt.Fprintf(os.Stdout," query msg: append block hash\n")
    msg.Prev= append(msg.Prev, c.choosed.Header.Prev...)

    //Height
    msg.Height=c.choosed.Header.Height

    // count
    msg.Count=count

    //Msghash
    bs:=make([]byte,0)
    bs=append(bs, []byte(msg.Ttype)...)
    bs=append(bs, msg.Data...)
    bs=append(bs, msg.Prev...)
    hstr:=strconv.Itoa(msg.Height)
    cstr:=strconv.Itoa(msg.Count)
    bs=append(bs,[]byte(hstr)...)
    bs=append(bs,[]byte(cstr)...)
    h:=sha256.Sum256(bs)
    msg.MsgHash=make([]byte, 0)
    msg.MsgHash = append(msg.MsgHash, h[:]...)

    for k := range c.query {
        if 0== bytes.Compare([]byte(k),msg.MsgHash) {
            //fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | QueryBlock | Query to block hash %v,block height %v HAS BEEN MADE, Time: %v\n",c.Index,  c.choosed.Header.BlockHash, c.choosed.Header.Height, time.Now().String())
            return nil
        }
    }

    // pk
    pks:=[]byte(crypt.EncodePk(pk))
    msg.Pk=make([]byte, 0)
    msg.Pk=append(msg.Pk, pks...)

    // sig 
    beta,proof,err:=ecvrf.P256Sha256Tai.Prove(sk,bs)
    if err!=nil {
        fmt.Fprintf(os.Stdout," query msg error1\n")
        panic(err)
    }
    fmt.Fprintf(os.Stdout," query msg: append proof sig\n")
    msg.Sig= append(msg.Sig, beta...)

    fmt.Fprintf(os.Stdout," query msg: append proof\n")
    msg.Proof = append(msg.Proof, proof...)

    //c.blocklck.Unlock()

    gmsp:=new(gossip.MessageImp)
    data,err:=msg.ToBytes()
    if err!=nil {
        fmt.Fprintf(os.Stdout," query msg error2\n")
        panic(err)
    }
    gmsp.Bs=data
    gmsp.Info=string(msg.BlockHash)
    gmsp.Ttype=constdef.CONSENSUS
    return gmsp
}
