package consensus

import "crypto/ecdsa"

//func (c *MyConsensus) ReadSimulated(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	tricker := time.NewTicker(time.Duration(c.interval) * time.Second)
//	c.lcache.Lock()
//	defer c.lcache.Unlock()
//	for {
//		if c.timeout {
//			return
//		}
//		select {
//		case sim := <-c.simluated:
//			c.cache = append(c.cache, *sim)
//			l := len(c.cache)
//			if l == c.intraTxNum {
//				fmt.Fprintf(os.Stdout, " Consensus | Enough client transaction for intra block\n")
//				return
//			}
//		case <-tricker.C:
//			fmt.Fprintf(os.Stdout, " Consensus | Time up for waiting client Transaction\n")
//			return
//		}
//	}
//}

func (c *MyConsensus) SimulatedToIntraBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	ticker := time.NewTicker(time.Duration(c.interval) * time.Second)
//	for {
//		select {
//		case sim := <-c.simluated:
//			c.cache = append(c.cache, *sim)
//			l := len(c.cache)
//			if l == c.intraTxNum {
//				//	b := block.NewBlock(sk, pk, c.cache)
//				//	c.l.WriteABlock(b)
//				//	//block:=block.CreateBlock(cache,l)
//				prev := []byte("abc")
//				intra := block.NewIntraBlock(prev, c.cache)
//				intra.Complete(sk, pk)
//				if random.Select(intra.Hash, c.tao, c.n) {
//					gspmsg := intraToMessage(sk, pk, intra)
//					c.SendMsg <- gspmsg
//				}
//			}
//		case <-ticker.C:
//			//p
//			prev := []byte("abc")
//			intra := block.NewIntraBlock(prev, c.cache)
//			intra.Complete(sk, pk)
//			if Selected(intra.Hash, c.m, c.tao, c.n) {
//				gspmsg := intraToMessage(sk, pk, intra)
//				c.SendMsg <- gspmsg
//			}
//		}
//	}
}

//func (c *MyConsensus) TimeForNewIBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	c.corelock.Lock()
//	defer c.corelock.Lock()
//	c.choosed = c.IntraToBlock(sk, pk)
//	if c.choosed == nil {
//		return
//	}
//	fmt.Fprintf(os.Stdout, " Consensus | !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!New selected block %v\n", c.choosed.Header.BlockHash)
//	//b:=blockToGossipMsg(c.choosed)
//	//if bytes.Compare(c.choosed.Header.BlockHash,b.Header.BlockHash)!=0 {
//	//c.choosed=b
//	if len(c.change) == 0 {
//		c.change <- true
//	}
//	b := blockToGossipMsg(c.choosed)
//	c.SendMsg <- b
//	//}
//}

//func (c *MyConsensus) QueryBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	tricker := time.NewTicker(time.Duration(c.interval) * time.Second)
//	c.corelock.Lock()
//	defer c.corelock.Unlock()
//	c.choosed = c.IntraToBlock(sk, pk)
//	if c.choosed == nil {
//		fmt.Fprintf(os.Stdout, " Consensus | No client transation, Empty now \n")
//		return
//	}
//	// generate a new block
//	// broadcast the block
//	blockmsg := blockToGossipMsg(c.choosed)
//	c.SendMsg <- blockmsg
//	if c.isAMissingBlock(c.choosed.Header.BlockHash) {
//		c.waiting = append(c.waiting, c.choosed)
//	}
//	//fmt.Fprintf(os.Stdout, " Consensus | !!!!!!!!!!!!!!!!!!!!!!!!!New selected block %v\n", c.choosed.Header.BlockHash)
//	fmt.Fprintf(os.Stdout, " Consensus | Query new block %v\n", c.choosed.Header.BlockHash)
//
//	<-tricker.C
//
//	qmsg := c.queryMsg(sk, pk)
//	c.SendMsg <- qmsg
//	//fmt.Fprintf(os.Stdout,"Consensu | Now queryResult: %v\n",c.queryResult)
//	//c.queryResult = c.queryResult[:0]
//}

//func (c *MyConsensus) QueryBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	tricker := time.NewTicker(time.Duration(c.interval) * time.Second)
//	for {
//		select {
//		case <-c.change:
//			{
//				//
//				// when recv new intra, compute to a new Block
//				// restart the query of it
//				// recount the result of it
//				fmt.Fprintf(os.Stdout, " Consensus | Recv new block or intra-block\n")
//				c.qrl.Lock()
//				c.blocklck.Lock()
//				c.choosed = c.IntraToBlock(sk, pk)
//				fmt.Fprintf(os.Stdout, " Consensus | !!!!!!!!!!!!!!!!!!!!!!!!!New selected block %v\n", c.choosed.Header.BlockHash)
//				qmsg := c.queryMsg(sk, pk)
//				c.SendMsg <- qmsg
//				c.queryResult = c.queryResult[:0]
//
//				//if _,ok:=c.QueryMsg[string(c.choosed.Header)].Header.BlockHash
//				c.blocklck.Unlock()
//				c.qrl.Unlock()
//			}
//		case <-tricker.C:
//			fmt.Fprintf(os.Stdout, " Consensus | Time up to query iblock\n")
//			return
//		}
//	}
//}


//func (c *MyConsensus) ResponeQuery(iblock *block.IBlock, spk []byte, sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//func (c *MyConsensus) ResponeQuery(spk []byte, sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	for k, v := range c.QueryMsg {
//		if v == false {
//			var cmp int
//			if c.choosed == nil {
//				cmp = 1
//				panic("no new block")
//			}
//			cmp = bytes.Compare(c.choosed.Header.BlockHash, []byte(k))
//			if cmp != 0 {
//				noack := c.ackmsg(constdef.NOACK, c.choosed.Header.BlockHash, spk, sk, pk)
//				if noack != nil {
//					c.blocklck.Lock()
//					c.QueryMsg[string(k)] = true
//					c.blocklck.Unlock()
//					c.SendMsg <- noack
//				}
//			}
//			// existed block
//			// choosed
//			if cmp == 0 {
//				ack := c.ackmsg(constdef.ACK, []byte(k), spk, sk, pk)
//				if ack != nil {
//					c.blocklck.Lock()
//					c.QueryMsg[string(k)] = true
//					c.blocklck.Unlock()
//					c.SendMsg <- ack
//				}
//			}
//		} else {
//			panic("Error:already ack")
//		}
//	}
//}

//func (c *MyConsensus) ResponeQuery(iblock *block.IBlock, spk []byte, sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//func (c *MyConsensus) ResponeQuery(blockhash []byte, spk []byte, sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	fmt.Fprintf(os.Stdout, "Consensus | Recv Query, respone to it %v\n", string(blockhash))
//
//	hash := string(blockhash)
//	c.querymsglock.Lock()
//	_, ok := c.ifrespQueryMsg[hash]
//	if !ok {
//		c.ifrespQueryMsg[hash] = false
//	}
//	c.querymsglock.Unlock()
//
//	ismissing := c.isAMissingBlock(blockhash)
//	if ismissing {
//		gspmsg := missingmsg(blockhash)
//		c.SendMsg <- gspmsg
//		return
//	}
//
//	//already respone the this query
//	c.querymsglock.Lock()
//	if c.ifrespQueryMsg[hash] == true {
//		return
//	}
//	c.querymsglock.Unlock()
//
//	if c.choosed == nil {
//		if len(c.intraCache) != 0 {
//			c.corelock.Lock()
//			c.choosed = c.IntraToBlock(sk, pk)
//			c.corelock.Lock()
//		} else {
//			return
//		}
//	}
//	//cmp = 1
//	//	} else {
//	//		cmp = bytes.Compare(c.choosed.Header.BlockHash, blockhash)
//	//	}
//	// look back 5 committed block
//	cmp := bytes.Compare(c.choosed.Header.BlockHash, blockhash)
//	if cmp != 0 {
//		n := 5
//		l := len(c.commitblock)
//		for i := 1; i < n; i++ {
//            bhash:=c.commitblock[l-i].Header.BlockHash
//			cmp = bytes.Compare(bhash, blockhash)
//			//cmp = bytes.Compare([]byte(c.commitblock[l-i]), blockhash)
//			if cmp == 0 {
//				break
//			}
//		}
//	}
//	// missing this block
//	// existed block
//	// and no choosed
//	if cmp != 0 {
//		noack := c.ackmsg(constdef.NOACK, c.choosed.Header.BlockHash, spk, sk, pk)
//		if noack != nil {
//			c.querymsglock.Lock()
//			c.ifrespQueryMsg[hash] = true
//			c.querymsglock.Unlock()
//			c.SendMsg <- noack
//		}
//	}
//	// existed block
//	// choosed
//	if cmp == 0 {
//		ack := c.ackmsg(constdef.ACK, blockhash, spk, sk, pk)
//		if ack != nil {
//			c.querymsglock.Lock()
//			c.ifrespQueryMsg[hash] = true
//			c.querymsglock.Unlock()
//			c.SendMsg <- ack
//		}
//	}
//}
