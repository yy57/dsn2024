package consensus

type Consensus interface {
    Serve()
}


