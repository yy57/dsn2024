package consensus

//
//func (c *Consensus) POS() {
//
//}
