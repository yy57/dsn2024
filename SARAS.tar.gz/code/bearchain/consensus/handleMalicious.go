package consensus

import (
	"bearchain/block"
	"bearchain/constdef"
	"bearchain/gossip"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
)

func (c *MyConsensus)SendMalicious(){
    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Recv malicious node.!!!!!!!!!!\n",c.Index )
    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Release lock, Time: %v\n",c.Index,  time.Now().String())

    mMsg:=new(MaliciousMsg)
    mMsg.Pk=string(c.choosed.Header.Pk)
    mMsg.Header=make([]block.Header, 0)
    bs:=make([]byte,0)
    bs=append(bs, []byte(mMsg.Pk)...)
    for _,v:=range c.blockcache {
        mMsg.Header=append(mMsg.Header, v.Header)
        h,err:=json.Marshal(v.Header)
        if err!=nil {
            panic(" MaliciousMsg | Fail to mashal msg")
        }
        bs=append(bs, h...)
    }
    hash:=sha256.Sum256(bs)
    mMsg.MsgHash=make([]byte, 0)
    mMsg.MsgHash = append(mMsg.MsgHash, hash[:]...)
    msg:=new(gossip.MessageImp)
    msg.Bs=make([]byte, 0)
    msg.Bs = append(msg.Bs, mMsg.ToBytes()...)
    msg.Ttype=constdef.MILICIOUS
    c.SendMsg<-msg
}

func (c *MyConsensus)RecvMalicious(){

}
