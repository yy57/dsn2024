package consensus

import (
	"bearchain/gossip"
	"crypto/ecdsa"
	"os"
)

//type MyConsensus struct {
//	lck     sync.Mutex
//	errchan chan<- error
//	RecvMsg <-chan *gossip.MessageImp
//	SendMsg chan<- *gossip.MessageImp
//	//client_tx <-chan block.Transaction
//	exe_tx chan block.TxResult
//
//	sc_handler *contract.Contract
//
//	l  *ledger.Ledger
//	lc *ledgercache.Cache
//
//    isbootstrap bool
//    proposerlck sync.Mutex
//    propserlist []string //proposer for to-be-committed block
//    propsercache []*block.Proposer
//    newpropser []string //propser in future
//    propserElection chan []byte
//
//
//	// para for tx to intrablock
//	// and intra to  block
//	// query block
//	simluated chan *block.Simulated // simulate of a tx
//	cache     []block.Simulated     // tx simulate cache
//	lcache    sync.Mutex
//
//	interval       int
//	timeupForintra chan bool
//	intraTxNum     int
//	intraBlockSize int
//	waitingtime    int // waiting time for Query block
//	timeupForQuery chan bool
//
//
//
//    newToBeCIntra chan bool
//    intraCacheLock sync.Mutex
//	intraCache  []*block.IntraBlock  //cache of to-be-committed intrablock for block
//    waitingIntra map[string]*block.IntraBlock //cache of intrablock for new block
//
//    newToBeCBlock chan bool
//    blockcache []*block.Block //cache of to-be-committed block
//    waitingblock map[string]*block.Block // cache of new block
//    choosedlock sync.Mutex
//	choosed     *block.Block
//    blockcachelock sync.Mutex
//
//    newToBeCBlock2 chan *block.Block
//    blockquerychan chan *block.Block
//    blockresponechan chan *block.Block
//
//	commitblock []*block.Block
//	commitintra []*block.IntraBlock
//    commitchan chan bool
//    updateQueryList chan bool
//
//	// para intra to block
//	corelock sync.Mutex
//	//	querylock  sync.Mutex
//	queryflag   bool
//	//choosed     *block.Block
//	newintra    bool
//	myintrac    *block.IntraBlock
//	waiting     []*block.Block     //cache of Block
//	//commitblock []*block.Block
//	//commitintra []*block.IntraBlock
//	oldintra    []*block.IntraBlock //not used
//	laterintra  []*block.IntraBlock
//
//	oldblock   []*block.Block //not used
//	laterblock []*block.Block
//	//commitblock []string
//	//commitintra []string
//	prev  []byte
//	stati []time.Time
//
//	//first time.Time
//	//first count
//	//end time.Time
//
//	//queryResult map[string][]bool
//	//queryResult map[string][]bool
//
//	//recved query message
//	// map  prev id to
//	// different succeed
//	//query map[string][]string//recved qeury message
//	query   map[string]*query //recved qeury message
//	querymsglock   sync.Mutex
//
//	timeout bool
//
//	//result []*result //recved respone
//    resultlock sync.Mutex
//	result map[string]*result //recved respone
//    resultcache map[string]*result
//	//result map[]
//	qrl sync.Mutex
//
//	ifrespQueryMsg map[string]bool
//	respQeuryCache []string
//	//	blocklck   sync.Mutex
//	change chan bool
//	//queryblock *block.Block
//	//change bool//once the choosed block changed, restart the query operations
//	//waiting []*block.Block
//	//waitingIntraBlock []*block.IntraBlock
//	//	qrl         sync.Mutex
//
//	waittime int
//
//	tao     float64 //intra selecter ratio
//	taonode float64 // node selected ratio
//	m       int
//	n       int
//
//	thres float64
//
//	cblock int
//	cintra int
//	ctx    int
//
//    txnum int
//
//	committed     bool
//	committedlock sync.Mutex
//}

func (c *MyConsensus) GenerateMyintra(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	tricker := time.NewTicker(time.Duration(c.interval) * time.Second)
//    go c.ReadSimulated(sk,pk)
//	for {
//        <-tricker.C
//		l := len(c.cache)
//        if l == 0 {
//            continue
//        }
//        <-c.commitchan
//		c.lcache.Lock()
//		//l := len(c.cache)
//        var intra *block.IntraBlock
//        if l > c.intraTxNum {
//            intra = block.NewIntraBlock(c.prev, c.cache[:c.intraTxNum])
//		    intra.Complete(sk, pk)
//		    c.cache = c.cache[c.intraTxNum:]
//        } else {
//            intra = block.NewIntraBlock(c.prev, c.cache)
//		    intra.Complete(sk, pk)
//		    c.cache = c.cache[l:]
//        }
//		fmt.Fprintf(os.Stdout, " Consensu | New intra block hash: %v\n", intra.Hash)
//		c.lcache.Unlock()
//
//        msg:=intraToMessage(sk,pk,intra)
//        fmt.Fprintf(os.Stdout," CONSENSUS | send intra\n")
//        c.SendMsg<-msg
//
//        c.intraCacheLock.Lock()
//        if len(c.newToBeCIntra)==0 {
//            c.newToBeCIntra<-true
//        }
//        c.intraCache=append(c.intraCache, intra)
//        c.intraCacheLock.Unlock()
//	}
}

func (c *MyConsensus) IntraToBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
	//TBC
	// When build a new block
	// update the ledger cache which will be write the the ledger
//    tricker:=time.NewTicker(time.Duration(c.interval)*time.Millisecond)
//    for {
//        <-tricker.C
//        <-c.newToBeCIntra
//
//        c.intraCacheLock.Lock()
//	    if len(c.intraCache) == 0 {
//            c.intraCacheLock.Unlock()
//            continue
//		    //return c.choosed
//	    }
//	    fmt.Fprintf(os.Stdout, " Consensus | sort intra\n")
//	    var cache intraCache
//	    cache = c.intraCache
//	    sort.Sort(cache)
//	    c.intraCache = cache
//	    b, err := block.NewBlock(sk, pk, c.prev, c.intraCache)
//	    if err != nil {
//		    panic(err)
//	    }
//
//        c.choosedlock.Lock()
//        c.choosed=b
//        c.choosedlock.Unlock()
//
//        c.blockquerychan<-b
//        //c.blockresponechan<-b
//        //c.newToBeCBlock<-true
//        c.intraCacheLock.Unlock()
//    }
}

//func (c *MyConsensus) SumQueryResult(file *os.File) {
//	fmt.Fprintf(os.Stdout, "-------------------------------Summary Query!!!!\n")
//	c.corelock.Lock()
//	defer c.corelock.Unlock()
//	ack := 0
//	if c.choosed == nil {
//		fmt.Fprintf(os.Stdout, " Consensus | task empty\n")
//		return
//		//panic("Error choosed")
//	}
//	l := len(c.result)
//    //if l<60 {
//	//	c.timeout = true
//    //    return
//    //}
//	for _, v := range c.result {
//		if v.ack == true {
//			ack = ack + 1
//		}
//	}
//	if float64(ack)/float64(l) >= c.thres {
//		//c.Commit()
//		fmt.Fprintf(os.Stdout, "-------------------------------Success!!!!!!the choosed block %v ack!!!\n", c.choosed.Header.BlockHash)
//		c.commitblock = append(c.commitblock, c.choosed)
//		c.cblock = c.cblock + 1
//		//c.commitblock = append(c.commitblock, string(c.choosed.Header.BlockHash))
//		c.prev = c.choosed.Header.BlockHash
//		for _, intra := range c.choosed.IntraBlock {
//			c.commitintra = append(c.commitintra, &intra)
//			c.cintra = c.cintra + 1
//			c.ctx = c.ctx + len(intra.Txs)
//		}
//		//	var tmp []*block.IntraBlock
//		//	for _, v := range c.intraCache {
//		//		if !c.isCommitIntra(v.Hash) {
//		//			tmp = append(tmp, v)
//		//		}
//		//	}
//		//	c.intraCache = tmp
//		fmt.Fprintf(os.Stdout, " Consensus | commit %d block / %d intra / %d tran\n", c.cblock, c.cintra, c.ctx)
//
//		c.waiting = c.waiting[:0]
//		c.intraCache = c.intraCache[:0]
//		c.choosed = nil
//		c.timeout = false
//		c.committedlock.Lock()
//		c.committed = true
//		c.committedlock.Unlock()
//		//static:=time.Now()
//		w := bufio.NewWriter(file)
//		now := time.Now().String()
//		w.WriteString(now)
//		w.WriteString("\n")
//		w.WriteString("commitblock: " + strconv.Itoa(c.cblock) + " commit intra: " + strconv.Itoa(c.cintra) + " committed tx: " + strconv.Itoa(c.ctx))
//		w.WriteString("\n")
//		w.Flush()
//		//c.stati=append(c.stati,time.Now())
//	} else {
//		c.timeout = true
//		return
//	}
//}

//func (c *MyConsensus) SumQueryResult() {
//	fmt.Fprintf(os.Stdout, "-------------------------------Summary Query!!!!\n")
//	c.corelock.Lock()
//	defer c.corelock.Unlock()
//	ack := 0
//	if c.choosed == nil {
//		fmt.Fprintf(os.Stdout, " Consensus | task empty\n")
//		return
//		//panic("Error choosed")
//	}
//	//l := len(c.queryResult)
//	r := c.queryResult[string(c.choosed.Header.BlockHash)]
//	if r == nil {
//		fmt.Fprintf(os.Stdout, "Fail to accept block%v\n", string(c.choosed.Header.BlockHash))
//		return
//	}
//	l := len(r)
//	for _, v := range r {
//		if v == true {
//			ack = ack + 1
//		}
//	}
//	if float64(ack)/float64(l) >= c.thres {
//		//c.Commit()
//		fmt.Fprintf(os.Stdout, "-------------------------------Success!!!!!!the choosed block %v ack!!!\n", c.choosed.Header.BlockHash)
//		c.commitblock = append(c.commitblock, c.choosed)
//        c.cblock=c.cblock+1
//		//c.commitblock = append(c.commitblock, string(c.choosed.Header.BlockHash))
//		c.prev = c.choosed.Header.BlockHash
//		for _, intra := range c.choosed.IntraBlock {
//			c.commitintra = append(c.commitintra, &intra)
//            c.cintra=c.cintra+1
//            c.ctx=c.ctx+len(intra.Txs)
//		}
//		var tmp []*block.IntraBlock
//		for _, v := range c.intraCache {
//			if !c.isCommitIntra(v.Hash) {
//				tmp = append(tmp, v)
//			}
//		}
//		c.intraCache = tmp
//        fmt.Fprintf(os.Stdout," Consensus | commit %d block / %d intra / %d tran\n",c.cblock,c.cintra,c.ctx)
//		//c.waiting=c.waiting[:0]
//		//c.queryResult
//	}
//	//empty cache
//	c.waiting = c.waiting[:0]
//	c.intraCache = c.intraCache[:0]
//	c.choosed = nil
//	for k := range c.queryResult {
//		delete(c.queryResult, k)
//	}
//}

//
// function to process Consensus message
//func (c *MyConsensus) ProcessConsensusMsg(bs []byte, sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	// first verify the sig of consensus message
//	c.corelock.Lock()
//	defer c.corelock.Unlock()
//	cmsg := new(ConsensusMessage)
//	err := json.Unmarshal(bs, cmsg)
//	if err != nil {
//		return
//	}
//	ok := cmsg.Verify()
//	spk := cmsg.SPk
//	if !ok {
//		fmt.Fprintf(os.Stdout, " ERROR | Failed to verify consensus messge\n")
//		return
//	}
//	blockhash := cmsg.Data
//
//	// second
//	// verify if respone to this msg ever
//	// else {
//	//     return
//	// }
//
//	// Respone Query message
//	if cmsg.Ttype == constdef.QUERY {
//		if _, ok := c.ifrespQueryMsg[string(blockhash)]; !ok {
//			c.ifrespQueryMsg[string(blockhash)] = false
//		}
//		if c.ifrespQueryMsg[string(blockhash)] == true {
//			return
//		}
//		// recv a commit block
//		// respone ack
//		if c.isACommitBlock(blockhash) {
//			ack := c.ackmsg(constdef.ACK, blockhash, spk, sk, pk)
//			if ack == nil {
//				panic("run out of memory")
//			}
//			c.ifrespQueryMsg[string(blockhash)] = true
//			c.SendMsg <- ack
//			return
//		}
//		// missing block
//		// send missing message
//		if c.isAMissingBlock(blockhash) {
//			gspmsg := missingmsg(blockhash)
//			c.SendMsg <- gspmsg
//			return
//		}
//		if c.choosed == nil {
//			if len(c.intraCache) != 0 {
//				c.choosed = c.IntraToBlock(sk, pk)
//			}
//		}
//		cmp := bytes.Compare(c.choosed.Header.BlockHash, blockhash)
//		if cmp != 0 {
//			noack := c.ackmsg(constdef.NOACK, c.choosed.Header.BlockHash, spk, sk, pk)
//			if noack == nil {
//				panic("run out of memory")
//			}
//			c.ifrespQueryMsg[string(blockhash)] = true
//			c.SendMsg <- noack
//		}
//		if cmp == 0 {
//			ack := c.ackmsg(constdef.ACK, blockhash, spk, sk, pk)
//			if ack == nil {
//				panic("run out of memory")
//			}
//			c.ifrespQueryMsg[string(blockhash)] = true
//			c.SendMsg <- ack
//		}
//	}
//
//	// Respone respone message
//	if cmsg.Ttype == constdef.RESPONE {
//		fmt.Fprintf(os.Stdout, " Consensus | Recv Respone Msg %v\n", string(blockhash))
//		ack := cmsg.Resp
//		if c.queryResult[string(blockhash)] == nil {
//			c.queryResult[string(blockhash)] = make([]bool, 0, 500)
//		}
//		if ack == constdef.ACK {
//			c.queryResult[string(blockhash)] = append(c.queryResult[string(blockhash)], true)
//		} else if ack == constdef.NOACK {
//			c.queryResult[string(blockhash)] = append(c.queryResult[string(blockhash)], false)
//		}
//	}
//
//	//	//	iblock := new(block.Block)
//	//	//	err = json.Unmarshal(cmsg.Data, iblock)
//	//	//	if err != nil {
//	//	//		return
//	//	//	}
//	//    if c.isACommitBlock(blockhash) {
//	//        return
//	//    }
//	//	ismissing := c.isAMissingBlock(blockhash)
//	//	if ismissing {
//	//		missing := missingmsg(blockhash)
//	//		c.SendMsg <- missing
//	//		return
//	//	}
//	//	if cmsg.Ttype == constdef.QUERY {
//	//		//go c.SaveQuery(blockhash, spk, sk, pk)
//	//		c.ResponeQuery(blockhash, spk, sk, pk)
//	//	}
//	//	if cmsg.Ttype == constdef.RESPONE {
//	//		fmt.Fprintf(os.Stdout, " Consensus | Recv Respone Msg %v\n", string(blockhash))
//	//		if ismissing {
//	//			return
//	//		}
//	//		//pkcmp := bytes.Compare(cmsg.SPk, []byte(crypt.EncodePk(pk)))
//	//		ack := cmsg.Resp
//	//		cmp:= bytes.Compare(cmsg.Data, c.choosed.Header.BlockHash)
//	//		// some node respone to this block
//	//		if cmp== 0 {
//	//			c.corelock.Lock()
//	//            defer c.corelock.Unlock()
//	//            if c.queryResult[string(blockhash)]==nil {
//	//                c.queryResult[string(blockhash)]=make([]bool,0)
//	//            }
//	//			if ack == constdef.ACK {
//	//                c.queryResult[string(blockhash)] = append(c.queryResult[string(blockhash)], true)
//	//                fmt.Fprintf(os.Stdout,"Consensus | query")
//	//            } else if ack==constdef.NOACK {
//	//                c.queryResult[string(blockhash)] = append(c.queryResult[string(blockhash)],false)
//	//            }
//	//		}
//	//	}
//}

func (c *MyConsensus) BFT(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	for k, v := range c.ifrespQueryMsg {
//		// recv a query messae
//		// we have not respone
//		if v == false {
//			// miss this block
//			if c.isAMissingBlock([]byte(k)) {
//				// ask for this block
//				msg := missingmsg([]byte(k))
//				c.SendMsg <- msg
//			}
//		}
//	}
}

//func (c *MyConsensus) Core(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	tricker := time.NewTicker(time.Duration(c.interval) * time.Second)
//	//defer tricker.Stop()
//	i := 0
//	for {
//		i = i + 1
//		//fmt.Fprintf(os.Stdout, "----------time up to generate a new intra block time %d\n", i)
//		// 1. read simulated tx to intra
//		c.ReadSimulated(sk, pk)
//		//<-tricker.C
//		//	fmt.Fprintf(os.Stdout, "----------time up to generate a new intra block time %d\n", i)
//		//c.timeupForintra <- true
//		//		// after simulated tx to intra
//		//		// clean simulated cache
//		fmt.Fprintf(os.Stdout, " Consensu | compute intra to block\n")
//
//		var intra *block.IntraBlock
//		intra = nil
//		c.lcache.Lock()
//		l := len(c.cache)
//		if l != 0 {
//			intra = block.NewIntraBlock(c.prev, c.cache)
//			intra.Complete(sk, pk)
//			c.cache = c.cache[l:]
//			fmt.Fprintf(os.Stdout, " Consensu | New intra block hash: %v\n", intra.Hash)
//		}
//		c.lcache.Unlock()
//
//		// 2. check if intra block is selected
//		if intra != nil {
//			ok := random.Select(intra.Hash, c.tao, c.m, c.n)
//			if ok {
//				c.corelock.Lock()
//				c.intraCache = append(c.intraCache, intra)
//				if len(c.change) == 0 {
//					c.change <- true
//				}
//				c.corelock.Unlock()
//				imsg := intraToMessage(sk, pk, intra)
//				c.SendMsg <- imsg
//			}
//		}
//		//go c.QueryBlock(sk,pk)
//
//		// 3. time for query a new Iblock
//		<-tricker.C
//		fmt.Fprintf(os.Stdout, " Consensus | Time up for waiting intra block \n")
//		//fmt.Fprintf(os.Stdout, "Time for intra block %v\n", intra)
//		//c.TimeForNewBlock(sk, pk)
//		//fmt.Fprintf(os.Stdout, " Consensus | Query new block %s\n", c.choosed.Header.BlockHash)
//		fmt.Fprintf(os.Stdout, " Consensus | Query new block\n")
//		c.QueryBlock(sk, pk)
//		fmt.Fprintf(os.Stdout, " Consensus | Waiting a time then Respone query\n")
//		<-tricker.C
//		// process BFT situation
//		fmt.Fprintf(os.Stdout, " Consensus | Waiting a time for BFT situation\n")
//		//c.BFT(sk, pk)
//		//<-tricker.C
//		c.QueryBlock(sk, pk)
//		//c.ResponeQuery(nil, sk, pk)
//		<-tricker.C
//		c.SumQueryResult()
//
//		//c.timeupForQuery <- true
//		//c.Commit()
//	}
//}

func (c *MyConsensus) BuildBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	tricker := time.NewTicker(time.Duration(c.interval) * time.Second)
//	//var last []byte
//	for {
//		select {
//		case <-tricker.C:
//			c.corelock.Lock()
//			c.choosed = c.IntraToBlock(sk, pk)
//			//if
//			c.corelock.Unlock()
//		}
//	}
}

func (c *MyConsensus) StaticFileClose(file *os.File) {
//	defer file.Close()
//	w := bufio.NewWriter(file)
//	for _, v := range c.stati {
//		s := v.String()
//		w.WriteString(s)
//		w.WriteString("\n")
//		w.Flush()
//		//write to file
//		//TBC
//	}
	//w.Flush()
}

func (c *MyConsensus) Core(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	path := "./static"
//	file, err := os.OpenFile("./static", os.O_CREATE|os.O_WRONLY|os.O_TRUNC|os.O_APPEND, 0660)
//	if os.IsNotExist(err) {
//		fmt.Fprintf(os.Stdout, " Error | fail to open %s infofile, create it\n", path)
//		file, err = os.OpenFile("./static", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0660)
//		if err != nil {
//			panic("fail to open file")
//			//return nil, fmt.Errorf("Error:\t fail to open or create %s infofile\n", path)
//		}
//	}
//	//defer c.StaticFileClose(file)
//	defer file.Close()
//    //var last []byte
//    //last:=[]byte("")
//
//    //tricker := time.NewTicker(time.Duration(c.interval) * time.Second)
//	tricker := time.NewTicker(time.Duration(c.interval*100) * time.Millisecond)
//	go c.UpdateQueryList()
//	//defer tricker.Stop()
//	for {
//		//fmt.Fprintf(os.Stdout, "----------time up to generate a new intra block time %d\n", i)
//		// 1. read simulated tx to intra
//		//c.Respone(sk,pk)
//		c.ReadSimulated(sk, pk)
//		//<-tricker.C
//		//	fmt.Fprintf(os.Stdout, "----------time up to generate a new intra block time %d\n", i)
//		//c.timeupForintra <- true
//		//		// after simulated tx to intra
//		//		// clean simulated cache
//		//fmt.Fprintf(os.Stdout, " Consensu | compute intra to block\n")
//
//		var intra *block.IntraBlock
//		intra = nil
//		c.lcache.Lock()
//		if !c.timeout {
//			l := len(c.cache)
//			if l != 0 {
//				intra = block.NewIntraBlock(c.prev, c.cache)
//				intra.Complete(sk, pk)
//				c.cache = c.cache[l:]
//				fmt.Fprintf(os.Stdout, " Consensu | New intra block hash: %v\n", intra.Hash)
//			}
//		}
//		c.lcache.Unlock()
//
//		// 2. check if intra block is selected
//		if intra != nil {
//			ok := random.Select(intra.Hash, c.tao, c.n)
//			if ok {
//				c.corelock.Lock()
//				//if c.intraCache
//				c.intraCache = append(c.intraCache, intra)
//				if len(c.change) == 0 {
//					c.change <- true
//				}
//				c.corelock.Unlock()
//				imsg := intraToMessage(sk, pk, intra)
//				c.SendMsg <- imsg
//				//<-tricker.C
//				//<-tricker.C
//				<-tricker.C
//			}
//		}
//		//go c.QueryBlock(sk,pk)
//
//		// 3. time for recv block or intra
//		// and query
//		//<-tricker.C
//		//<-tricker.C
//		//<-tricker.C
//		//<-tricker.C
//		c.corelock.Lock()
//		//c.choosed = c.IntraToBlock(sk, pk)
//		if c.choosed == nil {
//			fmt.Fprintf(os.Stdout, " Consensus | No client transation, Empty now \n")
//			c.corelock.Unlock()
//			continue
//		}
//		if c.isAMissingBlock(c.choosed.Header.BlockHash) {
//			c.waiting = append(c.waiting, c.choosed)
//		}
//       // if bytes.Compare(last,c.choosed.Header.BlockHash)!=0 {
//       //     last=c.choosed.Header.BlockHash
//       //     qmsg := c.queryMsg(sk, pk)
//	   //     c.SendMsg <- qmsg
//       // }
//        //last=c.choosed.Header.BlockHash
//        qmsg := c.queryMsg(sk, pk)
//		c.SendMsg <- qmsg
//		//c.Respone(sk,pk)
//		c.corelock.Unlock()
//
//		<-tricker.C
//		//		<-tricker.C
//		//		<-tricker.C
//		//		<-tricker.C
//		c.Respone(sk, pk)
//
//		fmt.Fprintf(os.Stdout, " Consensus | Time for summay \n")
//		//<-tricker.C
//		<-tricker.C
//		//c.SumQueryResult(file)
//	}
}

func (c *MyConsensus) SaveQuery(blockhash []byte, spk []byte, sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	hash := string(blockhash)
//	c.querymsglock.Lock()
//	_, ok := c.ifrespQueryMsg[hash]
//	if !ok {
//		c.ifrespQueryMsg[string(hash)] = false
//	}
//	c.querymsglock.Unlock()
}

func (c *MyConsensus) BroadcastBlock(msg *gossip.MessageImp) {
//	hash := msg.Bs
//	// If we have block
//	c.corelock.Lock()
//	defer c.corelock.Unlock()
//	for _, v := range c.waiting {
//		if bytes.Compare(v.Header.BlockHash, hash) == 0 {
//			bmsg := blockToGossipMsg(v)
//			c.SendMsg <- bmsg
//			return
//		}
//	}
//	// we don't hash block
//	// route this message
//	c.SendMsg <- msg
	//block:=c.waiting
}

func (c *MyConsensus) RecvIntra(bs []byte) {
//    fmt.Fprintf(os.Stdout,"Consensus | Recv new Intra block: %v\n",string(bs))
//	intra := new(block.IntraBlock)
//	err := json.Unmarshal(bs, intra)
//	if err != nil {
//		c.errchan <- err
//	}
//
//	// verify intra-block vrf sig
//	if !intra.VerifyProof() {
//		return
//	}
//    // committed intra 
//    if c.isCommitIntra(intra.Hash) {
//        return 
//    }
//    //  later intra
//    if bytes.Compare(intra.Prev,c.prev) != 0 && !c.ExistLaterIntra(intra.Hash)  {
//        c.waitingIntra[string(intra.Hash)]=intra
//        //c.laterintra= append(c.laterintra, intra)
//        return
//    }
//
//    // intraCache exist
//    c.intraCacheLock.Lock()
//    defer c.intraCacheLock.Unlock()
//    if !c.isMissingIntra(intra.Hash) {
//		return
//    }
//	// intra pass all test
//	// meaning we need to update the to-be-queried iblock
//	fmt.Fprintf(os.Stdout, " Consensus | ---------------Recv new to-be-committed intra \n")
//	if len(c.newToBeCIntra) == 0 {
//		c.newToBeCIntra<- true
//	}
//	c.intraCache = append(c.intraCache, intra)
//    //c.New
}


//func (c *MyConsensus) RecvIntra(bs []byte) {
//    c.corelock.Lock()
//    defer c.corelock.Unlock()
//    fmt.Fprintf(os.Stdout,"Consensus | Recv new Intra block: %v\n",string(bs))
//	intra := new(block.IntraBlock)
//	err := json.Unmarshal(bs, intra)
//	if err != nil {
//		c.errchan <- err
//	}
//
//	// verify intra-block vrf sig
//    // intraCache exist
//    if !c.isMissingIntra(intra.Hash) {
//		return
//    }
//    // committed intra exist
//    if c.isCommitIntra(intra.Hash) {
//        return
//    }
//    //
//    if bytes.Compare(intra.Prev,c.prev) != 0 && !c.ExistLaterIntra(intra.Hash)  {
//        c.laterintra= append(c.laterintra, intra)
//        return
//    }
//	if !intra.VerifyProof() {
//		return
//	}
//	// verify if intra-block is selected
//	if !random.Select(intra.Hash, c.tao, c.n) {
//		return
//	}
//
//	// intra pass all test
//	// meaning we need to update the to-be-queried iblock
//	fmt.Fprintf(os.Stdout, " Consensus | ---------------Recv new intra \n")
//	c.newintra = true
//
//	// tell query process recv new intra
//	// if c.change!=0
//	// means there has been new intra to be deal with by query process
//	if len(c.change) == 0 {
//		c.change <- true
//	}
//	c.intraCache = append(c.intraCache, intra)
//    //c.New
//}
//Recv Message
//func (c *MyConsensus)RecvMissingBlock(bs []byte,sk *ecdsa.PrivateKey,pk *ecdsa.PublicKey) {
//    // verfiy intra block msg sig
//    missingblock:=new(block.IBlock)
//    err:=json.Unmarshal(bs,missingblock)
//    if err!=nil {
//        panic(err)
//    }
//    ok:=missingblock.Verify()
//    if ok {
//        c.UpdateIBlockCache(missingblock,sk,pk)
//    }
//}
//func (c *MyConsensus) RecvBlock(bs []byte, sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//    c.corelock.Lock()
//    defer c.corelock.Unlock()
//    fmt.Fprintf(os.Stdout,"Consensus | Recv new block: %v\n",string(bs))
//	iblock := new(block.IBlock)
//	err := json.Unmarshal(bs, iblock)
//	if err != nil {
//		panic(err)
//	}
//	if !iblock.Verify() {
//		return
//	}
//    // is a committed block
//    if c.isACommitBlock(iblock.Header.BlockHash) {
//        return
//    }
//    // is a new block
//    if bytes.Compare(iblock.Header.Prev,c.prev) != 0  && !c.ExistALaterBlock(iblock.Header.BlockHash){
//        c.laterblock= append(c.laterblock,iblock)
//        return
//    }
//    c.blockcachelock.Lock()
//    defer c.blockcachelock.Unlock()
//	if !c.isAMissingBlock(iblock.Header.BlockHash) {
//		return
//	}
//    c.waitingblock[string(iblock.Header.BlockHash)]=iblock
//    //c.waiting=append(c.waiting, iblock)
//    c.intraCacheLock.Lock()
//    defer c.intraCacheLock.Unlock()
//	intras := iblock.IntraBlock
//	//cache:=make([]block.IntraBlock,0)
//	for _, v := range intras {
//		if c.isMissingIntra(v.Hash) {
//			c.intraCache = append(c.intraCache, &v)
//			c.newintra = true
//			if len(c.newToBeCIntra) == 0 {
//				c.newToBeCIntra<- true
//			}
//		}
//	}
//}

//func (c *MyConsensus) isCommitIntra(hash []byte) bool {
//	for _, val := range c.commitintra{
//		cmp := bytes.Compare(val.Hash, hash)
//		//cmp := bytes.Compare([]byte(val), hash)
//		if cmp == 0 {
//			return true
//		}
//	}
////.    if cmp:=bytes.Compare(byte[]("start"),hash);cmp==0 {
////.
////.    }
//	return false
//}
//
//func (c *MyConsensus) ExistLaterIntra(hash []byte) bool {
//	for _, val := range c.laterintra{
//		cmp := bytes.Compare(val.Hash, hash)
//		if cmp == 0 {
//			return false
//		}
//	}
//	return true
//}
//
//func (c *MyConsensus) isMissingIntra(hash []byte) bool {
//	for _, val := range c.intraCache{
//		cmp := bytes.Compare(val.Hash, hash)
//		if cmp == 0 {
//			return false
//		}
//	}
//	return true
//}
//func (c *MyConsensus)UpdateIntraCache(iblock *block.IBlock) {
//    intras:=iblock.IntraBlock
//    //cache:=make([]block.IntraBlock,0)
//    for _,v:=range intras {
//        if c.isMissingIntra(v.Hash) {
//            //c.lck.Lock()
//            c.intraCache=append(c.intraCache,v)
//            //c.lck.Unlock()
//        }
//    }
//}

// Recv New IBlock
// update intra cache
// updata block cache
// and update choosed block for query
//func (c *MyConsensus)UpdateIBlockCache(iblock *block.IBlock,sk *ecdsa.PrivateKey,pk *ecdsa.PublicKey) {
//    if c.isAMissingBlock(iblock.Header.BlockHash) {
//        c.blocklck.Lock()
//        c.waiting=append(c.waiting, iblock)
//        c.UpdateIntraCache(iblock)
//        c.choosed=c.IntraToBlock(sk,pk)
//        c.change<-true
//        c.blocklck.Unlock()
//    }
//}
////func (c *MyConsensus) SumQueryResult(file *os.File) {
//func (c *MyConsensus) SumQueryResult(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
// 	path := "./static"
//	file, err := os.OpenFile("./static", os.O_CREATE|os.O_WRONLY|os.O_TRUNC|os.O_APPEND, 0660)
//	if os.IsNotExist(err) {
//		fmt.Fprintf(os.Stdout, " Error | fail to open %s infofile, create it\n", path)
//		file, err = os.OpenFile("./static", os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0660)
//		if err != nil {
//			panic("fail to open file")
//		}
//	}
//	defer file.Close()
//
//    tricker := time.NewTicker(time.Duration(c.interval)*100*time.Millisecond)
//    for {
//        <-tricker.C
//	    fmt.Fprintf(os.Stdout, " CONSENSUS | -------------------------------Summary Query!!!!\n")
//	    ack := 0
//	    if c.choosed == nil {
//		    fmt.Fprintf(os.Stdout, " Consensus | task empty\n")
//            c.timeout=false
//            continue
//	    }
//	    l := len(c.result)
//	    for _, v := range c.result {
//            if bytes.Compare(c.choosed.Header.Prev,v.prev)==0 {
//                if v.ack == true {
//			        ack = ack + 1
//		        }
//            }
//	    }
//    	if float64(ack)/float64(l) >= c.thres {
//		//c.Commit()
//		    fmt.Fprintf(os.Stdout, " CONSENSUS | -------------------------------Success!!!!!!the choosed block %v ack!!!\n", c.choosed.Header.BlockHash)
//		    c.commitblock = append(c.commitblock, c.choosed)
//		    c.cblock = c.cblock + 1
//		//c.commitblock = append(c.commitblock, string(c.choosed.Header.BlockHash))
//		    c.prev = c.choosed.Header.BlockHash
//		    for _, intra := range c.choosed.IntraBlock {
//			    c.commitintra = append(c.commitintra, &intra)
//			    c.cintra = c.cintra + 1
//		        c.ctx = c.ctx + len(intra.Txs)
//		    }
//		    fmt.Fprintf(os.Stdout, " Consensus | commit %d block / %d intra / %d tran\n", c.cblock, c.cintra, c.ctx)
//            
//
//            c.intraCacheLock.Lock()
//		    c.intraCache = c.intraCache[:0]
//            for k,v:= range c.waitingIntra  {
//                if bytes.Compare(v.Prev,c.prev)==0 {
//                    c.intraCache=append(c.intraCache, v)
//                    delete(c.waitingIntra,k)
//                }
//            }
//            c.intraCacheLock.Unlock()
//
//            c.blockcachelock.Lock()
//		    c.blockcache= c.blockcache[:0]
//            for k,v :=range c.waitingblock {
//                if bytes.Compare(v.Header.BlockHash,c.prev) ==0 {
//                    c.blockcache=append(c.blockcache, v)
//                    delete(c.waitingblock,k)
//                }
//            }
//            c.blockcachelock.Unlock()
//
//            c.resultlock.Lock()
//            c.result=make(map[string]*result)
//            for k,v:=range c.resultcache {
//                if bytes.Compare(v.prev,c.prev)==0 {
//                    c.result[k]=v
//                    delete(c.resultcache,k)
//                }
//            }
//            c.resultlock.Unlock()
//
//            c.choosedlock.Lock()
//		    c.choosed = nil
//            c.choosedlock.Unlock()
//
//            if len(c.commitchan)==0 {
//                c.commitchan<-true
//            }
//            c.updateQueryList<-true
//
//		    w := bufio.NewWriter(file)
//		    now := time.Now().String()
//		    w.WriteString(now)
//		    w.WriteString("\n")
//		    w.WriteString("commitblock: " + strconv.Itoa(c.cblock) + " commit intra: " + strconv.Itoa(c.cintra) + " committed tx: " + strconv.Itoa(c.ctx))
//		    w.WriteString("\n")
//		    w.Flush()
//            c.timeout=false
//	    } else {
//		    c.timeout = true
//	    }
//    }
//}
