package consensus

import (
	"bearchain/block"
	"bearchain/config"
	"bearchain/constdef"
	"bearchain/contract"
	"bearchain/crypt"
	"bearchain/gossip"
	"bearchain/ledger"
	"bearchain/ledgercache"
	"bearchain/random"
	"bytes"
	"crypto/ecdsa"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"strconv"
	"sync"
	"time"

	"github.com/vechain/go-ecvrf"
)

type MyConsensus struct {
    ttype string
    g *gossip.GossipImp
	lck     sync.Mutex
    //lck2    sync.Mutex
    
    ismalicious bool
    isCommittee bool
    CommitteeActive bool

    Index string
	errchan chan<- error
	RecvMsg <-chan *gossip.MessageImp
    RecvMsg2active bool
    RecvMsg2 <-chan gossip.MessageImp
	SendMsg chan<- *gossip.MessageImp
	//client_tx <-chan block.Transaction
	exe_tx chan block.TxResult

	sc_handler *contract.Contract

	l  *ledger.Ledger
	lc *ledgercache.Cache

	// para for tx to intrablock
	// and intra to  block
	// query block
	simluated chan *block.Simulated // simulate of a tx
	cache     []block.Simulated     // tx simulate cache
	lcache    sync.Mutex

	isbootstrap bool // if a bootstrap node

	//proposerlck sync.Mutex
	//nowproposer int      // indicate the nowproposer
	//propserlist []string //proposer for to-be-committed block
	//newpropser  []string //propser in future

	propserElection chan string //recved proposer msg

	// propser election message cache
	//proposercachelck sync.Mutex
	proposercache    []*block.Proposer // proposer for next block
	proposerfuture   []*block.Proposer //propser for future block
	proposercheck    bool

	interval int // time up for generate block
	txnum    int // max number of tx in each block
	//BlockSize int

	//newToBeCBlock  chan bool
	blockcache     []*block.Block //cache of to-be-committed block
	choosed     *block.Block // the to-be-committed block
	blockcachelock sync.Mutex

	waitingblock    map[string]*block.Block // cache of future block
	waitingblocklck sync.Mutex

	choosedlock sync.Mutex

	commitblock     []*block.Block
	commitblockhash []string
	commitchan      chan bool

	//updateQueryList  chan bool
	blockquerychan   chan *block.Block
	//blockresponechan chan *block.Block
	//sumresult        chan bool

	prev []byte

    //TBC
    count int
	query        map[string]*query //recved qeury message
    //querycache map[string]*query //TBC
	querymsglock sync.Mutex

    //waitingresult []algoresult

	//result []*result //recved respone
	resultlock  sync.Mutex
	result      map[string]*result // respone of  to-be-committed block
	resultcache map[string]*result // respone of future block
	//result map[]
	//qrl sync.Mutex

	tao       float64 //intra selecter ratio
	taonode   float64 // node selected ratio
	m         int
	n         int
	weight    int
	totalnode int


    total int // Number of total node
    expect int // Expect selected
    nextRound int
	thres    float64 // total N node, expect to select n node for respone, thres =n/N
	thresack int
	thresprob float64
    lenght int



	cblock int
	cintra int
	ctx    int
	height int

    ltype string
    latency int
    newBlockTime time.Time
	//committed     bool
	//committedlock sync.Mutex

    // algorand
	//timeout bool
    algorandquery []algoquery
    waitingquery map[string]algoquery
    algorandresult map[string]algoresult

    expectProposer int
    expectCommittee int

    algorandlatency int
    algorandlatencytype string
    algorandwaitingtime int
    algorandwaitingtimetype string

    ifgenerateblock bool
    recvblocktime time.Time
    ifrecvblock bool

    ifresponeblock bool
    recvResponetime time.Time
    ifrecvrespone bool


    // laska
    selectiontime int
    q int
    fenweidian map[int][]float64
    selection [][]int
}

var localMyConsensus *MyConsensus

func StartBlock(str string) *block.Block {
	return nil
}

func Init() *MyConsensus {
	localMyConsensus = new(MyConsensus)
	localMyConsensus.simluated = make(chan *block.Simulated, 102400)
	localMyConsensus.cache = make([]block.Simulated, 0, 1024)

	// set is bootstrap node
	localMyConsensus.isbootstrap = false

	// set proposer
//	localMyConsensus.nowproposer = -1
//	localMyConsensus.propserlist = make([]string, 0)
//	localMyConsensus.newpropser = make([]string, 0)

	localMyConsensus.propserElection = make(chan string, 1)

	// propser election message cache
	localMyConsensus.proposercache = make([]*block.Proposer, 0)
	localMyConsensus.proposerfuture = make([]*block.Proposer, 0)
	localMyConsensus.proposercheck = false

	//
	//localMyConsensus.newToBeCBlock = make(chan bool, 1)
	localMyConsensus.blockcache = make([]*block.Block, 0)
	localMyConsensus.waitingblock = make(map[string]*block.Block)

	//
	localMyConsensus.commitchan = make(chan bool, 1)
	//localMyConsensus.commitchan <- true
	localMyConsensus.commitblock = make([]*block.Block, 0, 1024)

	//localMyConsensus.updateQueryList = make(chan bool, 1)
	localMyConsensus.blockquerychan = make(chan *block.Block)
	//localMyConsensus.blockresponechan = make(chan *block.Block)
	//localMyConsensus.sumresult = make(chan bool)

	// save the query message recved
    localMyConsensus.count=0
	localMyConsensus.query = make(map[string]*query)
	//localMyConsensus.querycache = make(map[string]*query)
	// save the  respone message
	localMyConsensus.result = make(map[string]*result)
	localMyConsensus.resultcache = make(map[string]*result)

	localMyConsensus.prev = []byte("start")

	localMyConsensus.tao = 1.0
	localMyConsensus.m = 1
	localMyConsensus.n = 1
	//cache []block.Simulated
	localMyConsensus.thres = 0.5

	localMyConsensus.cblock = 0
	localMyConsensus.cintra = 0
	localMyConsensus.ctx = 0

	////localMyConsensus.timeout = false
	//localMyConsensus.committed = false
	localMyConsensus.height = 0

    //laska
    localMyConsensus.fenweidian=make(map[int][]float64)
    localMyConsensus.selectiontime=0

	if localMyConsensus.isbootstrap {
		startblock := StartBlock("start")
		localMyConsensus.commitblock = append(localMyConsensus.commitblock, startblock)
	}

	return localMyConsensus
}

func New() *MyConsensus {
    myConsensus := new(MyConsensus)
	myConsensus.simluated = make(chan *block.Simulated, 102400)
	myConsensus.cache = make([]block.Simulated, 0, 1024)

	// set is bootstrap node
	myConsensus.isbootstrap = false

	// set proposer
//	myConsensus.nowproposer = -1
//	myConsensus.propserlist = make([]string, 0)
//	myConsensus.newpropser = make([]string, 0)

	myConsensus.propserElection = make(chan string, 1)

	// propser election message cache
	myConsensus.proposercache = make([]*block.Proposer, 0)
	myConsensus.proposerfuture = make([]*block.Proposer, 0)
	myConsensus.proposercheck = false

	//
	//myConsensus.newToBeCBlock = make(chan bool, 1)
	myConsensus.blockcache = make([]*block.Block, 0)
	myConsensus.waitingblock = make(map[string]*block.Block)

	//
	myConsensus.commitchan = make(chan bool, 1)
	//myConsensus.commitchan <- true
	myConsensus.commitblock = make([]*block.Block, 0, 1024)

	//myConsensus.updateQueryList = make(chan bool, 1)
	myConsensus.blockquerychan = make(chan *block.Block)
	//myConsensus.blockresponechan = make(chan *block.Block)
	//myConsensus.sumresult = make(chan bool)

	// save the query message recved
    myConsensus.count=0
	myConsensus.query = make(map[string]*query)
	//myConsensus.querycache = make(map[string]*query)
	// save the  respone message
	myConsensus.result = make(map[string]*result)
	myConsensus.resultcache = make(map[string]*result)

	myConsensus.prev = []byte("start")

	myConsensus.tao = 1.0
	myConsensus.m = 1
	myConsensus.n = 1
	//cache []block.Simulated
	myConsensus.thres = 0.5

	myConsensus.cblock = 0
	myConsensus.cintra = 0
	myConsensus.ctx = 0

	//myConsensus.timeout = false
	//myConsensus.committed = false
	myConsensus.height = 0

	if myConsensus.isbootstrap {
		startblock := StartBlock("start")
		myConsensus.commitblock = append(myConsensus.commitblock, startblock)
	}

    // algorand
    myConsensus.algorandquery=make([]algoquery,0 )
    myConsensus.waitingquery=make(map[string]algoquery)
    myConsensus.algorandresult=make(map[string]algoresult)


    //laska
    myConsensus.fenweidian=make(map[int][]float64)
    myConsensus.selectiontime=0

	return myConsensus
}

func (my *MyConsensus)SetMalicious(){
    my.ismalicious=true
}

// set the scale of stake 
// malicious as -
// honest as +
// e.g. [-1,1] l=2
func (my *MyConsensus)SetLength(l int){
    my.lenght=l
}



//algorand
func (my *MyConsensus)SetExpectProposer(expectProposer int) {
    my.expectProposer=expectProposer
}

func (my *MyConsensus) SetKnownLatency(ltype string, latency int) {
    my.ltype=ltype
    my.latency=latency
}



func (my *MyConsensus) SetNodeNum(total int, expect int,nextRound int, weight int) {
   // my.tao=tao
    my.total=total
    my.weight=weight
    my.expect=expect
    my.nextRound=nextRound
}

func (my *MyConsensus) SetWeight(weight int) {
   // my.tao=tao
    //my.total=total
    my.weight=weight
    //my.expect=expect
    //my.nextRound=nextRound
}

func (my *MyConsensus) SetProb(thres float64, thresack int, thresprob float64) {
    my.thres=thres
    my.thresack=thresack
    my.thresprob=thresprob
}

//func (my *MyConsensus)SetMalicious(flag bool){
//    my.ismalicious=flag
//}

func (my *MyConsensus)SetCommitted(isActive bool, iscommittee bool){
    my.CommitteeActive=isActive
    my.isCommittee=iscommittee
}

func (my *MyConsensus)SetType(ttpype string){
    my.ttype=ttpype
}

func (my *MyConsensus) SetBootStrap(boot bool) {
    my.isbootstrap=boot
}

func (my *MyConsensus) SetConsensus(conf *config.ConsensusConfig) {
	con := conf.GetCondition()
	if con.Interval == 0 {
		//fmt.Fprintf(os.Stdout, "index %v |  INFO | unset intrablock generation interval, using 10 seconds\n", my.Index)
		my.interval = 10
	}
	my.interval = con.Interval
	if con.Maxnum == 0 {
		//fmt.Fprintf(os.Stdout, "index %v |  INFO | unset intrablock max tx number, using 100\n", my.Index)
		my.interval = 10
	}
	my.txnum = con.Maxnum
	my.isbootstrap = conf.Isbootstrap()
	my.thres = float64(conf.Thresh)
	my.thresack = conf.Threshack
	my.thresprob= conf.ThresProb
	//my.intraTxNum = con.Maxnum
}

func (my *MyConsensus) SetVRFPara(conf *config.VRF) {
	my.tao = float64(conf.Tao)
	my.taonode = float64(conf.Taonode)
	my.totalnode = conf.Total
	my.weight = conf.Weight
}

func (c *MyConsensus) SetLedger(l *ledger.Ledger) {
	c.l = l
}

func (c *MyConsensus) SetCacheLedger(l *ledgercache.Cache) {
	c.lc = l
}

func SetErrChan(errchan chan<- error) {
	localMyConsensus.errchan = errchan
}

func GetlocalConsensus() *MyConsensus {
	return localMyConsensus
}

func (c *MyConsensus) SetRecvchan(ch <-chan *gossip.MessageImp) {
	c.RecvMsg = ch
}

func (c *MyConsensus) SetRecvchan2(ch <-chan gossip.MessageImp) {
	c.RecvMsg2 = ch
}

func (c *MyConsensus) SetSendchan(ch chan<- *gossip.MessageImp) {
	c.SendMsg = ch
}

func (c *MyConsensus) SetContract(sc *contract.Contract) {
	c.sc_handler = sc
}

func (c *MyConsensus) SetVRF(tao float64, taonode float64, n int) {
	c.tao = tao
	c.taonode = taonode
	c.n = n
	c.totalnode = n
}

// generate start block
func (c *MyConsensus) initBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
	if c.isbootstrap {
        c.lck.Lock()
        //fmt.Fprintf(os.Stdout," CONSENSUS |  initBlock | Get Lock, time %v\n", time.Now().String())
        defer c.lck.Unlock()
		pks := crypt.EncodePk(pk)
		hash, proof, err := ecvrf.P256Sha256Tai.Prove(sk, c.prev)
		if err != nil {
			panic(err)
		}
		propser := new(block.Proposer)
		propser.Hash = append(propser.Hash, hash...)
		propser.Proof = append(propser.Proof, proof...)
		propser.Pk = append(propser.Pk, pks...)
		propserlist := make([]*block.Proposer, 0)
		propserlist = append(propserlist, propser)
		//pmsg:=propserTomessage(propser)
		//c.SendMsg<-pmsg
        var initblock *block.Block
        //if c.ttype=="algorand" {
        //    initblock=block.AlgorandNewBlock(sk, pk, c.prev, 0,c.weight, nil, propserlist)
        //} else {
        //    initblock = block.NewBlock(sk, pk, c.prev, 0, nil, propserlist)
        //}
        initblock = block.NewBlock(sk, pk, c.prev, 0, nil, propserlist)
		c.height = 1
		bmsg := blockToGossipMsg(initblock)
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | initBlock | Broadcast Init block hash %v, block height: %d\n", c.Index, initblock.Header.BlockHash, initblock.Header.Height)
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | initBlock | Broadcast Init Block, block hash %v, block height: %d\n",c.Index,  initblock.Header.BlockHash, initblock.Header.Height)
		c.SendMsg <- bmsg
        //c.newBlockTime=time.Now()
        //if c.ttype=="algorand"{
        //    c.recvResponetime=time.Now()
        //    c.recvblocktime=time.Now()
        //}

		c.commitblock = append(c.commitblock, initblock)
		c.prev = initblock.Header.BlockHash
//		for _, v := range initblock.Proposer {
//			c.propserlist = append(c.propserlist, string(v.Pk))
//		}
		c.proposercheck = true
		//c.nowproposer = 0
		if len(c.commitchan) == 0 {
			c.commitchan <- true
		}
        //if c.ttype=="algorand"{
        //    var timer time.Timer
        //    switch c.ltype {
        //        case "Mil":
        //            timer=*time.NewTimer(time.Duration(c.latency)*time.Millisecond)
        //        case "Sec":
        //            timer=*time.NewTimer(time.Duration(c.latency)*time.Second)
        //        case "Min":
        //            timer=*time.NewTimer(time.Duration(c.latency)*time.Minute)
        //        default :
        //            panic("Wrong time duration")
        //    }
        //    <-timer.C
//func (//c *MyConsensus) AlgorandGenerateBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
        //    //c.AlgorandGenerateBlock(sk,pk)
        //    //c.ifgenerateblock=true
        //    //c.ifresponeblock=false
        //}
        //fmt.Fprintf(os.Stdout,"index %v | CONSENSUS |  initBlock  | Release Lock, time %v\n", c.Index, time.Now().String())
	}
}

func (c *MyConsensus) Process_ClienTx(flag string, bs []byte) error {
    //fmt.Fprintf(os.Stdout,"index %v | CONSENSUS |  Process tx, time %v\n", c.Index, time.Now().String())
	tx := new(block.Transaction)
	err := json.Unmarshal(bs, tx)
	if err != nil {
		e := fmt.Errorf("Error:\t function MyConsensus.Process_ClienTx ,para %s, fail to Unmarshal byte to block.Transaction\n", string(bs))
		c.errchan <- e
		//fmt.Fprintf(os.Stdout,"error: %v\n",err)
	}
	ok, err := tx.Verify()
	if ok != true {
		//return e:=fmt.Errorf("tx %s verified failed.", tx.Tx_ID)
		//fmt.Fprintf(os.Stdout, "index %v | Info: \t fail to verified tx %s \n", c.Index, tx.Tx_ID)
		e := fmt.Errorf("Info: \t fail to verified tx %s \n", tx.Tx_ID)
		return e
		//c.errchan<-e
	}
	c.sc_handler.ExecTx(flag, *tx, c.simluated)
	return nil
}

func (c *MyConsensus) ReadSimulated(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
	for {
		sim := <-c.simluated
		c.lcache.Lock()
		c.cache = append(c.cache, *sim)
		c.lcache.Unlock()
	}
}

func (c *MyConsensus) GenerateBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
	tricker := time.NewTicker(300 * time.Millisecond)
	//tricker := time.NewTicker(time.Duration(c.interval) * 300 * time.Millisecond)
	go c.ReadSimulated(sk, pk)
	for {
		// TBC
		<-c.commitchan
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | Create Block %d, Time: %v\n", c.Index, c.height, time.Now().String())
		if c.proposercheck {
		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | need new proposer, Time: %v\n", c.Index, time.Now().String())
			for {
				if len(c.proposercache) != 0 {
					break
				}
				fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | no proposer found, waiting, Time: %v\n", c.Index, time.Now().String())
				<-tricker.C
			}
		}   
        c.lck.Lock()
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | Get lock, Time: %v\n",c.Index,   time.Now().String())
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | Create Block %d with %d new proposer Time: %v\n",c.Index,  c.height, len(c.proposercache), time.Now().String())
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | Create Block %d with %d new proposer Time: %v\n", c.height, len(c.proposercache), time.Now().String())
        //var proposerlist []*block.Proposer
        //if len(c.proposercache)>10 {
        //    //proposerlist=c.
        //    proposerlist=c.proposercache[:10]
        //    //c.proposercache=c.proposercache[:10]
        //} else {
        //    proposerlist=c.proposercache
        //}
        proposerlist:=c.proposercache
        //for _,v:=range proposerlist {
        ////for _,v:=range c.proposercache {
		//    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | proposer pk %v, Time: %v\n",c.Index,  v.Pk, time.Now().String())
        //}

        if c.ismalicious {
            // Create  block 1
//            c.lcache.Lock()
//            var newblock1 *block.Block
//		    l := len(c.cache)
//		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock(Malicious Node) | tx cache len %d\n ",c.Index,  l)
//		    if l > c.txnum {
//                fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock(Malicious Node) | para: prev %v, height  %d\n ",c.Index,  c.prev,c.height)
//			    newblock1 = block.NewBlock(sk, pk, c.prev, c.height, c.cache[:c.txnum], proposerlist)
//			    //newblock = block.NewBlock(sk, pk, c.prev, c.height, c.cache[:c.txnum], c.proposercache)
//			    c.cache = c.cache[c.txnum:]
//		    } else {
//                fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock(Malicious Node) | para: prev %v, height  %d\n ",c.Index,  c.prev,c.height)
//			    newblock1 = block.NewBlock(sk, pk, c.prev, c.height, c.cache, proposerlist)
//			    //newblock = block.NewBlock(sk, pk, c.prev, c.height, c.cache, c.proposercache)
//			    c.cache = c.cache[l:]
//		    }
//		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock(Malicious Node) | new block hash %v, block height %d, set choosed block to it\n ",c.Index, newblock1.Header.BlockHash, newblock1.Header.Height)
//            c.newBlockTime=time.Now()
//		    c.choosed = newblock1
//
//		    blockmsg := blockToGossipMsg(newblock1)
//		    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | QueryBlock | Broadcast new block %v, block height %d, Time: %v\n",c.Index,  newblock.Header.BlockHash, newblock.Header.Height, time.Now().String())
//		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | QueryBlock | Block Message %v, Time: %v\n",c.Index,  blockmsg, time.Now().String())
//		    c.SendMsg <- blockmsg
//            c.QueryBlock(sk,pk)
//		    //c.blockquerychan <- newblock
//		    c.lcache.Unlock()
//
//            // Create block 2
//            c.lcache.Lock()
//		    c.lcache.Unlock()
//            c.lck.Unlock()
//            continue
        }

		c.lcache.Lock()
		var newblock *block.Block
		l := len(c.cache)
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | tx cache len %d\n ",c.Index,  l)
		if l > c.txnum {
            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | para: prev %v, height  %d\n ",c.Index,  c.prev,c.height)
			newblock = block.NewBlock(sk, pk, c.prev, c.height, c.cache[:c.txnum], proposerlist)
			//newblock = block.NewBlock(sk, pk, c.prev, c.height, c.cache[:c.txnum], c.proposercache)
			c.cache = c.cache[c.txnum:]
		} else {
            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | para: prev %v, height  %d\n ",c.Index,  c.prev,c.height)
			newblock = block.NewBlock(sk, pk, c.prev, c.height, c.cache, proposerlist)
			//newblock = block.NewBlock(sk, pk, c.prev, c.height, c.cache, c.proposercache)
			c.cache = c.cache[l:]
		}
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | new block hash %v, block height %d, set choosed block to it\n ",c.Index, newblock.Header.BlockHash, newblock.Header.Height)
        c.newBlockTime=time.Now()
		c.choosed = newblock

		blockmsg := blockToGossipMsg(newblock)
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | QueryBlock | Broadcast new block %v, block height %d, Time: %v\n",c.Index,  newblock.Header.BlockHash, newblock.Header.Height, time.Now().String())
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | QueryBlock | Block Message %v, Time: %v\n",c.Index,  blockmsg, time.Now().String())
		c.SendMsg <- blockmsg
        c.QueryBlock(sk,pk)
		//c.blockquerychan <- newblock
		c.lcache.Unlock()

		//c.choosedlock.Lock()
		//c.choosed = newblock
		//c.choosedlock.Unlock()
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | Release lock, Time: %v\n",c.Index,  time.Now().String())
        c.lck.Unlock()
	}
}

func blockToGossipMsg(b *block.Block) *gossip.MessageImp {
	gmsp := new(gossip.MessageImp)
	bs, err := json.Marshal(*b)
	if err != nil {
		fmt.Fprintf(os.Stdout, "Error | Fail to Marshal block to bytes :%v, Time: %v\n", err, time.Now().String())
	}
	gmsp.Bs = make([]byte, 0, 10240)
	gmsp.Bs = append(gmsp.Bs, bs...)
	gmsp.Ttype = constdef.BLOCK
    gmsp.TimeStamp=time.Now().String()
	return gmsp
}

// query Block
func (c *MyConsensus) QueryBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
    if c.choosed==nil {
        panic("empty choosed but query block")
    }
    //for _,v := range c.query {
    //    if 0== bytes.Compare(v.id,c.choosed.Header.BlockHash) {
    //        fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | QueryBlock | Query to block hash %v,block height %v HAS BEEN MADE, Time: %v\n",c.Index,  c.choosed.Header.BlockHash, c.choosed.Header.Height, time.Now().String())
    //        return
    //    }
    //}
	qmsg := c.queryMsg(c.count,sk, pk)
	//qmsg := c.queryMsg(0,sk, pk)
    if qmsg!=nil {
	    //fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | QueryBlock | Query block choosed block info, block hash %v,block height %v, query count %d,send query message, Time: %v\n",c.Index,  c.choosed.Header.BlockHash, c.choosed.Header.Height,c.count, time.Now().String())
        c.SendMsg <- qmsg
    }
    //TBC add query Msg to my recved query msg cache
	//fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | QueryBlock | Query block choosed block info, block hash %v,block height %v,send query message, Time: %v\n",c.Index,  c.choosed.Header.BlockHash, c.choosed.Header.Height, time.Now().String())
}
//func (c *MyConsensus) QueryBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	//	tricker := time.NewTicker(time.Duration(c.interval) * time.Second)
//	for {
//	    b := <-c.blockquerychan
//        c.lck.Lock()
//        fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | QueryBlock | Get lock, Time: %v\n",c.Index,   time.Now().String())
//        if c.choosed==nil {
//            ifcommitted:=false
//            for _,v := range c.commitblock {
//                if 0==bytes.Compare(v.Header.BlockHash,b.Header.BlockHash) {
//                    ifcommitted=true
//                    break
//                }
//            }
//            if ifcommitted {
//		        fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | QueryBlock | Release lock, Time: %v\n",c.Index,   time.Now().String())
//                c.lck.Unlock()
//                continue
//            }
//            fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | QueryBlock | Error empty choosed block, set choosed block to it, block hash: %v, height %d, block , Time: %v\n", c.Index, b.Header.BlockHash,b.Header.Height, time.Now().String())
//            c.choosed=b
//            //panic("Empty choosed block")
//        }
//		//blockmsg := blockToGossipMsg(b)
//		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | QueryBlock | Broadcast new block %v, block height %d, Time: %v\n",c.Index,  b.Header.BlockHash, b.Header.Height, time.Now().String())
//		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | QueryBlock | Block Message %v, Time: %v\n",c.Index,  blockmsg, time.Now().String())
//		//c.SendMsg <- blockmsg
//        // chongfule zhebufen gen RecvBlock hanshu 
//		if c.isAMissingBlock(b.Header.BlockHash) {
//			c.blockcache = append(c.blockcache, b)
//		}
//        //TBC
//		qmsg := c.queryMsg(0,sk, pk)
//		fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | QueryBlock | Query block, block hash %v,block height %v,send query message, Time: %v\n",c.Index,  b.Header.BlockHash, b.Header.Height, time.Now().String())
//		fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | QueryBlock | Query Message %v, Time: %v\n",c.Index,  qmsg, time.Now().String())
//		c.SendMsg <- qmsg
//		fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | QueryBlock | Release lock, Time: %v\n",c.Index,   time.Now().String())
//        c.lck.Unlock()
//	}
//}

//
func (c *MyConsensus) CheckifElectionOrGenerate(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) (bool, bool) {
	pks := crypt.EncodePk(pk)
	var ifElection bool
	var ifGenerate bool
	//    ifElection:=false
	//    ifGenerate:=false
	var proposerblockindex int
	l := len(c.commitblock)
    //count:=0
	//last:=c.commitblock[l-1]
	var proposerlist []block.Proposer
    //fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | CheckifElectionOrGenerate | 1 \n ",c.Index)
	for i := l - 1; i > 0; i-- {
		if c.commitblock[i].Proposer != nil {
			proposerlist = c.commitblock[i].Proposer
		    proposerblockindex = i
			break
        }
//        } else {
//            count = count + 1
//        }
	}
	//proposed_user := proposerlist[count]

    //fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | CheckifElectionOrGenerate | 2 \n ",c.Index)
    //fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | CheckifElectionOrGenerate | len of Proposer %v \n ",c.Index, len(proposerlist))
    //fmt.Fprintf(os.Stdout, " index %v | CONSENSUS | CheckifElectionOrGenerate | count %v \n ",c.Index, count)
    proposed_user := l - 1 - proposerblockindex
    nextpk := proposerlist[proposed_user].Pk
	//if count == len(proposerlist)-1 {
//	if proposed_user == len(proposerlist)-1 {
//		ifElection = true
//	} else {
//		ifElection = false
//	}
//    var nextpk []byte
//    if len(proposerlist)==count {
//        nextpk = proposerlist[count-1].Pk
//        ifElection=true
//    }
	//nextpk := proposerlist[count].Pk


    //fmt.Fprintf(os.Stdout, " index %v | CONSENSUS | CheckifElectionOrGenerate | len of Proposer %v \n ",c.Index, len(proposerlist))
	//proposed_user := l - 1 - proposerblockindex
    //fmt.Fprintf(os.Stdout, " index %v | CONSENSUS | CheckifElectionOrGenerate | proposed_user %v \n ",c.Index, proposed_user)
	//proposed_user := l - 1 - proposerblockindex
	//nextpk := proposerlist[proposed_user].Pk
	if bytes.Compare(nextpk, []byte(pks)) == 0 {
		ifGenerate = true
	} else {
		ifGenerate = false
	}
//	if count == len(proposerlist)-1 {
	if proposed_user == len(proposerlist)-1 {
		ifElection = true
	} else {
		ifElection = false
	}
	return ifElection, ifGenerate
}

// Commit a Block
func (c *MyConsensus)Commit() {
    if c.choosed==nil {
        panic("empty to-be-committed block")
    }
    c.lc.Commit(c.choosed)
}

func (c *MyConsensus)ProbCompute() bool {
    return true
}

// The probability that less half node agreement < c.threprob
// wrong probability
func ProbCompute(threprob float64, count int, total int) bool {
    rate:=float64(count)/float64(total)
    if rate<0.5{
        return false
    }
    t:=rate-0.5
    pro:=math.Exp(float64(-2)*float64(total)*t*t)
    if pro>threprob {
        return false
    }
    return true
}

//
func ProbCompute2(threprob float64, count int, total int, l int) bool {
    if count<=0 {
        return false
    }
    rate:=float64(count)/float64(total)
    pro:=math.Exp(float64(-2)*float64(total)*rate*rate/float64(l)/float64(l))
    if pro>threprob {
        return false
    }
    return true
}

//func (c *MyConsensus) SumQueryResult(file *os.File) {
func (c *MyConsensus) SumQueryResult(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	path := "./static"+c.Index
//	file, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_TRUNC|os.O_APPEND, 0660)
//	if os.IsNotExist(err) {
//		fmt.Fprintf(os.Stdout, "index %v |  Error | fail to open %s infofile, create it\n",c.Index,  path)
//		file, err = os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0660)
//		if err != nil {
//			panic("fail to open file")
//		}
//	}
//	defer file.Close()
    
    var ifquery bool
    //var recvResp int
    //recvResp=0

	tricker := time.NewTicker( 300 * time.Millisecond)
    //var tricker *time.Ticker
	////tricker := time.NewTicker( 3 * time.Millisecond)
    //switch c.ltype {
    //case "Mil":
    //    //newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Millisecond)
    //    tricker=time.NewTicker(time.Duration(c.latency)*time.Millisecond)
    //case "Sec":
    //    //newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Second)
    //    tricker=time.NewTicker(time.Duration(c.latency)*time.Second)
    //case "Min":
    //    tricker=time.NewTicker(time.Duration(c.latency)*time.Minute)
    //    default :
    //panic("Wrong time duration")
    //}
	//tricker := time.NewTicker( 100 * time.Millisecond)
	//tricker := time.NewTicker(time.Duration(c.interval) * 100 * time.Millisecond)
	for {
		<-tricker.C
        c.lck.Lock()
        if c.choosed == nil {
            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Waiting for new block, Time: %v\n",c.Index,  time.Now().String())
            c.lck.Unlock()
            continue
        }
        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Get lock, Time: %v\n",c.Index,   time.Now().String())

		ack := 0
        totalack:=0
		total := 0
        totalweight:=0
        usecount:=0
        //totalcount:=-1
        //countnumber:=0
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summay | Check for block %v, height %d, Time: %v\n",c.Index, c.choosed.Header.BlockHash,c.choosed.Header.Height, time.Now().String())
        //for _, v := range c.result { 
		//	if bytes.Compare(c.choosed.Header.BlockHash, v.id) == 0 {
        //        if v.count>usecount{
        //            usecount=v.count
        //        }         
        //    }
        //}

        //total:=0
        //var countlist []int
        //for usecount>=0 {
        //    countlist = append(countlist, usecount)
        //    usecount=usecount-1
        //}
        //var ack []int
        //var totalack []int
        //var totalweight []int
        //var total []int
        //usecount:=0

		//for k, v := range c.result {
		//	if bytes.Compare(c.choosed.Header.BlockHash, v.id) == 0 {
        //        if v.count>totalcount{
        //            totalcount=v.count
        //        }
		//	} else if c.isACommitBlock(v.id) {
        //        delete(c.result,k)
        //    }
		//}
        //if totalcount==-1 {
        //    c.lck.Unlock()
		//	continue
        //}

        //tmptotal:=make([]int,totalcount+1)
        //tmpack:=make([]int,totalcount+1)
        //tmpsumack:=make([]int,totalcount+1)
        //tmptotalweight:=make([]int,totalcount+1)
        //for i:=0;i<=totalcount;i++ {
        //    tmptotal[i]=0
        //    tmpack[i]=0
        //    tmptotalweight[i]=0
        //}

		//for _, v := range c.result {
		//	if bytes.Compare(c.choosed.Header.BlockHash, v.id) == 0 {
        //        tmptotal[v.count]=tmptotal[v.count]+1
        //        tmptotalweight[v.count]=tmptotalweight[v.count]+v.weight
		//		if v.ack == true {
		//			//ack = ack + 1
        //            tmpack[v.count]=tmpack[v.count]+v.weight
        //            tmpsumack[v.count]=tmpsumack[v.count]+v.weight
        //        } else if v.ack==false {
        //            tmpack[v.count]=tmpack[v.count]-v.weight
        //        }
		//	} 	
        //}


		for k, v := range c.result {
			if bytes.Compare(c.choosed.Header.BlockHash, v.id) == 0 {
                if v.count>usecount {
                    usecount=v.count
                }
				total = total + 1
                totalweight=totalweight+v.weight
				if v.ack == true {
					//ack = ack + 1
                    totalack=totalack+v.weight
                    ack=ack+v.weight
		            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summay | Recv %d ack from %s, Time: %v\n",c.Index, ack,v.pk, time.Now().String())
                } else if v.ack==false {
                    ack=ack-v.weight
                }
			} else if c.isACommitBlock(v.id) {
                delete(c.result,k)
            }
		}
        //ifprob:=false
        //ack:=0
        //total:=0
        //totalweight:=0
        //totalack:=0
        //usecount:=0
        //for i:=0;i<totalcount;i++{
        //    ack=ack+tmpack[i]
        //    totalweight=totalweight+tmptotalweight[i]
        //    total=total+tmptotal[i]
        //    totalack=totalack+tmpsumack[i]
        //    usecount=i
        //    ifprob=ProbCompute2(c.thresprob,ack,total,c.lenght) 
        //    if ifprob {
        //        break
        //    }
        //}
        //if !ifprob {
        //    var newtime time.Time
        //    switch c.ltype {
        //        case "Mil":
        //            newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Millisecond)
        //        case "Sec":
        //            newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Second)
        //        case "Min":
        //            newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Minute)
        //        default :
        //            panic("Wrong time duration")
        //    }
        //    if time.Now().After(newtime) {
        //        c.count=c.count+1
        //        c.newBlockTime=time.Now()
        //        c.QueryBlock(sk,pk)
        //    }
        //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Recv respone, tmptotal %v\n tmpack %v\n,tmpsumack %v\n tmptotalweight %v\n  time: %v\n",c.Index, c.thresprob,tmptotal,tmpack,tmpsumack,tmptotalweight, time.Now().String())
        //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | thresprob : %v, sampled node %d, totalweight %d,  sum ack %d, height %d, query count %d, Waiting for enough query respone, time: %v\n",c.Index, c.thresprob,total,totalweight,ack,c.choosed.Header.Height,c.count, time.Now().String())
        //    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | thresprob : %v, recv ack %d, Waiting for enough query respone, time: %v\n",c.Index, c.thresprob,total, time.Now().String())
		//    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Release lock, Time: %v\n",c.Index,   time.Now().String())
        //    c.lck.Unlock()
		//	continue
        //} else {
        // TBC
        ////if !ProbCompute(c.thresprob,ack,total) {
        if !ProbCompute2(c.thresprob,ack,total,c.lenght) {
            var newtime time.Time
            switch c.ltype {
                case "Mil":
                    newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Millisecond)
                case "Sec":
                    newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Second)
                case "Min":
                    newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Minute)
                default :
                    panic("Wrong time duration")
            }
            if time.Now().After(newtime) {
                c.count=c.count+1
                c.newBlockTime=time.Now()
                c.QueryBlock(sk,pk)
            }
            fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | thresprob : %v, sampled node %d, totalweight %d, recv ack %d, sum ack %d, height %d, query count %d, Waiting for enough query respone, time: %v\n",c.Index, c.thresprob,total,totalweight,totalack,ack,c.choosed.Header.Height,c.count, time.Now().String())
            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | thresprob : %v, recv ack %d, Waiting for enough query respone, time: %v\n",c.Index, c.thresprob,total, time.Now().String())
		    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Release lock, Time: %v\n",c.Index,   time.Now().String())
            c.lck.Unlock()
			continue
        } else {
			c.commitblock = append(c.commitblock, c.choosed)
			c.commitblockhash = append(c.commitblockhash, string(c.choosed.Header.BlockHash))
            //count:=c.count
			fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | -------------------------------Success!!!!!!the choosed block %v,height %d, Recv total Respone%d sum recv%d ack %d!!!\n",c.Index,  c.choosed.Header.BlockHash,c.choosed.Header.Height, total,ack,totalack)
			//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | -------------------------------Success!!!!!! %d proposer for next round block generation \n",c.Index,  len(c.choosed.Proposer))
			//c.l.WriteABlock(c.choosed)
			//if l:=len(c.commitblock);l>30{ 
            //    c.commitblock=c.commitblock[l-30:]
			//}
			//if l:=len(c.commitblockhash);l>100{
            //    c.commitblockhash=c.commitblockhash[l-100:]
			//}
			c.height = c.choosed.Header.Height+1
            if c.height == 110 {
                panic("Already 200 committed block! Stop")
            }
			//c.height = c.height + 1
			c.cblock = c.choosed.Header.Height
			//c.cblock = c.cblock + 1
			c.ctx = c.ctx + len(c.choosed.Txs)
			//c.commitblock = append(c.commitblock, string(c.choosed.Header.BlockHash))
			c.prev = c.choosed.Header.BlockHash
			//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | commit a block, set choosed block to nil\n",c.Index)
			c.choosed = nil
            c.count=0
            c.newBlockTime=time.Now()

			c.blockcache = c.blockcache[:0]
			fmt.Fprintf(os.Stdout, "index %v |  Consensus | commit %d block / %d tran\n",c.Index,  c.cblock, c.ctx)

            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Now committed block:\n ",c.Index)
            //for _,v:=range c.commitblock {
            //    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | height %d\nblockhash %v\n, prev: %v\n",c.Index, v.Header.Height,v.Header.BlockHash,v.Header.Prev)
            //    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | it contain Proposer:\n",c.Index )
            //    for _,v2:=range v.Proposer {
            //        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | %v:\n",c.Index, v2.Pk)
            //    }
            //    
            //}
            ifquery=false
			for k, v := range c.waitingblock {
                if c.isACommitBlock(v.Header.BlockHash) {
					delete(c.waitingblock, k)
                } else if bytes.Compare(v.Header.Prev, c.prev) == 0 {
					c.blockcache = append(c.blockcache, v)
                    if len(c.blockcache)>=2{
                        //TBC
                        // Malicious block
                        panic("Two to be committed block ")
                    }
                    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Set choosed block %v\n", c.Index, v.Header.BlockHash)
                    //TBC  
                    // deep copy!
                    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Set choosed block, blockhash: %v, block height %v \n",c.Index,v.Header.BlockHash,v.Header.Height)
                    if c.choosed==nil {
                        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Set choosed block, blockhash: %v, block height %v \n",c.Index,v.Header.BlockHash,v.Header.Height)
					    c.choosed = v
                        c.newBlockTime=time.Now()
                        c.QueryBlock(sk,pk)
                        ifquery=true
                    } else {
                        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | choosed block, blockhash: %v, block height %v, prev %v,pk %v \n",c.Index,c.choosed.Header.BlockHash,c.choosed.Header.Height,c.choosed.Header.Prev,c.choosed.Header.Pk)
                        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | another cached block has same prev with choosed block, blockhash: %v, block height %v, prev %v,pk %v\n",c.Index,v.Header.BlockHash,v.Header.Height,v.Header.Prev,v.Header.Pk)
                        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | another cached block, blockhash: %v, block height %v, prev %v,pk %v \n",c.Index,c.choosed.Header.BlockHash,c.choosed.Header.Height,c.choosed.Header.Prev,c.choosed.Header.Pk)
                        //panic
                    }
//                    if len(c.blockquerychan) == 0 {
//                        c.blockquerychan <- v
//                    }
                    //c.blockquerychan <- v
                    ifquery=true
                   // if len(c.blockquerychan)==0 {
                   //     c.blockquerychan <- v
                   // }
					delete(c.waitingblock, k)
				}
			}

//            if c.choosed != nil {
//                for k,v:=range c.resultcache {
//                    if bytes.Compare(c.choosed.Header.BlockHash, v.id) == 0 {
//                        c.result[k]=v
//                    }
//                    if c.isACommitBlock(v.id) {
//                        delete(c.result,k)
//                    }
//				}
//			}

            // update query
            for k,v:=range c.query {
                if v.ifresp==true {
                    delete(c.query,k)
                }
            }


			//c.waitingblocklck.Unlock()
			//c.blockcachelock.Unlock()
			//c.choosedlock.Unlock()
			//			c.resultlock.Lock()
			//            for k,v:=range c.result {
			//                if c.isACommitBlock(v.id) {
			//                    delete(c.result,k)
			//                }
			//            }
			//			c.result = make(map[string]*result)
			//			for k, v := range c.resultcache {
			//				if bytes.Compare(v.prev, c.prev) == 0 {
			//					c.result[k] = v
			//					delete(c.resultcache, k)
			//				}
			//			}
			//c.resultlock.Unlock()

			//c.updateQueryList <- true

			//update  proposer list
			//			if c.choosed.ContainProposer() {
			//				c.nowproposer = 0
			//				c.propserlist = c.propserlist[:0]
			//				for _, v := range c.choosed.Proposer {
			//					c.propserlist = append(c.propserlist, string(v.Pk))
			//				}
			//				c.proposercheck = true
			//				if len(c.propserElection) == 0 {
			//					c.propserElection <- string(c.choosed.Header.BlockHash)
			//				}
			//			} else {
			//				c.nowproposer = c.nowproposer + 1
			//			}

			//c.proposercachelck.Lock()
            proposercache:=c.proposercache
			c.proposercache = c.proposercache[:0]
			for _, v := range proposercache{
				if bytes.Compare(c.prev, v.Prev) == 0 {
					c.proposercache = append(c.proposercache, v)
				}
			}
			for _, v := range c.proposerfuture {
				if bytes.Compare(c.prev, v.Prev) == 0 {
					c.proposercache = append(c.proposercache, v)
				}
			}
			//c.proposercachelck.Unlock()

			ifelection, ifgenerate := c.CheckifElectionOrGenerate(sk, pk)
		    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index, len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
			if ifelection {
				if len(c.propserElection) == 0 {
					c.propserElection <- string(c.prev)
				}
				c.proposercheck = true
			} else {
				c.proposercheck = false
			}
			if ifgenerate {
				if len(c.commitchan) == 0 {
					c.commitchan <- true
				}
			}
		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Static | commitblock: %d committed tx: %d, Query Count %d, sample node %d, totalweight %d, ack weight %d, sum ack %d,Time: %v\n",c.Index, c.cblock,c.ctx,usecount, total,totalweight,totalack,ack,time.Now().String())
            //.WriteString("commitblock: " + strconv.Itoa(c.cblock) + " committed tx: " + strconv.Itoa(c.ctx))

			//w := bufio.NewWriter(file)
			//now := time.Now().String()
            //write,err:=w.WriteString(now)
            //if err!=nil {
            //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Fail to write to static file Error Info: %v,Error Location 1, write len %d; len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index,err,write, len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
            //}
            // 
			//write,err=w.WriteString("\n")
            //if err!=nil {
            //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Fail to write to static file Error Info: %v,Error Location 2, write len %d; len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index, err,write, len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
            //}
            // 
            //write,err=w.WriteString("commitblock: " + strconv.Itoa(c.cblock) + " committed tx: " + strconv.Itoa(c.ctx))
            //if err!=nil {
            //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Fail to write to static file Error Info: %v,Error Location 3, write len %d; len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index,err,write, len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
            //}
            // 
			//write,err=w.WriteString("\n")
            //if err!=nil {
            //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Fail to write to static file Error Info %v,Error Location 4, write len %d; len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index, err,write, len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
            //}
            //err=w.Flush()
            //if err!=nil {
            //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Fail to write to static file, failt to Flush %v,Error Location 5; len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index, err,len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
            //}
			//c.timeout = false
		    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Release lock, Time: %v\n",c.Index,   time.Now().String())
            if ifquery==true {
                if c.choosed == nil {
                    //fmt.Fprintf(os.Stdout, "index %v |  SumQueryResult | Error: choosed is empty time: %v\n",c.Index,  time.Now().String())
                    panic("SumQueryResult | Error: choosed is empty")
                }
            }
        }
		//if total < c.thresack {
        //    var newtime time.Time
        //    switch c.ltype {
        //        case "Mil":
        //            newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Millisecond)
        //        case "Sec":
        //            newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Second)
        //        case "Min":
        //            newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Minute)
        //        default :
        //            panic("Wrong time duration")
        //    }
        //    if time.Now().After(newtime) {
        //        c.count=c.count+1
        //        c.newBlockTime=time.Now()
        //        c.QueryBlock(sk,pk)
        //    }
        //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | thresack: %d, recv ack %d, Waiting for enough query respone, time: %v\n",c.Index, c.thresack,total, time.Now().String())
		//    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Release lock, Time: %v\n",c.Index,   time.Now().String())
        //    c.lck.Unlock()
		//	continue
		//}
		//if float64(ack)/float64(total) >= c.thres {
//      //      c.VariableUsage()
		//	//if float64(ack)/float64(l) >= c.thres {
		//	//c.Commit()
		//	//c.choosedlock.Lock()
		//	//c.blockcachelock.Lock()
		//	//c.waitingblocklck.Lock()
		//	c.commitblock = append(c.commitblock, c.choosed)
		//	c.commitblockhash = append(c.commitblockhash, string(c.choosed.Header.BlockHash))
        //    //c.Commit()
		//	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | -------------------------------Success!!!!!!the choosed block %v,height %d, ack!!!\n",c.Index,  c.choosed.Header.BlockHash,c.choosed.Header.Height)
        //    count:=c.count
		//	fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | -------------------------------Success!!!!!!the choosed block %v,height %d, Recv total Respone%d with %d ack!!!\n",c.Index,  c.choosed.Header.BlockHash,c.choosed.Header.Height, total,ack)
		//	fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | -------------------------------Success!!!!!! %d proposer for next round block generation \n",c.Index,  len(c.choosed.Proposer))
		//	//c.l.WriteABlock(c.choosed)
		//	//if l:=len(c.commitblock);l>30{ 
        //    //    c.commitblock=c.commitblock[l-30:]
		//	//}
		//	//if l:=len(c.commitblockhash);l>100{
        //    //    c.commitblockhash=c.commitblockhash[l-100:]
		//	//}
		//	c.height = c.choosed.Header.Height+1
        //    if c.height == 110 {
        //        panic("Already 200 committed block! Stop")
        //    }
		//	//c.height = c.height + 1
		//	c.cblock = c.choosed.Header.Height
		//	//c.cblock = c.cblock + 1
		//	c.ctx = c.ctx + len(c.choosed.Txs)
		//	//c.commitblock = append(c.commitblock, string(c.choosed.Header.BlockHash))
		//	c.prev = c.choosed.Header.BlockHash
		//	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | commit a block, set choosed block to nil\n",c.Index)
		//	c.choosed = nil
        //    c.count=0
        //    c.newBlockTime=time.Now()

		//	c.blockcache = c.blockcache[:0]
		//	fmt.Fprintf(os.Stdout, "index %v |  Consensus | commit %d block / %d tran\n",c.Index,  c.cblock, c.ctx)

        //    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Now committed block:\n ",c.Index)
        //    //for _,v:=range c.commitblock {
        //    //    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | height %d\nblockhash %v\n, prev: %v\n",c.Index, v.Header.Height,v.Header.BlockHash,v.Header.Prev)
        //    //    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | it contain Proposer:\n",c.Index )
        //    //    for _,v2:=range v.Proposer {
        //    //        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | %v:\n",c.Index, v2.Pk)
        //    //    }
        //    //    
        //    //}
        //    ifquery=false
		//	for k, v := range c.waitingblock {
        //        if c.isACommitBlock(v.Header.BlockHash) {
		//			delete(c.waitingblock, k)
        //        } else if bytes.Compare(v.Header.Prev, c.prev) == 0 {
		//			c.blockcache = append(c.blockcache, v)
        //            if len(c.blockcache)>=2{
        //                //TBC
        //                // Malicious block
        //                panic("Two to be committed block ")
        //            }
        //            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Set choosed block %v\n", c.Index, v.Header.BlockHash)
        //            //TBC  
        //            // deep copy!
        //            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Set choosed block, blockhash: %v, block height %v \n",c.Index,v.Header.BlockHash,v.Header.Height)
        //            if c.choosed==nil {
        //                fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Set choosed block, blockhash: %v, block height %v \n",c.Index,v.Header.BlockHash,v.Header.Height)
		//			    c.choosed = v
        //                c.newBlockTime=time.Now()
        //                c.QueryBlock(sk,pk)
        //                ifquery=true
        //            } else {
        //                //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | choosed block, blockhash: %v, block height %v, prev %v,pk %v \n",c.Index,c.choosed.Header.BlockHash,c.choosed.Header.Height,c.choosed.Header.Prev,c.choosed.Header.Pk)
        //                //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | another cached block has same prev with choosed block, blockhash: %v, block height %v, prev %v,pk %v\n",c.Index,v.Header.BlockHash,v.Header.Height,v.Header.Prev,v.Header.Pk)
        //                //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | another cached block, blockhash: %v, block height %v, prev %v,pk %v \n",c.Index,c.choosed.Header.BlockHash,c.choosed.Header.Height,c.choosed.Header.Prev,c.choosed.Header.Pk)
        //                //panic
        //            }
//      //              if len(c.blockquerychan) == 0 {
//      //                  c.blockquerychan <- v
//      //              }
        //            //c.blockquerychan <- v
        //            ifquery=true
        //           // if len(c.blockquerychan)==0 {
        //           //     c.blockquerychan <- v
        //           // }
		//			delete(c.waitingblock, k)
		//		}
		//	}

//      //      if c.choosed != nil {
//      //          for k,v:=range c.resultcache {
//      //              if bytes.Compare(c.choosed.Header.BlockHash, v.id) == 0 {
//      //                  c.result[k]=v
//      //              }
//      //              if c.isACommitBlock(v.id) {
//      //                  delete(c.result,k)
//      //              }
//		//		}
//		//	}

        //    // update query
        //    for k,v:=range c.query {
        //        if v.ifresp==true {
        //            delete(c.query,k)
        //        }
        //    }


		//	//c.waitingblocklck.Unlock()
		//	//c.blockcachelock.Unlock()
		//	//c.choosedlock.Unlock()
		//	//			c.resultlock.Lock()
		//	//            for k,v:=range c.result {
		//	//                if c.isACommitBlock(v.id) {
		//	//                    delete(c.result,k)
		//	//                }
		//	//            }
		//	//			c.result = make(map[string]*result)
		//	//			for k, v := range c.resultcache {
		//	//				if bytes.Compare(v.prev, c.prev) == 0 {
		//	//					c.result[k] = v
		//	//					delete(c.resultcache, k)
		//	//				}
		//	//			}
		//	//c.resultlock.Unlock()

		//	//c.updateQueryList <- true

		//	//update  proposer list
		//	//			if c.choosed.ContainProposer() {
		//	//				c.nowproposer = 0
		//	//				c.propserlist = c.propserlist[:0]
		//	//				for _, v := range c.choosed.Proposer {
		//	//					c.propserlist = append(c.propserlist, string(v.Pk))
		//	//				}
		//	//				c.proposercheck = true
		//	//				if len(c.propserElection) == 0 {
		//	//					c.propserElection <- string(c.choosed.Header.BlockHash)
		//	//				}
		//	//			} else {
		//	//				c.nowproposer = c.nowproposer + 1
		//	//			}

		//	//c.proposercachelck.Lock()
        //    proposercache:=c.proposercache
		//	c.proposercache = c.proposercache[:0]
		//	for _, v := range proposercache{
		//		if bytes.Compare(c.prev, v.Prev) == 0 {
		//			c.proposercache = append(c.proposercache, v)
		//		}
		//	}
		//	for _, v := range c.proposerfuture {
		//		if bytes.Compare(c.prev, v.Prev) == 0 {
		//			c.proposercache = append(c.proposercache, v)
		//		}
		//	}
		//	//c.proposercachelck.Unlock()

		//	ifelection, ifgenerate := c.CheckifElectionOrGenerate(sk, pk)
		//    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index, len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
		//	if ifelection {
		//		if len(c.propserElection) == 0 {
		//			c.propserElection <- string(c.prev)
		//		}
		//		c.proposercheck = true
		//	} else {
		//		c.proposercheck = false
		//	}
		//	if ifgenerate {
		//		if len(c.commitchan) == 0 {
		//			c.commitchan <- true
		//		}
		//	}
		//    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Static | commitblock: %d committed tx: %d, Query Count %d, total respone %d, ack %d ,Time: %v\n",c.Index, c.cblock,c.ctx, count, total,ack,time.Now().String())
        //    //.WriteString("commitblock: " + strconv.Itoa(c.cblock) + " committed tx: " + strconv.Itoa(c.ctx))

		//	//w := bufio.NewWriter(file)
		//	//now := time.Now().String()
        //    //write,err:=w.WriteString(now)
        //    //if err!=nil {
        //    //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Fail to write to static file Error Info: %v,Error Location 1, write len %d; len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index,err,write, len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
        //    //}
        //    // 
		//	//write,err=w.WriteString("\n")
        //    //if err!=nil {
        //    //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Fail to write to static file Error Info: %v,Error Location 2, write len %d; len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index, err,write, len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
        //    //}
        //    // 
        //    //write,err=w.WriteString("commitblock: " + strconv.Itoa(c.cblock) + " committed tx: " + strconv.Itoa(c.ctx))
        //    //if err!=nil {
        //    //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Fail to write to static file Error Info: %v,Error Location 3, write len %d; len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index,err,write, len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
        //    //}
        //    // 
		//	//write,err=w.WriteString("\n")
        //    //if err!=nil {
        //    //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Fail to write to static file Error Info %v,Error Location 4, write len %d; len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index, err,write, len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
        //    //}
        //    //err=w.Flush()
        //    //if err!=nil {
        //    //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Fail to write to static file, failt to Flush %v,Error Location 5; len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index, err,len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
        //    //}
		//	//c.timeout = false
		//}
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Release lock, Time: %v\n",c.Index,   time.Now().String())
        //if ifquery==true {
        //    if c.choosed == nil {
        //        //fmt.Fprintf(os.Stdout, "index %v |  SumQueryResult | Error: choosed is empty time: %v\n",c.Index,  time.Now().String())
        //        panic("SumQueryResult | Error: choosed is empty")
        //    }
        //}
        c.lck.Unlock()
	}
}

func (c *MyConsensus) SendMissingBlock(msg *gossip.MessageImp) {
	hash := msg.Bs
    c.lck.Lock()
    defer c.lck.Unlock()
	// If we have block
	for _, v := range c.commitblock {
		if bytes.Compare(v.Header.BlockHash, hash) == 0 {
			bmsg := blockToGossipMsg(v)
			fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | send missing block ,time: %v\n",c.Index,  time.Now().String())
		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | SendMissingBlock | Block Message %v, Time: %v\n",c.Index,  bmsg, time.Now().String())
			c.SendMsg <- bmsg
			return
		}
	}
	c.blockcachelock.Lock()
	defer c.blockcachelock.Unlock()
	for _, v := range c.blockcache {
		if bytes.Compare(v.Header.BlockHash, hash) == 0 {
			bmsg := blockToGossipMsg(v)
			fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | send missing block ,time: %v\n",c.Index,  time.Now().String())
		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | SendMissingBlock | Block Message %v, Time: %v\n",c.Index,  bmsg, time.Now().String())
			c.SendMsg <- bmsg
			return
		}
	}
	c.waitingblocklck.Lock()
	defer c.waitingblocklck.Unlock()
	for _, v := range c.waitingblock {
		if bytes.Compare(v.Header.BlockHash, hash) == 0 {
			bmsg := blockToGossipMsg(v)
			fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | send missing block ,time: %v\n",c.Index,  time.Now().String())
		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | SendMissingBlock | Block Message %v, Time: %v\n",c.Index,  bmsg, time.Now().String())
			c.SendMsg <- bmsg
			return
		}
	}
}

//func (c *MyConsensus) UpdateResponeCache() {
//	tricker := time.NewTicker(3 * time.Duration(c.interval) * time.Second)
//	for {
//		<-tricker.C
//		//c.corelock.Lock()
//		c.respQeuryCache = c.respQeuryCache[:0]
//		for k, v := range c.ifrespQueryMsg {
//			if v == true {
//				c.respQeuryCache = append(c.respQeuryCache, k)
//			}
//		}
//		//c.corelock.Unlock()
//		<-tricker.C
//		//c.corelock.Lock()
//		for _, v := range c.respQeuryCache {
//			if _, ok := c.ifrespQueryMsg[v]; ok {
//				delete(c.ifrespQueryMsg, v)
//			}
//		}
//		//c.corelock.Unlock()
//	}
//}
func (c *MyConsensus) ResponeWithProSelection(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
	tricker := time.NewTicker(time.Duration(c.interval) * 100 * time.Millisecond)
	for {
		<-tricker.C
        c.lck.Lock()
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Get lock, Time: %v\n",c.Index,   time.Now().String())
		//b:=<-c.blockresponechan
		//c.querymsglock.Lock()
        for _, v := range c.query {
            if  v.ifresp==false {
            // respone the Query to a committed block
            // Respone:
            // if a block is committed MEANs that with Exponential probability
            // the block will be committed when node Recv all respone
            for _,v2:=range c.commitblock {
                if 0==bytes.Compare(v.id, v2.Header.BlockHash) {
                    if c.ttype=="laska" {
                        continue
                    } else {
                        ack:=c.ackmsg2(constdef.ACK,v.id,v.prev,c.height,v.count,sk,pk)
                        if ack!=nil {
                            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Respone to block  %v  height %d ,query count %d  with right message, Time: %v\n",c.Index,v.id,v.height,v.count ,time.Now().String())
                            if c.ttype=="my" {
                                c.SendMsg<-ack
                            }
                            v.ifresp=true
                        }
                    }
                }
            }
            // respone the Query to a to-be-committed block
                if  c.choosed!=nil {
                    v.ifresp=true
                    if  0== bytes.Compare(v.prev,c.choosed.Header.Prev) {
                        if  0==bytes.Compare(v.id,c.choosed.Header.BlockHash) {
                        // match prev and blockhash, same to-be-committed block
                            if c.ismalicious {
                                if c.ttype=="laska" {
                                //ack:=c.ackmsg(constdef.NOACK,v.id,v.prev,c.height,v.count,sk,pk)
                                    selected:=c.selection[c.selectiontime]
                                    c.selectiontime=c.selectiontime+1
                                    flag:=false
                                    my,err:=strconv.Atoi(c.Index)
                                    if err!=nil {
                                        panic("node index error")
                                    }
                                    for _,v:=range selected {
                                        if my==v {
                                            flag=true
                                        }
                                    }
                                    if flag==true {
                                        ack:=c.ackmsgLaska(constdef.NOACK,v.id,v.prev,c.height,v.count,sk,pk)
                                        if ack!=nil {
                                        //panic("Respone function! cannt generate respone")
		                                    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Respone to block  %v  height %d ,query count %d  with error message, Time: %v\n",c.Index,v.id,v.height,v.count ,time.Now().String())
                                            //c.SendMsg<-ack
                                            if c.ttype=="my" {
                                                c.SendMsg<-ack
                                            }
                                            v.ifresp=true
                                            cmsg:=new(ConsensusMessage)
	                                        err := json.Unmarshal(ack.Bs, cmsg)
	                                        if err != nil {
                                                panic("Respone")
	                                        }
                                            //c.RecvRespone(cmsg)
                                            if c.ttype=="my" {
                                                c.RecvRespone(cmsg)
                                            }
                                        }
                                    }
                                } else {
                                    ack:=c.ackmsg2(constdef.NOACK,v.id,v.prev,c.height,v.count,sk,pk)
                                    //ack:=c.ackmsg2(constdef.ACK,v.id,v.prev,c.height,v.count,sk,pk)
                                    if ack!=nil {
                                        //panic("Respone function! cannt generate respone")
		                                fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Respone to block  %v  height %d ,query count %d  with error message, Time: %v\n",c.Index,v.id,v.height,v.count ,time.Now().String())
                                        //c.SendMsg<-ack
                                        if c.ttype=="my" {
                                            c.SendMsg<-ack
                                        }
                                        v.ifresp=true
                                        cmsg:=new(ConsensusMessage)
	                                    err := json.Unmarshal(ack.Bs, cmsg)
	                                    if err != nil {
                                            panic("Respone")
	                                    }
                                        //c.RecvRespone(cmsg)
                                        if c.ttype=="my" {
                                            c.RecvRespone(cmsg)
                                        }
                                    }
                                }
                            } else {
                                if c.ttype=="laska" {
                                //ack:=c.ackmsg(constdef.NOACK,v.id,v.prev,c.height,v.count,sk,pk)
                                    selected:=c.selection[c.selectiontime]
                                    c.selectiontime=c.selectiontime+1
                                    flag:=false
                                    my,err:=strconv.Atoi(c.Index)
                                    if err!=nil {
                                        panic("node index error")
                                    }
                                    for _,v:=range selected {
                                        if my==v {
                                            flag=true
                                        }
                                    }
                                    if flag==true {
                                        ack:=c.ackmsgLaska(constdef.NOACK,v.id,v.prev,c.height,v.count,sk,pk)
                                        if ack!=nil {
                                        //panic("Respone function! cannt generate respone")
		                                    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Respone to block  %v  height %d ,query count %d  with error message, Time: %v\n",c.Index,v.id,v.height,v.count ,time.Now().String())
                                            //c.SendMsg<-ack
                                            if c.ttype=="my" {
                                                c.SendMsg<-ack
                                            }
                                            v.ifresp=true
                                            cmsg:=new(ConsensusMessage)
	                                        err := json.Unmarshal(ack.Bs, cmsg)
	                                        if err != nil {
                                                panic("Respone")
	                                        }
                                            //c.RecvRespone(cmsg)
                                            if c.ttype=="my" {
                                                c.RecvRespone(cmsg)
                                            }
                                        }
                                    }
                                } else {
                                    ack:=c.ackmsg2(constdef.ACK,v.id,v.prev,c.height,v.count,sk,pk)
                                    if ack!=nil {
		                                fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Respone to block  %v  height %d ,query count %d  with right message, Time: %v\n",c.Index,v.id,v.height,v.count ,time.Now().String())
                                        //c.SendMsg<-ack
                                        if c.ttype=="my" {
                                            c.SendMsg<-ack
                                        }
                                        v.ifresp=true
                                        cmsg:=new(ConsensusMessage)
	                                    err := json.Unmarshal(ack.Bs, cmsg)
	                                    if err != nil {
                                            panic("Respone")
	                                    }
                                        if c.ttype=="my" {
                                            c.RecvRespone(cmsg)
                                        }
                                        //c.RecvRespone(cmsg)
                                    }       
                                }
                            }
                            //c.SendMsg<-ack
                            //break
                        } else {
                            // match prev but not match block hash
                            // there are to different block
                            // broadcast "malicious node" msg
                            // TBC
                            //ack:=c.ackmsg2(constdef.ACK,v2.Header.BlockHash,v2.Header.Prev,v2.Header.Height,sk,pk)
                            //if ack==nil {
                            //    panic("Respone function! cannt generate respone")
                            //}
                            //c.SendMsg<-ack
                            //break
                        }
                    } else {
                    // respone the Query to a Future block  
                    // No Respone
                    }
                }
            } 

        }
        // respone to the Query to other
        // No Respone

	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Release lock, Time: %v\n",c.Index,  time.Now().String())
    c.lck.Unlock()
	}
}

func (c *MyConsensus) Respone(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
	tricker := time.NewTicker(time.Duration(c.interval) * 100 * time.Millisecond)
	for {
		<-tricker.C
        c.lck.Lock()
		fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Get lock, Time: %v\n",c.Index,   time.Now().String())
		//b:=<-c.blockresponechan
		//c.querymsglock.Lock()
		for _, v := range c.query {
		//for k, v := range c.query {
			fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Respone to query, query block %v,prev %v,height %d,count %d, Time: %v\n",c.Index,v.id,v.prev,v.height,v.count,time.Now().String())
            if v.ifresp==true {
                fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Query: responed continue, Time: %v\n",c.Index,time.Now().String())
                continue
            }
			//TBC
			hash := v.id
            // Respone to a commitblock
            for _,v2:=range c.commitblock {
                if 0==bytes.Compare(v.id, v2.Header.BlockHash) {
                    v.ifresp=true
                    ack:=c.ackmsg(constdef.ACK,v2.Header.BlockHash,v2.Header.Prev,v2.Header.Height,c.count,sk,pk)
                    if ack==nil {
                        panic("Respone function! cannt generate respone")
                    }
                    c.SendMsg<-ack
                    break
                }
            }

            //Respone to a to-be-commitblock 
            if v.ifresp==true {
                continue
            }
            if c.choosed==nil {
                continue
            } else {
                if 0==bytes.Compare(v.prev,c.choosed.Header.Prev) {
                    if 0==bytes.Compare(v.id,c.choosed.Header.BlockHash) {
                        v.ifresp=true
                        ack:=c.ackmsg(constdef.ACK,c.choosed.Header.BlockHash,c.choosed.Header.Prev,c.choosed.Header.Height,c.count,sk,pk)
                        //ack:=c.ackmsg(constdef.ACK,v2.Header.BlockHash,v2.Header.Prev,v2.Header.Height,c.count,sk,pk)
                        if ack==nil {
                            panic("Respone function! cannt generate respone")
                        }
                        c.SendMsg<-ack
                    } else {
                        v.ifresp=true
                        ack:=c.ackmsg(constdef.NOACK,hash,c.choosed.Header.BlockHash,c.choosed.Header.Height,c.count,sk,pk)
                        if ack==nil {
                            panic("Respone function! cannt generate respone")
                        }
                        c.SendMsg<-ack
                    }
                }
            }
        }
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Release lock, Time: %v\n",c.Index,  time.Now().String())
        c.lck.Unlock()
	}
}

            // Respone to a future block 
//            if v.ifresp==true {
//                continue
//            }


			//Respone to a committed block
//			if c.isACommitBlock(hash) { // query a commitblock
//				ack := c.ackmsg(constdef.ACK, hash, []byte(""), nil, sk, pk)
//				//ack := c.ackmsg(constdef.ACK, hash, b.Header.BlockHash, nil, sk, pk)
//				if ack != nil {
//					fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | block %v is a committed block, respone ack, time: %v\n",c.Index,  v.id, time.Now().String())
//		            fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Respone Message %v, Time: %v\n",c.Index, ack, time.Now().String())
//					c.SendMsg <- ack
//					//TBC
//					v.ifresp=true
//					fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Remove the query to block %v, time: %v\n",c.Index, v.id, time.Now().String())
//					//delete(c.query, k)
//				}
//				// respone to a to-be-committed block
//			} else if c.choosed == nil { // we have no to-be-committed block  but somebody query a new block
//                continue
//			//	msg := missingmsg(hash)
//			//	fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | query block %v is a missing block ,time: %v \n",c.Index, v.id, time.Now().String())
//		    //    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Missing Message %v, Time: %v\n",c.Index,msg, time.Now().String())
//			//	c.SendMsg <- msg
//			} else { // we have a to-be-committed block
//				b := c.choosed
//				//				if cmp := bytes.Compare(b.Header.BlockHash, hash); cmp != 0 { // query a future block
//				//					msg := missingmsg(hash)
//				//                    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | query block %v is a future block, we don't ,time: %v \n",v.id,time.Now().String())
//				//                    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | query block %v is a future block ,time: %v \n",v.id,time.Now().String())
//				//					v.ifresp = true
//				//					//delete(c.query,k)
//				//					c.SendMsg <- msg
//				//				}
//				if cmp := bytes.Compare(b.Header.BlockHash, hash); cmp == 0 { //query a to be committed block
//					ack := c.ackmsg(constdef.ACK, hash, b.Header.BlockHash, nil, sk, pk)
//					if ack != nil {
//						//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | query block %v is a future block ,time: %v \n",v.id,time.Now().String())
//						fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | query block %v is a to-be-committed block ,time: %v \n",c.Index, v.id, time.Now().String())
//						//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | send ack 4, time: %v\n", time.Now().String())
//						v.ifresp = true
//		                fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Respone Message %v, Time: %v\n",c.Index,ack, time.Now().String())
//						c.SendMsg <- ack
//						fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Remove the query to block %v, time: %v\n",c.Index, v.id, time.Now().String())
//
//						//delete(c.query, k)
//					}
//				}
//			}
//		}
		//c.querymsglock.Unlock()
//		fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | Release lock, Time: %v\n",c.Index,  time.Now().String())
//        c.lck.Unlock()
//	}
//}

func (c *MyConsensus) UpdateQueryList() {
	//tricker := time.NewTicker(10* time.Second)
//	for {
//		<-c.updateQueryList
//		c.querymsglock.Lock()
//		fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | UpdateQueryList |update query list, time: %v\n", c.Index, time.Now().String())
//		for k, v := range c.query {
//			if bytes.Compare(v.prev, c.prev) != 0 && c.isACommitBlock(v.id) {
//				delete(c.query, k)
//			}
//		}
//		c.querymsglock.Unlock()
//	}
}

func propserTomessage(propser *block.Proposer) *gossip.MessageImp {
	//TBC
	bs := propser.ToBytes()
	msg := new(gossip.MessageImp)
	msg.Bs = bs
	msg.Ttype = constdef.NEWPROPOSER
    msg.TimeStamp=time.Now().String()
	return msg
}

func test(p *block.Proposer) bool {
    pk := crypt.DecodePk(string(p.Pk))
	_, err := ecvrf.P256Sha256Tai.Verify(pk, p.Prev, p.Proof)
    if err!=nil {
        fmt.Fprintf(os.Stdout, "Error to verify ecvrf")
    }
    return true
}

func (c *MyConsensus) CompeteForProposer(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
	pks := crypt.EncodePk(pk)
	for {
		blockhash := <-c.propserElection
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | CompeteForProposer | proposer election, prev block hash %v, prev height %d, time: %v\n",blockhash,len(c.commitblock)-1, time.Now().String())
		hash, proof, err := ecvrf.P256Sha256Tai.Prove(sk, []byte(blockhash))
		if err != nil {
			panic(err)
		}
	    _, err = ecvrf.P256Sha256Tai.Verify(pk, []byte(blockhash), proof)
        if err!=nil {
            panic("ECVRF ERROR")
        }
		//TBC
        prob:=float64(c.nextRound)/float64(c.total)
		//if random.Select(hash, c.tao, c.totalnode) {
		if random.Select(hash, prob, c.weight) {
			propser := new(block.Proposer)
			//propser.Hash = append(propser.Hash, hash...)
			propser.Hash = hash
			propser.Proof = proof
			//propser.Proof = append(propser.Proof, proof...)
			propser.Pk = []byte(pks)
			//propser.Pk = append(propser.Pk, pks...)
			propser.Prev = []byte(blockhash)
			//propser.Prev = append(propser.Prev, c.prev...)
			pmsg := propserTomessage(propser)
			//fmt.Fprintf(os.Stdout," CONSENSUS | CompeteForProposer | Broadcast proposer message of block %d, time: %v\n", c.height, time.Now().String())
            //test(propser)
			//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | CompeteForProposer | proposer election, prev block hash %v, prev height %d, time: %v\n", blockhash, len(c.commitblock)-1, time.Now().String())
			fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | CompeteForProposer | proposer election, prev block hash %v, prev height %d, time: %v\n", c.Index, blockhash, c.height, time.Now().String())
            fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | CompeteForProposer | Prev: %v, Hash: %v, Proof: %v, Pk %s, time: %v\n", c.Index, blockhash,hash,proof,pks,time.Now().String())
			fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | CompeteForProposer | Braodcast proposer message %v, time: %v\n", c.Index, pmsg, time.Now().String())
			c.SendMsg <- pmsg
		}
	}
}

func (c *MyConsensus) Bootstrap(b *block.Block, sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
    if c.isbootstrap!=true {
        //c.lck.Lock()
	    c.prev = b.Header.BlockHash
	    //c.nowproposer = 0
//	    for _, v := range b.Proposer {
//		    c.propserlist = append(c.propserlist, string(v.Pk))
//		    //c.propserlist = append(c.propserlist, string(v.Pk))
//	    }

	    c.commitblock = append(c.commitblock, b)

	    c.height = 1

	    c.propserElection <- string(b.Header.BlockHash)

    
	    c.proposercheck = true
        //if c.ttype=="algorand" {
            //c.AlgorandGenerateBlock(sk,pk)
        //}
        //c.lck.Unlock()
        c.newBlockTime=time.Now()
		for k, v := range c.waitingblock {
            if c.isACommitBlock(v.Header.BlockHash) {
				delete(c.waitingblock, k)
            } else if bytes.Compare(v.Header.Prev, c.prev) == 0 {
				c.blockcache = append(c.blockcache, v)
                if len(c.blockcache)>=2{
                    //TBC
                    // Malicious block
                    panic("Two to be committed block ")
                }
                //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Set choosed block %v\n", c.Index, v.Header.BlockHash)
                //TBC  
                // deep copy!
                //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Set choosed block, blockhash: %v, block height %v \n",c.Index,v.Header.BlockHash,v.Header.Height)
                if c.choosed==nil {
                    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Set choosed block, blockhash: %v, block height %v \n",c.Index,v.Header.BlockHash,v.Header.Height)
					c.choosed = v
                    c.newBlockTime=time.Now()
                    c.QueryBlock(sk,pk)
                } else {
                    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | choosed block, blockhash: %v, block height %v, prev %v,pk %v \n",c.Index,c.choosed.Header.BlockHash,c.choosed.Header.Height,c.choosed.Header.Prev,c.choosed.Header.Pk)
                    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | another cached block has same prev with choosed block, blockhash: %v, block height %v, prev %v,pk %v\n",c.Index,v.Header.BlockHash,v.Header.Height,v.Header.Prev,v.Header.Pk)
                    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | another cached block, blockhash: %v, block height %v, prev %v,pk %v \n",c.Index,c.choosed.Header.BlockHash,c.choosed.Header.Height,c.choosed.Header.Prev,c.choosed.Header.Pk)
                    //panic
                }
				delete(c.waitingblock, k)
			}
		}
    }
}

// consensus serve function
// consensus process input Message
// data message:
//      client tx request
//      new block
//      new intra-block
//      request missing block
// consensus message(controll message:)
//      query a block
//      ack a block
func (c *MyConsensus) Serve(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
    sks:=crypt.EncodeSk(sk)
    pks:=crypt.EncodePk(pk)
    fmt.Fprintf(os.Stdout, "index %v | my sk: string %v bytes %v, my pk string %v bytes %v\n, my weight: %d",c.Index,sks,[]byte(sks),pks, []byte(pks),c.weight)
    // inside process
    if c.ismalicious{
		fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | I am the Malicious Node, Time: %v\n",c.Index,time.Now().String())
    }
    //	go c.Core(sk, pk)
    //go c.GenerateMyintra(sk,pk)
    //go c.IntraToBlock(sk,pk)
   //     sks:=crypt.EncodeSk(sk)
   //     pks:=crypt.EncodePk(pk)
   //     fmt.Fprintf(os.Stdout, "index %v | my sk: string %v bytes %v, my pk string %v bytes %v\n",c.Index,sks,[]byte(sks),pks, []byte(pks))
    go c.initBlock(sk, pk)
    go c.CompeteForProposer(sk, pk)
    go c.GenerateBlock(sk, pk)
    //	go c.QueryBlock(sk, pk)
    go c.ResponeWithProSelection(sk, pk)
    //go c.Respone(sk, pk)
    //	go c.UpdateQueryList()
    if c.ttype=="algorand" {
        //go c.SumQueryResult(sk, pk)
        go c.AlgorandSum(sk, pk)
    } else if c.ttype=="my" {
        go c.SumQueryResult(sk, pk)
    } else if c.ttype=="laska" {
        go c.LaSKASumQueryResult(sk,pk)
    }
    // process Recv Msg
    for {
        if c.RecvMsg2active==true  {
            msg:=<-c.RecvMsg2
            //msg := <-c.RecvMsg
            if msg.Ttype == constdef.NEWPROPOSER {
                go c.RecvProposer(msg.Bs)
            }
            if msg.Ttype == constdef.TX {
                go c.Process_ClienTx(constdef.CLIENT, msg.Bs)
            }
            if msg.Ttype == constdef.BLOCK {
                go c.RecvBlock(msg.Bs, sk, pk)
            }
            if msg.Ttype == constdef.MISSBLOCK {
                go c.SendMissingBlock(&msg)
            }
            if msg.Ttype == constdef.CONSENSUS {
                go c.RecvConsensusMsg(msg.Bs, sk, pk)
            }
        } else {
            msg := <-c.RecvMsg
            //msg := <-c.RecvMsg
            if msg.Ttype == constdef.NEWPROPOSER {
                go c.RecvProposer(msg.Bs)
            }
            if msg.Ttype == constdef.TX {
                go c.Process_ClienTx(constdef.CLIENT, msg.Bs)
            }
            if msg.Ttype == constdef.BLOCK {
                go c.RecvBlock(msg.Bs, sk, pk)
            }
            if msg.Ttype == constdef.MISSBLOCK {
                go c.SendMissingBlock(msg)
            }
            if msg.Ttype == constdef.CONSENSUS {
                go c.RecvConsensusMsg(msg.Bs, sk, pk)
            }
        }

//    if c.ttype=="algorand" {
//        //c.recvResponetime=time.Now()
//        //c.recvblocktime=time.Now()
//        c.ifgenerateblock=false
//        c.ifresponeblock=false
//        go c.initBlock(sk, pk)
//        go c.ReadSimulated(sk, pk)
//        go c.AlgorandResponeWithProSelection(sk, pk)
//        go c.AlgorandSumQueryResult(sk, pk)
//        for {
//            if c.RecvMsg2active==true  {
//                msg:=<-c.RecvMsg2
//                if msg.Ttype == constdef.TX {
//                    go c.Process_ClienTx(constdef.CLIENT, msg.Bs)
//                }
//                if msg.Ttype == constdef.BLOCK {
//                    go c.AlgorandRecvBlock(msg.Bs, sk, pk)
//                }
//                //if msg.Ttype == constdef.MISSBLOCK {
//                //    go c.SendMissingBlock(&msg)
//                //}
//                if msg.Ttype == constdef.CONSENSUS {
//                    //go c.RecvConsensusMsg(msg.Bs, sk, pk)
//                    go c.AlgorandRecvRespone(msg.Bs)
//                }
//            } else {
//                msg := <-c.RecvMsg
//                //msg := <-c.RecvMsg
//                if msg.Ttype == constdef.NEWPROPOSER {
//                    go c.RecvProposer(msg.Bs)
//                }
//                if msg.Ttype == constdef.TX {
//                    go c.Process_ClienTx(constdef.CLIENT, msg.Bs)
//                }
//                if msg.Ttype == constdef.BLOCK {
//                    go c.RecvBlock(msg.Bs, sk, pk)
//                }
//                if msg.Ttype == constdef.MISSBLOCK {
//                    go c.SendMissingBlock(msg)
//                }
//                if msg.Ttype == constdef.CONSENSUS {
//                    go c.RecvConsensusMsg(msg.Bs, sk, pk)
//                }
//            }
//        }
//    } else if c.ttype=="my" {
//        // inside process
//        if c.ismalicious{
//		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Respone | I am the Malicious Node, Time: %v\n",c.Index,time.Now().String())
//        }
//        //	go c.Core(sk, pk)
//        //go c.GenerateMyintra(sk,pk)
//        //go c.IntraToBlock(sk,pk)
//   //     sks:=crypt.EncodeSk(sk)
//   //     pks:=crypt.EncodePk(pk)
//   //     fmt.Fprintf(os.Stdout, "index %v | my sk: string %v bytes %v, my pk string %v bytes %v\n",c.Index,sks,[]byte(sks),pks, []byte(pks))
//        go c.initBlock(sk, pk)
//        go c.CompeteForProposer(sk, pk)
//        go c.GenerateBlock(sk, pk)
//        //	go c.QueryBlock(sk, pk)
//        go c.ResponeWithProSelection(sk, pk)
//        //go c.Respone(sk, pk)
//        //	go c.UpdateQueryList()
//        go c.SumQueryResult(sk, pk)
//        // process Recv Msg
//        for {
//            if c.RecvMsg2active==true  {
//                msg:=<-c.RecvMsg2
//                //msg := <-c.RecvMsg
//                if msg.Ttype == constdef.NEWPROPOSER {
//                    go c.RecvProposer(msg.Bs)
//                }
//                if msg.Ttype == constdef.TX {
//                    go c.Process_ClienTx(constdef.CLIENT, msg.Bs)
//                }
//                if msg.Ttype == constdef.BLOCK {
//                    go c.RecvBlock(msg.Bs, sk, pk)
//                }
//                if msg.Ttype == constdef.MISSBLOCK {
//                    go c.SendMissingBlock(&msg)
//                }
//                if msg.Ttype == constdef.CONSENSUS {
//                    go c.RecvConsensusMsg(msg.Bs, sk, pk)
//                }
//            } else {
//                msg := <-c.RecvMsg
//                //msg := <-c.RecvMsg
//                if msg.Ttype == constdef.NEWPROPOSER {
//                    go c.RecvProposer(msg.Bs)
//                }
//                if msg.Ttype == constdef.TX {
//                    go c.Process_ClienTx(constdef.CLIENT, msg.Bs)
//                }
//                if msg.Ttype == constdef.BLOCK {
//                    go c.RecvBlock(msg.Bs, sk, pk)
//                }
//                if msg.Ttype == constdef.MISSBLOCK {
//                    go c.SendMissingBlock(msg)
//                }
//                if msg.Ttype == constdef.CONSENSUS {
//                    go c.RecvConsensusMsg(msg.Bs, sk, pk)
//                }
//            }
//            //msg := <-c.RecvMsg
//            //if msg.Ttype == constdef.NEWPROPOSER {
//            //	go c.RecvProposer(msg.Bs)
//            //}
//            //if msg.Ttype == constdef.TX {
//            //	go c.Process_ClienTx(constdef.CLIENT, msg.Bs)
//            //}
//            //if msg.Ttype == constdef.BLOCK {
//            //	go c.RecvBlock(msg.Bs, sk, pk)
//            //}
//            //if msg.Ttype == constdef.MISSBLOCK {
//            //	go c.SendMissingBlock(msg)
//            //}
//            //if msg.Ttype == constdef.CONSENSUS {
//            //	go c.RecvConsensusMsg(msg.Bs, sk, pk)
//            //}
//        }
//
    }
}
