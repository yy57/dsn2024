package consensus

import (
	"bearchain/block"
	"crypto/ecdsa"
)
func (c *MyConsensus) SimulatedToIBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
//	for {
//		select {
//		case sim := <-c.simluated:
//			c.cache = append(c.cache, *sim)
//			l := len(c.cache)
//			if l == 2 {
//				b := block.NewBlock(sk, pk, c.cache)
//				//b := block.NewBlock(sk, pk, c.cache)
//				c.l.WriteABlock(b)
//				//block:=block.CreateBlock(cache,l)
//			}
//		}
//	}
}

func txTointra(sk *ecdsa.PrivateKey,pk *ecdsa.PublicKey,prev []byte, res []block.Simulated) *block.Simulated{
    intra:=block.NewIntraBlock(prev,res)
    intra.Complete(sk,pk)
    return nil
}

//func (c *MyConsensus)TimeForNewIBlock(sk *ecdsa.PrivateKey,pk *ecdsa.PublicKey){
//    tricker:=time.NewTicker(time.Duration(c.interval)*time.Second)
//    <-tricker.C
//    c.blocklck.Lock()
//    b:=c.IntraToBlock(sk,pk)
//    if bytes.Compare(c.choosed.Header.BlockHash,b.Header.BlockHash)!=0 {
//        c.choosed=b
//        c.change<-true
//    }
//    c.blocklck.Unlock()
//}
