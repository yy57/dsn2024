package consensus

import (
	"bearchain/block"
	"bearchain/constdef"
	"bearchain/crypt"
	"bearchain/gossip"
	"bearchain/random"
	"bytes"
	"crypto/ecdsa"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/vechain/go-ecvrf"
)

func (c *MyConsensus)SetAlgorandlatency(ltype string, latency int) {
    c.algorandlatencytype=ltype
    c.algorandlatency=latency
}

func (c *MyConsensus)SetAlgorandWaitingtime(ltype string, latency int) {
    c.algorandwaitingtimetype=ltype
    c.algorandwaitingtime=latency
}

func (c *MyConsensus)SetExpectCommittee( i int ) {
    c.expectCommittee=i
}

func (c *MyConsensus)EmptyBlock() *block.Block{
    b:=new(block.Block)
     
    h:=new(block.Header)
    h.Height=c.height
    h.Prev=c.prev
    s:=c.prev
    hstr:=strconv.Itoa(h.Height)
    s=append(s, []byte(hstr)...)
    hash:=sha256.Sum256(s)
    h.BlockHash=hash[:]
     
    b.Header=*h
    return b
}

//func (c *MyConsensus) SumQueryResult(file *os.File) {
func (c *MyConsensus) AlgorandSumQueryResult(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) { 
	//tricker := time.NewTicker(time.Duration(c.interval) * 100 * time.Millisecond)
	tricker := time.NewTicker( 100 * time.Millisecond)
	//tricker := time.NewTicker(1*time.Second)
    //var tricker time.Ticker
    //switch c.algorandlatencytype{
    //case "Mil":
    //    tricker=*time.NewTicker(time.Duration(c.algorandlatency)*time.Millisecond)
    //case "Sec":
    //    tricker=*time.NewTicker(time.Duration(c.algorandlatency)*time.Second)
    //case "Min":
    //    tricker=*time.NewTicker(time.Duration(c.algorandlatency)*time.Minute)
    //default :
    //    panic("Wrong time duration")
    //}
    //var empty *block.Block
    //empty=nil
	for {
		<-tricker.C
        c.lck.Lock()
		fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Get lock, Time: %v\n",c.Index,   time.Now().String())
		//ack := 0
		total := 0
        weightest:=0
        weightesthash:=make([]byte,0)
        var weightestResult algoresult
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Check for block %v, height %d, Time: %v\n",c.Index, c.algorandquery,c.height, time.Now().String())
        if c.height==0 {
		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Release lock, Time: %v\n",c.Index,   time.Now().String())
            c.recvblocktime=time.Now()
            c.recvResponetime=time.Now()
            c.lck.Unlock()
            continue
        }
        if !c.ifresponeblock {
            c.lck.Unlock()
            continue
        }
        //if !c.ifrecvrespone {
        //    c.recvResponetime=time.Now()
        //    c.lck.Unlock()
        //    continue
        //}
        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | block in Cache: %d,   Time: %v\n",c.Index,v.Header.BlockHash,v.Header.Prev,v.Header.Height, time.Now().String())
        for _,v:=range c.algorandresult {
		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Result block hash %v, prev %v ,height %d, vote %d, Time: %v\n",c.Index, v.blockhash,v.prev,v.height,v.vote, time.Now().String())
        }

        for _,v:=range c.algorandresult {
            if 0==bytes.Compare(v.prev,c.prev) {
		        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Check for block %v, weight %d, vote %d, Time: %v\n",c.Index, v.blockhash,v.weight,v.vote, time.Now().String())
                total=total+v.vote
                if v.weight>weightest{
                    weightest=v.weight
                    weightesthash=v.blockhash
                    weightestResult=v
                } else if v.weight==weightest{
                    flag:=bytes.Compare(v.blockhash,weightesthash)
                    if flag>0 {
                        weightest=v.weight
                        weightesthash=v.blockhash
                        weightestResult=v
                    } 
                }
            }
        }
		fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | block %v, height %d, weight %d Recv vote %d, total vote %d, expectCommittee %v, recv rate %f, Time: %v\n",c.Index, weightestResult.blockhash,weightestResult.height,weightestResult.weight,weightestResult.vote,total,c.expectCommittee,float32(weightestResult.vote)/float32(c.expectCommittee), time.Now().String())
        //if float32(weightest)/float32(total)>float32(2)/float32(3){
        if float32(weightestResult.vote)/float32(c.expectCommittee)>float32(2)/float32(3){
            c.ifresponeblock=false
	        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | set ifresponeblock false\n ",c.Index )
        //if float32(weightestResult.vote)/float32(total)>float32(2)/float32(3){
            var b *block.Block
            for _,v:=range c.blockcache {
                fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | block in Cache: hash %v, Prev %d, height %d,  Time: %v\n",c.Index,v.Header.BlockHash,v.Header.Prev,v.Header.Height, time.Now().String())
                if 0== bytes.Compare(weightestResult.blockhash,v.Header.BlockHash) {
                    b=v
                }
            }
            // committed 
            //c.newBlockTime=time.Now()
            if b==nil {
                panic("index "+c.Index+"Error")
            }
            c.commitblock = append(c.commitblock, b)
            pks:=crypt.EncodePk(pk)
            if 0==bytes.Compare([]byte(pks),b.Header.Pk) {
                c.lcache.Lock()
                l:=len(b.Txs)
                c.cache=c.cache[l:]
                c.lcache.Unlock()
            }
		    c.commitblockhash = append(c.commitblockhash, string(b.Header.BlockHash))
		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | -------------------------------Success!!!!!!the choosed block %v,height %d, Recv total Respone%d with %d ack!!!\n",c.Index,  b.Header.BlockHash,b.Header.Height, total,weightestResult.vote)
		    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | -------------------------------Success!!!!!! %d proposer for next round block generation \n",c.Index,  len(b.Proposer))
		    if l:=len(c.commitblock);l>30{ 
                c.commitblock=c.commitblock[l-30:]
		    }
		    if l:=len(c.commitblockhash);l>100{
                c.commitblockhash=c.commitblockhash[l-100:]
		    }
		    c.height = b.Header.Height+1
		    	//c.height = c.height + 1
		    c.cblock = b.Header.Height
		    	//c.cblock = c.cblock + 1
		    c.ctx = c.ctx + len(b.Txs)
		    	//c.commitblock = append(c.commitblock, string(c.choosed.Header.BlockHash))
		    c.prev = b.Header.BlockHash
		    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | commit a block, set choosed block to nil\n",c.Index)
		    //c.choosed = nil
            //c.count=0
		    c.blockcache = c.blockcache[:0]
		    //fmt.Fprintf(os.Stdout, "index %v |  Consensus | commit %d block / %d tran\n",c.Index,  c.cblock, c.ctx)

            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Now committed block:\n ",c.Index)
		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Static | commitblock: %d committed tx: %d,Time: %v\n",c.Index, c.cblock,c.ctx, time.Now().String())
            // update block cache
            // update voting result

		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Static | waiting block len: %d,Time: %v\n",c.Index,len(c.waitingblock), time.Now().String())
		    for k, v := range c.waitingblock {
		        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Static | waiting block %v, prev %v,height %d,Time: %v\n",c.Index,v.Header.BlockHash,v.Header.Prev,v.Header.Height, time.Now().String())
                if c.isACommitBlock(v.Header.BlockHash) {
		            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Static | waiting block len: %d,Time: %v\n",c.Index,len(c.waitingblock), time.Now().String())
		        	delete(c.waitingblock, k)           
                //if c.isACommitBlock(v.Header.BlockHash) {
                } 
                if bytes.Compare(v.Header.Prev, c.prev) == 0 {
		            fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Static | a to-be-committed block in waiting block; hash %v, prev %v,height %d,Time: %v\n",c.Index,v.Header.BlockHash,v.Header.Prev,v.Header.Height, time.Now().String())
                    c.blockcache = append(c.blockcache, v)
                }
		    }
//            c.algorandquery=c.algorandquery[:0]
//            for k,v:=range c.waitingquery {
//                if c.isACommitBlock(v.hash) {
//                    delete(c.waitingquery,k)
//                } else if bytes.Compare(v.prev, c.prev) == 0 {
//		            fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary |  waiting query %v, prev %v,height %d,Time: %v\n",c.Index,v.hash,v.prev,v.height, time.Now().String())
//                    c.algorandquery=append(c.algorandquery, v)
//                }
//            }
            if len(c.blockcache)!=0 {
		        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Static | After sum, blockcache not empty, set recvblocktime,Time: %v\n",c.Index, time.Now().String())
                //c.ifrecvblock=true
                //c.recvblocktime=time.Now()
                c.recvblocktime=time.Now()
            }
            for k,v:=range c.algorandresult{
                if c.isACommitBlock(v.blockhash) {
                    delete(c.algorandresult,k)
                }
            }
            
            var count int
            count =0
            for _,v:=range c.algorandresult {
                if 0==bytes.Compare(v.prev,c.prev) {
                    count=count+1
                }
            }
            if count>0 {
                c.recvResponetime=time.Now()
            }
            c.AlgorandGenerateBlock(sk,pk)
            //c.ifgenerateblock=true
		    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Release lock, Time: %v\n",c.Index,   time.Now().String())
            //c.lck.Unlock()
        } else {
            var newtime time.Time
            //newtime=c.newBlockTime.Add(20*time.Second)
            switch c.algorandwaitingtimetype{
                case "Mil":
                    newtime=c.recvResponetime.Add(time.Duration(c.algorandwaitingtime)*time.Millisecond)
                case "Sec":
                    newtime=c.recvResponetime.Add(time.Duration(c.algorandwaitingtime)*time.Second)
                case "Min":
                    newtime=c.recvResponetime.Add(time.Duration(c.algorandwaitingtime)*time.Minute)
                default :
                    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | waitingtime type %s, nowtime %v \n",c.Index,c.algorandwaitingtimetype,time.Now().String())
                    panic("Wrong time duration")
            }

            timenow:=time.Now()
            if timenow.After(newtime) {
	            fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | set ifresponeblock false\n ",c.Index )
                c.ifresponeblock=false
                //Create Empty Block
                //TBC
                empty:=c.EmptyBlock()
                // committed 
                //c.newBlockTime=time.Now()
                c.commitblock = append(c.commitblock, empty)
		        c.commitblockhash = append(c.commitblockhash, string(empty.Header.BlockHash))
                fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | timeout: newblocktime %v nowtime %v \n",c.Index,c.recvResponetime.String(),timenow.String())
		        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | -------------------------------Success!!!!!! Empty block %v,height %d, Recv total Respone%d with %d ack!!!\n",c.Index,  empty.Header.BlockHash,empty.Header.Height, total,weightest)
		        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | -------------------------------Success!!!!!! %d proposer for next round block generation \n",c.Index,  len(b.Proposer))
		        if l:=len(c.commitblock);l>30{ 
                    c.commitblock=c.commitblock[l-30:]
		        }
		        if l:=len(c.commitblockhash);l>100{
                    c.commitblockhash=c.commitblockhash[l-100:]
		        }
		        c.height = empty.Header.Height+1
		        	//c.height = c.height + 1
		        c.cblock = empty.Header.Height
		        	//c.cblock = c.cblock + 1
		        //c.ctx = c.ctx + len(b.Txs)
		        	//c.commitblock = append(c.commitblock, string(c.choosed.Header.BlockHash))
		        c.prev = empty.Header.BlockHash
		        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | commit a block, set choosed block to nil\n",c.Index)
		        //c.choosed = nil
                //c.count=0
		        c.blockcache = c.blockcache[:0]
		        //fmt.Fprintf(os.Stdout, "index %v |  Consensus | commit %d block / %d tran\n",c.Index,  c.cblock, c.ctx)

                //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Now committed block:\n ",c.Index)
		        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Static | commitblock: %d committed tx: %d,Time: %v\n",c.Index, c.cblock,c.ctx, time.Now().String())
                // update block cache
                // update voting result
		        for k, v := range c.waitingblock {
                    if c.isACommitBlock(v.Header.BlockHash) {
		        		delete(c.waitingblock, k)
                    } else if bytes.Compare(v.Header.Prev, c.prev) == 0 {
		        		c.blockcache = append(c.blockcache, v)
                    }
		        }
                //c.algorandquery=c.algorandquery[:]
                //for k,v:=range c.waitingquery {
                //    if c.isACommitBlock(v.hash) {
                //        delete(c.waitingquery,k)
                //    } else if bytes.Compare(v.prev, c.prev) == 0 {
                //        c.algorandquery=append(c.algorandquery, v)
                //    }
                //}
                for k,v:=range c.algorandresult{
                    if c.isACommitBlock(v.blockhash) {
                        delete(c.algorandresult,k)
                    }
                    //if bytes.Compare(v.prev,c.prev)==0 {
                    //    delete(c.algorandresult,k)
                    //}
                }
                var count int
                count =0
                for _,v:=range c.algorandresult {
                    if 0==bytes.Compare(v.prev,c.prev) {
                        count=count+1
                    }
                }
                if count>0 {
                    c.recvResponetime=time.Now()
                }
                c.AlgorandGenerateBlock(sk,pk)
                //c.ifgenerateblock=true
            }
		    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Release lock, Time: %v\n",c.Index,   time.Now().String())
            //c.lck.Unlock()
        }
		fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandSummary | Release lock, Time: %v\n",c.Index,   time.Now().String())
        c.lck.Unlock()
	}
}

func (c *MyConsensus) AlgorandGenerateBlock(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
	c.lcache.Lock()
    defer c.lcache.Unlock()
	var newblock *block.Block
    newblock=nil
	l := len(c.cache)
	fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | tx cache len %d\n ",c.Index,  l)
    c.recvblocktime=time.Now()
	fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | set ifgenerateblock true\n ",c.Index )
    c.ifgenerateblock=true
	if l > c.txnum {
        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | para: prev %v, height  %d\n ",c.Index,  c.prev,c.height)
		newblock = block.AlgorandNewBlock(sk, pk, c.prev, c.height,c.weight, c.cache[:c.txnum],nil)
        if  newblock ==nil {
            panic("empty block")
        }
        prob:=float64(c.expectProposer)/float64(c.total)
        //prob:=float64(c.total)/float64(c.total)
        if !random.Select(newblock.Header.Sig, prob, c.weight) {
            return
        }
		//c.cache = c.cache[c.txnum:]
	} else {
        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | para: prev %v, height  %d\n ",c.Index,  c.prev,c.height)
		newblock = block.AlgorandNewBlock(sk, pk, c.prev, c.height,c.weight, c.cache,nil)
        if  newblock ==nil {
            panic("empty block")
        }
        prob:=float64(c.expectProposer)/float64(c.total)
        //prob:=float64(c.total)/float64(c.total)
        if !random.Select(newblock.Header.Sig, prob, c.weight) {
            return
        }
	    //c.cache = c.cache[l:]
	}
    c.newBlockTime=time.Now()
	fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | GenerateBlock | new block hash %v, block height %d, newBlockTime  %v\n ",c.Index, newblock.Header.BlockHash, newblock.Header.Height,c.newBlockTime.String())
	//c.choosed = newblock
    c.blockcache=append(c.blockcache, newblock)
	blockmsg := blockToGossipMsg(newblock)
	c.SendMsg <- blockmsg
	//c.lcache.Unlock()
}

//  height field as weight field
func (c *MyConsensus)algoAckmsg2(flag string,blockhash []byte,prev []byte,height int, weight int, vote int,sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) *gossip.MessageImp{
    if blockhash == nil {
        panic("ackmsg Empty blockhash")
    }
    msg:=new(ConsensusMessage)
    //Type
    msg.Ttype=constdef.RESPONE

    //Block hash
    msg.BlockHash=make([]byte, 0)
    msg.BlockHash = append(msg.BlockHash, blockhash...)
    //msg.BlockHash = append(msg.BlockHash, c.choosed.Header.BlockHash...)

    // Prev
    msg.Prev=make([]byte,0 )
    msg.Prev=append(msg.Prev,prev...)
    //msg.Prev=append(msg.Prev,c.choosed.Header.Prev...)

    // height
    // height is reused as weight in Algorand
    msg.Height=height

    msg.Weight=weight

    msg.Vote=vote

    // ifACK
    if flag==constdef.ACK {
        msg.ACK=true
    } else if flag==constdef.NOACK {
        msg.ACK=false
    }

    // Pk
    pks:=[]byte(crypt.EncodePk(pk))
    msg.Pk=make([]byte, 0)
    msg.Pk=append(msg.Pk, pks...)

    //msghash
    bs:=make([]byte,0)
    bs=append(bs, []byte(msg.Ttype)...)
    bs=append(bs, msg.BlockHash...)
    bs=append(bs, msg.Prev...)
    //hstr:=strconv.Itoa(msg.Height)
    //cstr:=strconv.Itoa(msg.Count)
    //bs=append(bs,[]byte(hstr)...)
    //bs=append(bs,[]byte(cstr)...)
    bs=append(bs, pks...)
    h:=sha256.Sum256(bs)
    msg.MsgHash=make([]byte, 0)
    msg.MsgHash = append(msg.MsgHash, h[:]...)

    // Sig
    beta,proof,err:=ecvrf.P256Sha256Tai.Prove(sk,msg.MsgHash)
    if err!=nil {
        fmt.Fprintf(os.Stdout," query msg error1\n")
        panic(err)
    }
    //TBC
    // Random Selction
    prob:=float64(c.expectCommittee)/float64(c.total)
    if !random.Select(beta, prob, c.weight) {
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | ackmsg | my respone to Query hash %v, prev %d, height %d has not been selected, time: %v\n", c.Index, blockhash,prev,height, time.Now().String())
        return nil
    }
	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | ackmsg | my respone to Query hash %v, prev %d, height %d has been selected, time: %v\n", c.Index, blockhash,prev,height, time.Now().String())
    //fmt.Fprintf(os.Stdout," query msg: append proof sig\n")
    msg.Sig=make([]byte,0 )
    msg.Sig= append(msg.Sig, beta...)

    // Proof
    //fmt.Fprintf(os.Stdout," query msg: append proof\n")
    msg.Proof=make([]byte, 0)
    msg.Proof = append(msg.Proof, proof...)


    gmsp:=new(gossip.MessageImp)
    data,err:=msg.ToBytes()
    if err!=nil {
        fmt.Fprintf(os.Stdout," query msg error2\n")
        panic(err)
    }
    gmsp.Bs=data
    gmsp.Ttype=constdef.CONSENSUS
    gmsp.Info=string(msg.BlockHash)
    return gmsp
}

func (c *MyConsensus) AlgorandResponeWithProSelection(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
	//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandRespone | interval %d, Time: %v\n",c.Index, c.interval,  time.Now().String())
	//tricker := time.NewTicker(time.Duration(c.interval) * 100 * time.Millisecond)
	tricker := time.NewTicker(  100 * time.Millisecond)
	//tricker := time.NewTicker( 2* time.Second)
//    var tricker time.Ticker
//    switch c.algorandlatencytype{
//    case "Mil":
//        tricker=*time.NewTicker(time.Duration(c.algorandlatency)*time.Millisecond)
//    case "Sec":
//        tricker=*time.NewTicker(time.Duration(c.algorandlatency)*time.Second)
//    case "Min":
//        tricker=*time.NewTicker(time.Duration(c.algorandlatency)*time.Minute)
//    default :
//        panic("Wrong time duration")
//    }
    //var timelabel time.Time
    //timelabel=time.Now()
    //var height int
    //height=c.height
	for {
		<-tricker.C
        c.lck.Lock()
		fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandRespone | Get lock, Time: %v\n",c.Index,   time.Now().String())
        if !c.ifgenerateblock {
		        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandRespone | Release lock, Time: %v\n",c.Index,   time.Now().String())
                c.lck.Unlock()
                continue
        }
//        if !c.ifrecvblock {
//            c.recvblocktime=time.Now()
//        }
		fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandRespone | len of block cache %d, Time: %v\n",c.Index, len(c.blockcache),  time.Now().String())
        if len(c.blockcache)<c.expectProposer-1 {
            var newtime time.Time
            switch c.algorandwaitingtimetype{
                case "Mil":
                    newtime=c.recvblocktime.Add(time.Duration(c.algorandwaitingtime)*time.Millisecond)
                case "Sec":
                    newtime=c.recvblocktime.Add(time.Duration(c.algorandwaitingtime)*time.Second)
                case "Min":
                    newtime=c.recvblocktime.Add(time.Duration(c.algorandwaitingtime)*time.Minute)
                default :
                    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | waitingtime type %s, nowtime %v \n",c.Index,c.algorandwaitingtimetype,time.Now().String())
                    panic("Wrong time duration")
            }
            timenow:=time.Now()
            if timenow.Before(newtime) {
		        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandRespone | Release lock, Time: %v\n",c.Index,   time.Now().String())
                c.lck.Unlock()
                continue
            }
        }
        //timelabel=time.Now()
        var weightest int
        weightest=0
        weightesthash:=make([]byte,0)
        var weightestq *block.Block
        for _,v:=range c.blockcache{
            //fmt.Fprintf(os.Stdout, "index %v | Consensus | AlgorandRespone | Respone Process block %v, prev %v, height %d, time: %v\n", c.Index,v.hash, v.prev,v.height , time.Now().String())
            if v.Header.Weight>weightest {
                weightest=v.Header.Weight
                weightesthash=v.Header.BlockHash
                weightestq=v
            } else if v.Header.Weight==weightest{
                cmp:=bytes.Compare(v.Header.BlockHash,weightesthash)
                if cmp>0 {
                    weightest=v.Header.Weight
                    weightesthash=v.Header.BlockHash
                    weightestq=v
                }
            }
        }
        if  weightest!=0 {
            //c.ifrecvblock=false
            // 
            c.ifresponeblock=true
            c.ifgenerateblock=false
	        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandResponeWithProSelection | set ifgenerateblock false\n ",c.Index )
	        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandResponeWithProSelection | set ifresponeblock true\n ",c.Index )
	        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandResponeWithProSelection | Finish Respone\n ",c.Index )
            c.recvResponetime=time.Now()
            //fmt.Fprintf(os.Stdout, "index %v | Consensus | AlgorandRespone | AlgorandRespone to block %v, time: %v\n", c.Index, weightesthash, time.Now().String())
            ack:=c.algoAckmsg2(constdef.ACK,weightestq.Header.BlockHash,weightestq.Header.Prev,weightestq.Header.Height,weightestq.Header.Weight,c.weight,sk,pk)
            if ack!=nil{
                fmt.Fprintf(os.Stdout, "index %v | Consensus | AlgorandRespone | AlgorandRespone to block %v, prev %v, height %d,pk %v, time: %v\n", c.Index,weightestq.Header.BlockHash,weightestq.Header.Prev,weightestq.Header.Height,crypt.EncodePk(pk), time.Now().String())
                c.SendMsg<-ack
                mypk:=crypt.EncodePk(pk)
	            if _, ok := c.algorandresult[string(weightestq.Header.BlockHash)]; !ok {
                    fmt.Fprintf(os.Stdout, "index %v | Consensus | AlgorandRespone | (Self) AlgorandRespone to block %v, prev %v, height %d, time: %v\n", c.Index,weightestq.Header.BlockHash, weightestq.Header.BlockHash,weightestq.Header.Height, time.Now().String())
        //r:=new(algoresult)
                    var r algoresult
                    r.prev=weightestq.Header.Prev
                    r.blockhash=weightestq.Header.BlockHash
                    r.weight=weightestq.Header.Weight
                    r.height=weightestq.Header.Height
                    r.pks=make([]string,0)
                    //mypk:=crypt.EncodePk(pk)
                    r.pks=append(r.pks, mypk)
                    r.vote=c.weight
                    r.choosed=false
		            c.algorandresult[string(weightestq.Header.BlockHash)]=r
                    c.recvResponetime=time.Now()
                } else {
                    pks:=c.algorandresult[string(weightestq.Header.BlockHash)].pks
                    ifexist:=false
                    for _,k:=range pks {
                        if 0==strings.Compare(k,mypk) {
                            ifexist=true
                        }
                    }
                    if !ifexist{
                        result:=c.algorandresult[string(weightestq.Header.BlockHash)]
                        result.pks=append(result.pks, mypk)
                        result.vote=result.vote+c.weight
                        c.algorandresult[string(weightestq.Header.BlockHash)]=result
                    }
                }
            }
        }
		fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | AlgorandRespone | Release lock, Time: %v\n",c.Index,   time.Now().String())
        c.lck.Unlock()
	}
}

func (c *MyConsensus) AlgorandRecvBlock(bs []byte, sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
	newblock := new(block.Block)
	err := json.Unmarshal(bs, newblock)
	if err != nil {
		panic(err)
	}
    //fmt.Fprintf(os.Stdout, "index %v | Consensus | RecvBlock | Recv new block, block hash %v, block height %d, block prev %v, time: %v\n", c.Index, newblock.Header.BlockHash,newblock.Header.Height,newblock.Header.Prev, time.Now().String())
    c.lck.Lock()
	fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Get lock, Time: %v\n",  c.Index, time.Now().String())
	defer fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Release lock, Time: %v\n",c.Index,  time.Now().String())
    defer c.lck.Unlock()
	if !newblock.AlgorandVerify() {
	//if !newblock.Verify() {
        fmt.Fprintf(os.Stdout, "index %v | Consensus | RecvBlock | New block verify fail drop it, block hash %v, block height %d, block prev %v, time: %v\n", c.Index, newblock.Header.BlockHash,newblock.Header.Height,newblock.Header.Prev, time.Now().String())
		return
	}

    // init block
	if bytes.Compare(newblock.Header.Prev, []byte("start")) == 0 {
        fmt.Fprintf(os.Stdout, "index %v | Consensus | RecvBlock | Block(hash %v) is a start block, time: %v\n",c.Index, newblock.Header.BlockHash, time.Now().String())
		c.Bootstrap(newblock,sk,pk)
        c.AlgorandGenerateBlock(sk,pk)
        return
	}
    // committed block
	if c.isACommitBlock(newblock.Header.BlockHash) {
        fmt.Fprintf(os.Stdout, "index %v | Consensus | RecvBlock | Block(hash %v) is a committed block, height %d, time: %v\n",c.Index, newblock.Header.BlockHash,newblock.Header.Height, time.Now().String())
	    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvBlock | Release lock, Time: %v\n",c.Index,  time.Now().String())
		return
	}
	// is a to-be-committed block
	if bytes.Compare(newblock.Header.Prev, c.prev) == 0 {
        if len(c.blockcache)==0{
            //fmt.Fprintf(os.Stdout, "index %v | Consensus | RecvBlock | Recv first to-be-committed block %v, height %d, set recvblocktime, time: %v\n",c.Index, newblock.Header.BlockHash,newblock.Header.Height, time.Now().String())
            c.recvblocktime=time.Now()
            //c.ifrecvblock=true
        }
        if c.isAMissingBlock(newblock.Header.BlockHash){
            fmt.Fprintf(os.Stdout, "index %v | Consensus | RecvBlock | Block(hash %v) Prev %v is a new committed block, height %d, time: %v\n",c.Index, newblock.Header.BlockHash,newblock.Header.Prev,newblock.Header.Height, time.Now().String())
            c.blockcache=append(c.blockcache, newblock)
            //newq:=new(algoquery)
            //newq.pk=string(newblock.Header.Pk)
            //newq.prev=newblock.Header.Prev
            //newq.hash=newblock.Header.BlockHash
            //newq.height=newblock.Header.Height
            //newq.weight=newblock.Header.Weight
            //newq.done=false
            //c.algorandquery=append(c.algorandquery, *newq)
            //fmt.Fprintf(os.Stdout, "index %v | Consensus | cache block len %d,cache blockquery len %d, time: %v\n",c.Index,len(c.blockcache),len(c.algorandquery), time.Now().String())
        }
		return
    } else {
		// is a future block
        fmt.Fprintf(os.Stdout, "index %v | Consensus | Block(hash %v) , prev %v is a future block, height %d, time: %v\n",c.Index, newblock.Header.BlockHash,newblock.Header.Prev,newblock.Header.Height, time.Now().String())
     //   c.waitingblocklck.Lock()
		if _, ok := c.waitingblock[string(newblock.Header.BlockHash)]; !ok {
			c.waitingblock[string(newblock.Header.BlockHash)] = newblock
            //newq:=new(algoquery)
            //newq.pk=string(newblock.Header.Pk)
            //newq.prev=newblock.Header.Prev
            //newq.weight=newblock.Header.Weight
            //newq.height=newblock.Header.Height
            //newq.hash=newblock.Header.BlockHash
            //newq.done=false
            //c.waitingquery[string(newblock.Header.BlockHash)]=*newq
        }
    } 
}


func (c *MyConsensus) AlgorandRecvRespone(bs []byte) {
	cmsg := new(ConsensusMessage)
	err := json.Unmarshal(bs, cmsg)
	if err != nil {
		return
	}
    c.lck.Lock()

    defer c.lck.Unlock()
    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvConsensusMsg | Recv Respone Msg: Blockhash %v, Prev %v, Height %d, Count: %v, Msghash: %v, pk: %v, time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev,cmsg.Height,cmsg.Count,cmsg.MsgHash,cmsg.Pk,time.Now().String())
	blockhash := cmsg.BlockHash
	msghash := cmsg.MsgHash
    if msghash == nil {
        panic("empty respone msg hash")
    }

    pk:=crypt.DecodePk(string(cmsg.Pk))
    beta,err:=ecvrf.P256Sha256Tai.Verify(pk,msghash,cmsg.Proof)
    if err!=nil {
        fmt.Fprintf(os.Stdout,"Fail to Verify vrf msg\n")
        panic(err)
    }
    if 0!=bytes.Compare(beta,cmsg.Sig) {
        fmt.Fprintf(os.Stdout,"VRF verify unmatech\n")
        //2eturnpanic(err)
        return
    }
    //TBC
    // Random Selction
    prob:=float64(c.expectCommittee)/float64(c.total)
    if !random.Select(beta, prob, c.weight) {
		fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | RecvConsensusMsg | this Msg is not selected, time: %v\n", c.Index, time.Now().String())
        return
    }
    //fmt.Fprintf(os.Stdout," query msg: append proof sig\n")
	// respone to a committed block
	for _, v := range c.commitblock {
        if 0== bytes.Compare(v.Header.BlockHash, blockhash) {
            fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | Recv RESPONE to committed block  %v,  block prev %v, height %d, pk %v, time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev,v.Header.Height,cmsg.Pk,time.Now().String())
            return
        }
	}
    // respone to a to-be-commitblock or future block
    var count int
    count =0
    for _,v:=range c.algorandresult {
        if 0==bytes.Compare(v.prev,c.prev) {
            count=count+1
        }
    }
    if count==0 && 0==bytes.Compare(c.prev,cmsg.Prev) {
        //fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | Recv first RESPONE to to-be-cimmitted block %v, block prev %v, height %d, set recvResponetime , time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev, cmsg.Height,time.Now().String())
        //c.ifrecvrespone=true
        c.recvResponetime=time.Now()
    }
    //fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | Recv RESPONE to to-be-cimmitted or future block %v, block prev %v, height %d, time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev, cmsg.Height,time.Now().String())
	if _, ok := c.algorandresult[string(cmsg.BlockHash)]; !ok {
        fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | Recv RESPONE to a new to-be-cimmitted or future block %v, block prev %v, height %d, pk %v, time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev, cmsg.Height,cmsg.Pk,time.Now().String())
        //r:=new(algoresult)
        var r algoresult
        r.prev=cmsg.Prev
        r.blockhash=cmsg.BlockHash
        r.weight=cmsg.Weight
        r.height=cmsg.Height
        //for _,v:=
        //r.pk=string(cmsg.Pk)
        r.pks=make([]string,0)
        r.pks=append(r.pks, string(cmsg.Pk))
        r.vote=cmsg.Vote
        r.choosed=false
		c.algorandresult[string(cmsg.BlockHash)]=r
    } else {
        fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | Recv RESPONE to a exist to-be-cimmitted or future block %v, block prev %v, height %d, pk %v, time: %v\n",c.Index, cmsg.BlockHash,cmsg.Prev, cmsg.Height,cmsg.Pk,time.Now().String())
        pks:=c.algorandresult[string(cmsg.BlockHash)].pks
        ifexist:=false
        for _,k:=range pks {
            if 0==strings.Compare(k,string(cmsg.Pk)) {
                ifexist=true
            }
        }
        if !ifexist{
            result:=c.algorandresult[string(cmsg.BlockHash)]
            result.pks=append(result.pks, string(cmsg.Pk))
            result.vote=result.vote+cmsg.Vote
            c.algorandresult[string(cmsg.BlockHash)]=result
        }
    }

    fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | Now Respone:, time: %v\n",c.Index, time.Now().String())
    for _,v:=range c.algorandresult{
        fmt.Fprintf(os.Stdout, "index %v | CONSENSUS | RecvConsensusMsg | block %v, block prev %v, height %d, Vote %d, time: %v\n",c.Index, v.blockhash,v.prev,v.height,v.vote,time.Now().String())
    }
}

func (c *MyConsensus) AlgorandSum(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
    

	//tricker := time.NewTicker( 300 * time.Millisecond)
    var tricker *time.Ticker
    switch c.ltype {
        case "Mil":
            //tricker=c.newBlockTime.Add(time.Duration(c.latency)*time.Millisecond)
            tricker=time.NewTicker(time.Duration(c.latency)*time.Millisecond)
        case "Sec":
            //newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Second)
            tricker=time.NewTicker(time.Duration(c.latency)*time.Second)
        case "Min":
            //newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Minute)
            tricker=time.NewTicker(time.Duration(c.latency)*time.Minute)
        default :
            panic("Wrong time duration")
    }
    var ifquery bool
	//tricker := time.NewTicker( 100 * time.Millisecond)
	//tricker := time.NewTicker(time.Duration(c.interval) * 100 * time.Millisecond)
	for {
		<-tricker.C
        c.lck.Lock()
        if c.choosed == nil {
            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Waiting for new block, Time: %v\n",c.Index,  time.Now().String())
            c.lck.Unlock()
            continue
        }
        var newtime time.Time
        switch c.ltype {
            case "Mil":
                newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Millisecond)
            case "Sec":
                newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Second)
            case "Min":
                newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Minute)
            default :
                panic("Wrong time duration")
        }
        if !time.Now().After(newtime) {
            fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | waiting for respone of block %d, time: %v\n",c.Index, c.choosed.Header.Height, time.Now().String())
            c.lck.Unlock()
		    continue
        }

		ack := 0
        //totalack:=0
		total :=2000
        totalweight:=0
		//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summay | Check for block %v, height %d, Time: %v\n",c.Index, c.choosed.Header.BlockHash,c.choosed.Header.Height, time.Now().String())
		//for k, v := range c.result {
		//	if bytes.Compare(c.choosed.Header.BlockHash, v.id) == 0 {
		//		total = total + 1
        //        totalweight=totalweight+v.weight
		//		if v.ack == true {
		//			//ack = ack + 1
        //            ack=ack+v.weight
        //        }
		//	} else if c.isACommitBlock(v.id) {
        //        delete(c.result,k)
        //    }
		//}
        // TBC
        //if !ProbCompute(c.thresprob,ack,total) {
        if total<1500{
            c.lck.Unlock()
		    continue
        } else {
        //if float64(ack)/float64(totalweight)>0.685 {
        //if float64(ack)/float64(totalweight)>0.685 {
			c.commitblock = append(c.commitblock, c.choosed)
			c.commitblockhash = append(c.commitblockhash, string(c.choosed.Header.BlockHash))
            count:=c.count
			fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | -------------------------------Success!!!!!!the choosed block %v,height %d, Recv total Respone%d recv ack%d !!!\n",c.Index,  c.choosed.Header.BlockHash,c.choosed.Header.Height, total,ack)
			//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | -------------------------------Success!!!!!! %d proposer for next round block generation \n",c.Index,  len(c.choosed.Proposer))
			//c.l.WriteABlock(c.choosed)
			//if l:=len(c.commitblock);l>30{ 
            //    c.commitblock=c.commitblock[l-30:]
			//}
			//if l:=len(c.commitblockhash);l>100{
            //    c.commitblockhash=c.commitblockhash[l-100:]
			//}
			c.height = c.choosed.Header.Height+1
            if c.height == 110 {
                panic("Already 200 committed block! Stop")
            }
			//c.height = c.height + 1
			c.cblock = c.choosed.Header.Height
			//c.cblock = c.cblock + 1
			c.ctx = c.ctx + len(c.choosed.Txs)
			//c.commitblock = append(c.commitblock, string(c.choosed.Header.BlockHash))
			c.prev = c.choosed.Header.BlockHash
			//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | commit a block, set choosed block to nil\n",c.Index)
			c.choosed = nil
            c.count=0
            c.newBlockTime=time.Now()

			c.blockcache = c.blockcache[:0]
			fmt.Fprintf(os.Stdout, "index %v |  Consensus | commit %d block / %d tran\n",c.Index,  c.cblock, c.ctx)

            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Now committed block:\n ",c.Index)
            //for _,v:=range c.commitblock {
            //    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | height %d\nblockhash %v\n, prev: %v\n",c.Index, v.Header.Height,v.Header.BlockHash,v.Header.Prev)
            //    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | it contain Proposer:\n",c.Index )
            //    for _,v2:=range v.Proposer {
            //        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | %v:\n",c.Index, v2.Pk)
            //    }
            //    
            //}
            ifquery=false
			for k, v := range c.waitingblock {
                if c.isACommitBlock(v.Header.BlockHash) {
					delete(c.waitingblock, k)
                } else if bytes.Compare(v.Header.Prev, c.prev) == 0 {
					c.blockcache = append(c.blockcache, v)
                    if len(c.blockcache)>=2{
                        //TBC
                        // Malicious block
                        panic("Two to be committed block ")
                    }
                    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Set choosed block %v\n", c.Index, v.Header.BlockHash)
                    //TBC  
                    // deep copy!
                    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Set choosed block, blockhash: %v, block height %v \n",c.Index,v.Header.BlockHash,v.Header.Height)
                    if c.choosed==nil {
                        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Set choosed block, blockhash: %v, block height %v \n",c.Index,v.Header.BlockHash,v.Header.Height)
					    c.choosed = v
                        c.newBlockTime=time.Now()
                        c.QueryBlock(sk,pk)
                        ifquery=true
                    } else {
                        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | choosed block, blockhash: %v, block height %v, prev %v,pk %v \n",c.Index,c.choosed.Header.BlockHash,c.choosed.Header.Height,c.choosed.Header.Prev,c.choosed.Header.Pk)
                        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | another cached block has same prev with choosed block, blockhash: %v, block height %v, prev %v,pk %v\n",c.Index,v.Header.BlockHash,v.Header.Height,v.Header.Prev,v.Header.Pk)
                        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | another cached block, blockhash: %v, block height %v, prev %v,pk %v \n",c.Index,c.choosed.Header.BlockHash,c.choosed.Header.Height,c.choosed.Header.Prev,c.choosed.Header.Pk)
                        //panic
                    }
//                    if len(c.blockquerychan) == 0 {
//                        c.blockquerychan <- v
//                    }
                    //c.blockquerychan <- v
                    ifquery=true
                   // if len(c.blockquerychan)==0 {
                   //     c.blockquerychan <- v
                   // }
					delete(c.waitingblock, k)
				}
			}

//            if c.choosed != nil {
//                for k,v:=range c.resultcache {
//                    if bytes.Compare(c.choosed.Header.BlockHash, v.id) == 0 {
//                        c.result[k]=v
//                    }
//                    if c.isACommitBlock(v.id) {
//                        delete(c.result,k)
//                    }
//				}
//			}

            // update query
            //for k,v:=range c.query {
            //    if v.ifresp==true {
            //        delete(c.query,k)
            //    }
            //}


			//c.waitingblocklck.Unlock()
			//c.blockcachelock.Unlock()
			//c.choosedlock.Unlock()
			//			c.resultlock.Lock()
			//            for k,v:=range c.result {
			//                if c.isACommitBlock(v.id) {
			//                    delete(c.result,k)
			//                }
			//            }
			//			c.result = make(map[string]*result)
			//			for k, v := range c.resultcache {
			//				if bytes.Compare(v.prev, c.prev) == 0 {
			//					c.result[k] = v
			//					delete(c.resultcache, k)
			//				}
			//			}
			//c.resultlock.Unlock()

			//c.updateQueryList <- true

			//update  proposer list
			//			if c.choosed.ContainProposer() {
			//				c.nowproposer = 0
			//				c.propserlist = c.propserlist[:0]
			//				for _, v := range c.choosed.Proposer {
			//					c.propserlist = append(c.propserlist, string(v.Pk))
			//				}
			//				c.proposercheck = true
			//				if len(c.propserElection) == 0 {
			//					c.propserElection <- string(c.choosed.Header.BlockHash)
			//				}
			//			} else {
			//				c.nowproposer = c.nowproposer + 1
			//			}

			//c.proposercachelck.Lock()
            proposercache:=c.proposercache
			c.proposercache = c.proposercache[:0]
			for _, v := range proposercache{
				if bytes.Compare(c.prev, v.Prev) == 0 {
					c.proposercache = append(c.proposercache, v)
				}
			}
			for _, v := range c.proposerfuture {
				if bytes.Compare(c.prev, v.Prev) == 0 {
					c.proposercache = append(c.proposercache, v)
				}
			}
			//c.proposercachelck.Unlock()

			ifelection, ifgenerate := c.CheckifElectionOrGenerate(sk, pk)
		    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index, len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
			if ifelection {
				if len(c.propserElection) == 0 {
					c.propserElection <- string(c.prev)
				}
				c.proposercheck = true
			} else {
				c.proposercheck = false
			}
			if ifgenerate {
				if len(c.commitchan) == 0 {
					c.commitchan <- true
				}
			}
            if float64(ack)/float64(totalweight)>0.685 {
                fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Static | commitblock: %d committed tx: %d, Query Count %d, sample node %d, Empty block 0 , totalweight %d, ack weight %d,Time: %v\n",c.Index, c.cblock,c.ctx, count, total,totalweight,ack,time.Now().String())
            } else {
		        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Static | commitblock: %d committed tx: %d, Query Count %d, sample node %d, Empty block 1 , totalweight %d, ack weight %d,Time: %v\n",c.Index, c.cblock,c.ctx, count, total,totalweight,ack,time.Now().String())
            }
            //.WriteString("commitblock: " + strconv.Itoa(c.cblock) + " committed tx: " + strconv.Itoa(c.ctx))

		    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Release lock, Time: %v\n",c.Index,   time.Now().String())
            if ifquery==true {
                if c.choosed == nil {
                    //fmt.Fprintf(os.Stdout, "index %v |  SumQueryResult | Error: choosed is empty time: %v\n",c.Index,  time.Now().String())
                    panic("SumQueryResult | Error: choosed is empty")
                }
            }
        }         
        c.lck.Unlock()
	}
}
