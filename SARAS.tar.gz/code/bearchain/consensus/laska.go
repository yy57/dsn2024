package consensus

import (
	"bytes"
	"crypto/ecdsa"
	"fmt"
	"os"
	"time"
)

//func jiecheng(i int) int {
//    if i<0{
//        panic("jiecheng <0")
//    }
//    if i==0 {
//        return 1
//    }
//    tmp:=i
//    ret:=1
//    for tmp>0 {
//        ret=ret*tmp
//        tmp=tmp-1
//    }
//    return ret
//}
//
//func combine(n int, k int) float64 {
//    if n<0 || k<0 || n-k<0 {
//        panic("error combine")
//    }
//    a1:=float64(jiecheng(n))
//    a2:=float64(jiecheng(k))
//    a3:=float64(jiecheng(n-k))
//    return a1/a2/a3
//}
//
//func hyperGeomPMF(n int,u int,q int, i int) float64 {
//    a1:=combine(n,q)
//    a2:=combine(u,i)
//    a3:=combine(n-u,q-i)
//    return a2*a3/a1
//}
//
//func HyperGeomProb(n int, u int, q int, k int ,t int, s int) float64 {
//    var prob float64
//    prob=0
//    if k==1 {
//        for i:=t+1;i<=q;i++ {
//            prob=prob+hyperGeomPMF(n,u,q,i)
//        }
//        return prob
//    } else {
//        for i:=0;i<=q;i++ {
//            prob=prob+hyperGeomPMF(n,u,q,i)*HyperGeomProb(n,u,q,k-1,s-i,s)
//        }
//        return prob
//    }
//}

//laska
func (my *MyConsensus)Setlaska(q int, fenweidian map[int][]float64, selection [][]int) {
    my.q=q
    my.fenweidian=fenweidian
    my.selection=selection
}


func (my *MyConsensus)CheckFenweidian(k int, result int, total int) bool{
    if k+1<=len(my.fenweidian) {
        fenweidian:=my.fenweidian[k+1]
        prob:=fenweidian[result]
        if prob>float64(my.thresprob) {
            return false
        } else {
            return true
        }
    } else {
        sumack:=result-(total-result)
        if !ProbCompute2(my.thresprob,sumack,total,my.lenght) {
            return false
        } else {
            return true
        }
    }
}

//func (my *MyConsensus)LaSKASelection() []int {
//    return nil
//}


func (c *MyConsensus) LaSKASumQueryResult(sk *ecdsa.PrivateKey, pk *ecdsa.PublicKey) {
    
    var ifquery bool
//    var recvResp int
//    recvResp=0

	//tricker := time.NewTicker( 300 * time.Millisecond)
    var tricker *time.Ticker
	//tricker := time.NewTicker( 3 * time.Millisecond)
    switch c.ltype {
    case "Mil":
        //newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Millisecond)
        tricker=time.NewTicker(time.Duration(c.latency)*time.Millisecond)
    case "Sec":
        //newtime=c.newBlockTime.Add(time.Duration(c.latency)*time.Second)
        tricker=time.NewTicker(time.Duration(c.latency)*time.Second)
    case "Min":
        tricker=time.NewTicker(time.Duration(c.latency)*time.Minute)
        default :
    panic("Wrong time duration")
    }
	//tricker := time.NewTicker( 100 * time.Millisecond)
	//tricker := time.NewTicker(time.Duration(c.interval) * 100 * time.Millisecond)
	for {
		<-tricker.C
        c.lck.Lock()
        if c.choosed == nil {
            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Waiting for new block, Time: %v\n",c.Index,  time.Now().String())
            c.lck.Unlock()
            continue
        }
        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Get lock, Time: %v\n",c.Index,   time.Now().String())

        result:=0
        total:=0
        if c.count==0 {
		    for k, v := range c.result {
		    	if bytes.Compare(c.choosed.Header.BlockHash, v.id) == 0 {
                    total=total+1
		    		if v.ack == true {
                        result=result+1
                    } 
		    	} else if c.isACommitBlock(v.id) {
                    delete(c.result,k)
                }
		    }
            if total<(c.count+1)*c.q {
                c.lck.Unlock()
			    continue
            }
        }
        if !c.CheckFenweidian(c.count,result,total) {
            c.count=c.count+1
            c.QueryBlock(sk,pk)
            fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | thresprob : %v, sampled node %d, sum ack %d, height %d, query count %d, Waiting for enough query respone, time: %v\n",c.Index, c.thresprob,total,result,c.choosed.Header.Height,c.count, time.Now().String())
            c.lck.Unlock()
			continue
        } else {
			c.commitblock = append(c.commitblock, c.choosed)
			c.commitblockhash = append(c.commitblockhash, string(c.choosed.Header.BlockHash))
            //count:=c.count
            fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | -------------------------------Success!!!!!!the choosed block height %d, sample nodes: %d sum ack %d ack %d!!!\n",c.Index,  c.choosed.Header.BlockHash,c.choosed.Header.Height, total,result)
			//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | -------------------------------Success!!!!!! %d proposer for next round block generation \n",c.Index,  len(c.choosed.Proposer))
			//c.l.WriteABlock(c.choosed)
			//if l:=len(c.commitblock);l>30{ 
            //    c.commitblock=c.commitblock[l-30:]
			//}
			//if l:=len(c.commitblockhash);l>100{
            //    c.commitblockhash=c.commitblockhash[l-100:]
			//}
			c.height = c.choosed.Header.Height+1
            if c.height == 110 {
                panic("Already 200 committed block! Stop")
            }
			//c.height = c.height + 1
			c.cblock = c.choosed.Header.Height
			//c.cblock = c.cblock + 1
			c.ctx = c.ctx + len(c.choosed.Txs)
			//c.commitblock = append(c.commitblock, string(c.choosed.Header.BlockHash))
			c.prev = c.choosed.Header.BlockHash
			//fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | commit a block, set choosed block to nil\n",c.Index)
			c.choosed = nil
            c.count=0
            c.newBlockTime=time.Now()

			c.blockcache = c.blockcache[:0]
			fmt.Fprintf(os.Stdout, "index %v |  Consensus | commit %d block / %d tran\n",c.Index,  c.cblock, c.ctx)

            //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Now committed block:\n ",c.Index)
            //for _,v:=range c.commitblock {
            //    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | height %d\nblockhash %v\n, prev: %v\n",c.Index, v.Header.Height,v.Header.BlockHash,v.Header.Prev)
            //    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | it contain Proposer:\n",c.Index )
            //    for _,v2:=range v.Proposer {
            //        fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | %v:\n",c.Index, v2.Pk)
            //    }
            //    
            //}
            ifquery=false
			for k, v := range c.waitingblock {
                if c.isACommitBlock(v.Header.BlockHash) {
					delete(c.waitingblock, k)
                } else if bytes.Compare(v.Header.Prev, c.prev) == 0 {
					c.blockcache = append(c.blockcache, v)
                    if len(c.blockcache)>=2{
                        //TBC
                        // Malicious block
                        panic("Two to be committed block ")
                    }
                    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Set choosed block %v\n", c.Index, v.Header.BlockHash)
                    //TBC  
                    // deep copy!
                    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Set choosed block, blockhash: %v, block height %v \n",c.Index,v.Header.BlockHash,v.Header.Height)
                    if c.choosed==nil {
                        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Set choosed block, blockhash: %v, block height %v \n",c.Index,v.Header.BlockHash,v.Header.Height)
					    c.choosed = v
                        c.newBlockTime=time.Now()
                        c.QueryBlock(sk,pk)
                        ifquery=true
                    } else {
                        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | choosed block, blockhash: %v, block height %v, prev %v,pk %v \n",c.Index,c.choosed.Header.BlockHash,c.choosed.Header.Height,c.choosed.Header.Prev,c.choosed.Header.Pk)
                        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | another cached block has same prev with choosed block, blockhash: %v, block height %v, prev %v,pk %v\n",c.Index,v.Header.BlockHash,v.Header.Height,v.Header.Prev,v.Header.Pk)
                        //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | another cached block, blockhash: %v, block height %v, prev %v,pk %v \n",c.Index,c.choosed.Header.BlockHash,c.choosed.Header.Height,c.choosed.Header.Prev,c.choosed.Header.Pk)
                        //panic
                    }
//                    if len(c.blockquerychan) == 0 {
//                        c.blockquerychan <- v
//                    }
                    //c.blockquerychan <- v
                    ifquery=true
                   // if len(c.blockquerychan)==0 {
                   //     c.blockquerychan <- v
                   // }
					delete(c.waitingblock, k)
				}
			}


            // update query
            for k,v:=range c.query {
                if v.ifresp==true {
                    delete(c.query,k)
                }
            }



			//c.proposercachelck.Lock()
            proposercache:=c.proposercache
			c.proposercache = c.proposercache[:0]
			for _, v := range proposercache{
				if bytes.Compare(c.prev, v.Prev) == 0 {
					c.proposercache = append(c.proposercache, v)
				}
			}
			for _, v := range c.proposerfuture {
				if bytes.Compare(c.prev, v.Prev) == 0 {
					c.proposercache = append(c.proposercache, v)
				}
			}
			//c.proposercachelck.Unlock()

			ifelection, ifgenerate := c.CheckifElectionOrGenerate(sk, pk)
		    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | len of committed block %d, ifelection %v, ifgenerate %v, Time: %v\n",c.Index, len(c.commitblock),ifelection,ifgenerate,  time.Now().String())
			if ifelection {
				if len(c.propserElection) == 0 {
					c.propserElection <- string(c.prev)
				}
				c.proposercheck = true
			} else {
				c.proposercheck = false
			}
			if ifgenerate {
				if len(c.commitchan) == 0 {
					c.commitchan <- true
				}
			}
		    fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Static | commitblock: %d committed tx: %d, Query Count %d, sample node %d,  sum ack %d,Time: %v\n",c.Index, c.cblock,c.ctx,c.count, total,result,time.Now().String())
            //.WriteString("commitblock: " + strconv.Itoa(c.cblock) + " committed tx: " + strconv.Itoa(c.ctx))

		    //fmt.Fprintf(os.Stdout, "index %v |  CONSENSUS | Summary | Release lock, Time: %v\n",c.Index,   time.Now().String())
            if ifquery==true {
                if c.choosed == nil {
                    //fmt.Fprintf(os.Stdout, "index %v |  SumQueryResult | Error: choosed is empty time: %v\n",c.Index,  time.Now().String())
                    panic("SumQueryResult | Error: choosed is empty")
                }
            }
        }
		//if total < c.thresack {
        c.lck.Unlock()
	}
}
