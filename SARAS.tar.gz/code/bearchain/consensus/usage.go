package consensus

import (
	"fmt"
	"os"
)

func (my *MyConsensus)VariableUsage() {
    fmt.Fprintf(os.Stdout, " CONSENSUS | Usage info\n")

    fmt.Fprintf(os.Stdout, " CONSENSUS | Recv message channel data len %d:\n", len(my.RecvMsg))


    fmt.Fprintf(os.Stdout, " CONSENSUS | Send message channel data len %d:\n",len(my.SendMsg))

    fmt.Fprintf(os.Stdout, " CONSENSUS | simulated channel data len: %d\n",len(my.simluated))

    fmt.Fprintf(os.Stdout, " CONSENSUS | tx simulated cache len %d:\n", len(my.cache))

    //fmt.Fprintf(os.Stdout, " CONSENSUS | propser list len : %d\n", len(my.propserlist))

    //fmt.Fprintf(os.Stdout, " CONSENSUS | newpropser list len: %d\n",len(my.newpropser))

    fmt.Fprintf(os.Stdout, " CONSENSUS | propser cache len : %d\n", len(my.proposercache))

    fmt.Fprintf(os.Stdout, " CONSENSUS | proposer future len: %d\n",len(my.proposerfuture))

    fmt.Fprintf(os.Stdout, " CONSENSUS | block cache len: %d\n",len(my.blockcache))

    fmt.Fprintf(os.Stdout, " CONSENSUS | waiting block len: %d\n",len(my.waitingblock))

    fmt.Fprintf(os.Stdout, " CONSENSUS | committed block len: %d\n",len(my.commitblock))

    fmt.Fprintf(os.Stdout, " CONSENSUS | committed block hash len: %d\n",len(my.commitblockhash))

    fmt.Fprintf(os.Stdout, " CONSENSUS | query message len: %d\n",len(my.query))

    fmt.Fprintf(os.Stdout, " CONSENSUS | result message len: %d\n",len(my.result))
    fmt.Fprintf(os.Stdout, " CONSENSUS | future result message len: %d\n",len(my.resultcache))

}
