package consensus

import "bearchain/block"

type querytimetricker struct {
    count int
    //time 
    block *block.Block
}

func (q *querytimetricker)Reset() {

}
