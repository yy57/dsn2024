package ledger

import (
	"bearchain/block"
	"bearchain/config"
	"fmt"
	"os"

	//"bearchain/ledger/block"

	"bearchain/ledger/kvdb"
	"bearchain/ledger/storage"
)

const (
    maxsize = 3000
)
type Ledger struct {
    //bchan chan *block.Block
    //errchan chan error

    s *storage.Storage 

    kv *kvdb.Kvdb
    //p *Process
    path string
}

var localLedger *Ledger

//func Inir


//func InitLedger(config *config.LedgerConfig) (*Ledger,error) {
func InitLedger(config *config.LedgerConfig) error {
    localLedger=new(Ledger)
    //localLedger.bchan=make(chan *block.Block,maxsize)
    //localLedger.errchan=make(chan error,maxsize)
    var err error
    kvpath:=config.GetFilePath()
    fmt.Fprintf(os.Stdout," INFO | init ledger at path \"%s\" \n",kvpath)
    localLedger.kv,err=kvdb.Initkvdb(kvpath)
    if err!=nil {
        return err
    }
    s:=storage.InitStorage(config.GetFilePath())
    //s,err:=storage.InitStorage(config.GetSize(), config.GetFilePath())
    localLedger.s=s
    localLedger.path=config.Filepath
//    if err!=nil {
//        return err
//    }
    return err
}


func NewLedger(config *config.LedgerConfig) (*Ledger,error) {
    ledger:=new(Ledger)
    var err error
    kvpath:=config.GetFilePath()
    fmt.Fprintf(os.Stdout," INFO | init ledger at path \"%s\" \n",kvpath)
    ledger.kv,err=kvdb.Initkvdb(kvpath)
    if err!=nil {
        return nil,err
    }
    s:=storage.InitStorage(config.GetFilePath())
    //s,err:=storage.InitStorage(config.GetSize(), config.GetFilePath())
    ledger.s=s
    ledger.path=config.Filepath
//    if err!=nil {
//        return err
//    }
    return ledger,nil
}

func GetLedger() *Ledger {
    return localLedger
}

//func InitLedger(config *config.LedgerConfig) error {
//    l:=&Ledger{}
//    l.bchan=make(chan *block.Block,maxsize)
//    l.errchan=make(chan error,maxsize)
//    var err error
//    l.s,err=storage.InitStorage(config.GetCondition().Size, l.bchan,l.errchan)
//    if err!=nil {
//        return err
//    }
//    return err
//}

//func (l *Ledger) GetLastBlock() *block.Block {
//    b,_:=l.s.LastBlock()
//    return b
//}
//
//func (l *Ledger) NewBlock(b *block.Block) {
//    //TBC
//}
////
//func (l *Ledger) AddBlock(b *block.Block)  {
//  l.bchan<-b
//}
////
//func (l *Ledger) UpdateKV() error {
//    return nil
//}
//
//func (l *Ledger) Serve() error {
//    go l.s.UpdateLedger() //Update ledger
//    go l.p.process() // process tx to block
//    return nil
//}

func (l *Ledger)SimulateGet(flag string, sim *block.Simulated,key []byte) ([]byte,error) {
    if flag=="Sim" {
        val,err:=l.kv.Get(key)
        if err!=nil {
            return nil,fmt.Errorf("Error: \t simulated error, key %s \n",string(key))
        }
        kv:=new(block.KV)
        kv.Key=string(key)
        kv.Val=string(val)
        sim.Result.Rset=append(sim.Result.Rset,*kv)
        return l.kv.Get(key)
    } else if flag =="Commit" {
        return l.Get(key)
    }
    return nil,fmt.Errorf("Error:\t error flag \"%s\" when simulate tx\n",flag)
}
func (l *Ledger)SimulatePut(flag string,sim *block.Simulated,key []byte, value []byte) error {
    if flag=="Sim" {
        kv:=new(block.KV)
        kv.Key=string(key)
        kv.Val=string(value)
        sim.Result.Wset=append(sim.Result.Wset, *kv)
    } else if flag=="Commit" {
        return l.kv.Put(key,value)
    }
    //return l.kv.Put(key,value)
    return nil
}

func (l *Ledger)Get(key []byte) ([]byte,error) {
    //if 
    return l.kv.Get(key)
}

func (l *Ledger)Put(key []byte,value []byte) error{
    return l.kv.Put(key,value)
}


//func (l *Ledger)Commit() error {
//}

func (l *Ledger) WriteABlock(b *block.Block) {
    l.s.WriteABlock(b)
}
func (l *Ledger) ReadAblock(hash []byte, height int) *block.Block{
    return l.s.ReadABlock(hash,height)
}

func (l *Ledger)Close() {
    //l.s.Close()
    l.kv.Close()
}

//func (l *Ledger)Commit
//func (l *Ledger)Iterator() ([][]byte,[][]byte,error) {
//    return nil,nil,nil
//}
