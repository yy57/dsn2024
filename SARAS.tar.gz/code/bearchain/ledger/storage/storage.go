package storage

import (
	//"bearchain/ledger/block"
	"bearchain/block"
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

type Storage struct {
    path string
//	i *InfoFile
//	//ihandle *os.File
//	lhandle *os.File
//
//	// block file ="prefix.suffix"
//	suffix int
//	// count: the block number written to block file
//	count int
//	// every trigcount open a new block file
//	trigcount int

	//    errchan chan<- error
}

var localstorage *Storage
func InitStorage(path string) *Storage {
	localstorage = new(Storage)
    localstorage.path=path
    return localstorage
}

// Write A new block
func (s *Storage) WriteABlock(b *block.Block) {
    hash:=string(b.Header.BlockHash)
    height:=strconv.Itoa(b.Header.Height)
    //filename:=b.Header.BlockHash
    filename:=s.path + "/" + height+"++++"+hash
    bs,err:=json.Marshal(b)
    if err!=nil {
        panic(err)
    } 
    fmt.Fprintf(os.Stdout," Ledger | Write block %d\n ", b.Header.Height)
    file, err := os.OpenFile(filename, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0660)
    defer file.Close()

    writer:= bufio.NewWriter(file)
    n, err:=writer.WriteString(string(bs))
    fmt.Fprintf(os.Stdout," Ledger | write %d number \n ", n)
    if err!=nil {
        fmt.Fprintf(os.Stdout, " Ledger | Error when commit block %v, err: %v, time: %v\n",b.Header.BlockHash,err,time.Now().String())
    }
    writer.Flush()
}

func (s *Storage) ReadABlockFromHash(hash []byte) *block.Block {
    files,err:=os.ReadDir(s.path)
    if err!=nil {
        fmt.Fprintf(os.Stdout, " Ledger | ReadABlockFromHash |  Error when reading block with hash %v Details: fail to read dir %s, error info: %v\n",hash,s.path, err)
        return nil
    }
    for _,file := range files {
        filename:=file.Name()
        if strings.Contains(filename, string(hash)) {
            bs,err:=os.ReadFile(filename) 
            if err!=nil {
                fmt.Fprintf(os.Stdout, " Ledger | ReadABlockFromHash | fail to read block %v file, error: %v\n",filename,err)
                return nil
            }
            b:=new(block.Block)
            err=json.Unmarshal(bs,b)
            if err!=nil {
                fmt.Fprintf(os.Stdout, " Ledger | ReadABlockFromHash | fail to unmarshal block %v from bs to block, error info: %v",filename,err)
                return nil
            }
            return b
        }
    }
    fmt.Fprintf(os.Stdout, " Ledger | ReadABlockFromHash | No hash %v block\n",hash)
    return nil
}

func (s *Storage) ReadABlockFromHeight(height int) *block.Block {
    files,err:=os.ReadDir(s.path)
    if err!=nil {
        fmt.Fprintf(os.Stdout, " Ledger | ReadABlockFromHeight |  Error when reading block in height %d, Details: fail to read dir %s, error info: %v\n",height,s.path, err)
        return nil
    }
    for _,file := range files {
        filename:=file.Name()
        s:=strings.Split(filename,"++++")
        //TBC
        if len(s)>2 {
            fmt.Fprintf(os.Stdout, " Ledger | ReadABlockFromHeight | Warning | block hash has ++++ string : %v\n",filename)
        }
        fh,err:=strconv.Atoi(s[0]) 
        if err!=nil {
            continue
        }
        if fh==height {
            bs,err:=os.ReadFile(filename) 
            if err!=nil {
                fmt.Fprintf(os.Stdout, " Ledger | ReadABlockFromHeight | fail to read block %v file, error: %v\n",filename,err)
                return nil
            }
            b:=new(block.Block)
            err=json.Unmarshal(bs,b)
            if err!=nil {
                fmt.Fprintf(os.Stdout, " Ledger | ReadABlockFromHeight | fail to unmarshal block %v from bs to block, error info: %v",filename,err)
                return nil
            }
            return b
        } else {
            continue
        }
    }
    fmt.Fprintf(os.Stdout, " Ledger | ReadABlockFromHeight | No height %d block\n",height)
    return nil
}

func (s *Storage) ReadABlock(hash []byte, height int) *block.Block {
    if height>=0 {
        return s.ReadABlockFromHeight(height)
    } else {
        return s.ReadABlockFromHash(hash)
    }
}

//func blockfile(suffix int) string {
//	return prefix + strconv.Itoa(suffix)
//}
//
//func splitSufix(str string) int {
//	arr := strings.Split(str, ".")
//	l := len(arr)
//	if l != 2 {
//		fmt.Fprintf(os.Stdout, "Wrong file in data")
//		return -1
//	}
//	sufix := arr[l-1]
//	index, err := strconv.Atoi(sufix)
//	if err != nil {
//		fmt.Fprintf(os.Stdout, "Wrong file in data")
//		return -1
//	}
//	return index
//}
//
//func InfofilePath(i int) string {
//	path := strconv.Itoa(i)
//	path = infofile + path
//	return path
//}
//
//func BlockFilePath(i int) string {
//	path := strconv.Itoa(i)
//	path = prefix + path
//	return path
//}

//func InitStorage(trigcount int,bchan <-chan *block.Block,errchan chan<- error)  (*Storage,error) {
//func InitStorage(trigcount int, path string) (*Storage, error) {
//func InitStorage(path string) (*Storage, error) {
//	localstorage = new(Storage)
//    localstorage.path=path
//	path = path + "/block"
//	files, err := os.ReadDir(path)
//	fmt.Fprintf(os.Stdout, " INFO | init block data at \"%s\"\n", path+"/block")
//	if os.IsNotExist(err) {
//		fmt.Fprintf(os.Stdout, " INFO | Dir %s does not exist, create it\n", path+"/block")
//		err = os.Mkdir(path, 0750)
//		if err != nil {
//			panic(err)
//		}
//		ipath := InfofilePath(0)
//		ipath = path + "/" + ipath
//		i, err := InitinfoFile(ipath)
//		if err != nil {
//			panic(err)
//		}
//		//localstorage.lhandle, err = os.OpenFile(BlockFilePath(0), os.O_CREATE|os.O_APPEND, 0666)
//		spath := BlockFilePath(0)
//		spath = path + "/" + spath
//		localstorage.lhandle = InitBlockStorage(spath)
//		localstorage.i = i
//	}
//	last := -1
//	for _, file := range files {
//		filename := file.Name()
//		sufix := splitSufix(filename)
//		if sufix > last {
//			last = sufix
//		}
//	}
//	if last == -1 {
//		fmt.Fprintf(os.Stdout, " INFO | no block data in \"%s\" \n", path+"/block")
//		fmt.Fprintf(os.Stdout, " INFO | init with blockfile.0\n")
//		ipath := InfofilePath(0)
//		ipath = path + "/" + ipath
//		i, err := InitinfoFile(ipath)
//		if err != nil {
//			panic(err)
//		}
//		spath := BlockFilePath(0)
//		spath = path + "/" + spath
//		localstorage.lhandle = InitBlockStorage(spath)
//		localstorage.i = i
//		return localstorage, nil
//	}
//	ipath := InfofilePath(0)
//	ipath = path + "/" + ipath
//	spath := BlockFilePath(last)
//	spath = path + "/" + spath
//	i, err := InitinfoFile(ipath)
//	//localstorage.lhandle, err = os.OpenFile(BlockFilePath(last), os.O_CREATE|os.O_APPEND, 0666)
//	localstorage.lhandle = InitBlockStorage(spath)
//	localstorage.i = i
//	return localstorage, nil
//}

//func (s *Storage) WriteABlock(b *block.Block) {
//	data, err := marshal(b)
//	if err != nil {
//		//s.errchan<-err
//		fmt.Fprintf(os.Stdout, "error when init ledger storage")
//		return
//	}
//	writebuf := bufio.NewWriter(s.lhandle)
//	_, err = writebuf.Write(data)
//	if err != nil {
//		panic("Write block to file failed!")
//	}
//	writebuf.Flush()
//	//s.lhandle.Write(data)
//	s.count = s.count + 1
//	s.i.NewBlock()
//	if s.count >= s.trigcount {
//		sufix := splitSufix(s.lhandle.Name())
//		if sufix == -1 {
//			fmt.Fprintf(os.Stdout, "error when init ledger storage")
//			return
//		}
//		sufix = sufix + 1
//		s.i.WriteToFile()
//		s.i.NewInfoFile(InfofilePath(sufix))
//		s.lhandle.Close()
//		s.lhandle, err = os.OpenFile(BlockFilePath(sufix), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
//	}
//	//s.i.Write(s.suffix,s.count)
//}


//func (s *Storage) ReadABlock() (*block.Block, error) {
//	buf := bufio.NewReader(s.lhandle)
//	line, err := buf.ReadString('\n')
//	if err != nil {
//		fmt.Fprintf(os.Stdout, "error when init ledger storage")
//		//s.errchan<-err
//		return nil, err
//	}
//	line = strings.TrimSpace(line)
//	b, err := unmarshal([]byte(line))
//	if err != nil {
//		fmt.Fprintf(os.Stdout, "error when init ledger storage")
//		//s.errchan<-err
//		return nil, err
//	}
//	return b, nil
//}

//func unmarshal(bs []byte) (*block.Block, error) {
//	//TBC
//	return nil, nil
//}
//
//func marshal(b *block.Block) ([]byte, error) {
//	//TBC
//	bs, err := json.Marshal(*b)
//	if err != nil {
//		return nil, fmt.Errorf("Error:\t fail to marshal block to bytes,details:%v \n", err)
//	}
//	return bs, nil
//}
//func (s *Storage) LastBlock() (*block.Block, error) {
//	b, err := s.ReadABlock()
//	if err != nil {
//		return nil, err
//	}
//	return b, nil
//}

//func (s *Storage) LastBlockHead() ([]byte,error) {
//    b,err:=s.ReadABlock()
//    if err !=nil {
//        //s.errchan<-err
//        fmt.Fprintf(os.Stdout,"error when init ledger storage")
//        return nil,err
//    }
//    return b.Header.Block_hash,nil
//}

//func (s *Storage) Close() {
//	s.i.Close()
//	s.lhandle.Close()
//}

//func (s *Storage) UpdateLedger() error {
//    for {
//        select {
//        case b:=<-s.bchan:
//            s.WriteABlock(b)
//            s.Trigger()
//        }
//    }
//}

//func (c *Storage)SaveABlock(prefix string, b *block.Block) {
//    filename:=strconv.Itoa(b.Header.Height)
//    //filename:=b.Header.BlockHash
//    path:= prefix + "/" + filename
//    bs,err:=json.Marshal(b)
//    if err!=nil {
//        panic(err)
//    } 
//    fmt.Fprintf(os.Stdout," Ledger | Write block %d\n ", b.Header.Height)
//    file, err := os.OpenFile(path, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0660)
//    defer file.Close()
//
//    writer:= bufio.NewWriter(file)
//    n, err:=writer.WriteString(string(bs))
//    fmt.Fprintf(os.Stdout," Ledger | write %d number \n ", n)
//    if err!=nil {
//        fmt.Fprintf(os.Stdout, " Ledger | Error when commit block %v, err: %v, time: %v\n",b.Header.BlockHash,err,time.Now().String())
//    }
//    writer.Flush()
//}
