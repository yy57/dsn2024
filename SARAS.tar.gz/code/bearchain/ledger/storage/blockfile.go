package storage

import "os"

func InitBlockStorage(path string) *os.File {
    file,err:=os.OpenFile(path, os.O_CREATE|os.O_RDWR|os.O_APPEND,0666)
    if err!=nil {
        panic(err)
    }
    return file
}
