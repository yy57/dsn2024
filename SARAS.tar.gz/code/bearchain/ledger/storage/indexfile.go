package storage

import (
	"fmt"
	"os"
)

const (
	prefix   = "blockdata."
	infofile = "info."
)

type InfoFile struct {
	count  int // how many block in this file
	height int // block height in this file
	file   *os.File
}

func stringToInt(str string) (int, int) {
	return 0, 0
}

var localinforFile *InfoFile

// 路径有问题！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
func InitinfoFile(path string) (*InfoFile, error) {
	localinforFile = new(InfoFile)
	file, err := os.OpenFile(path, os.O_WRONLY|os.O_TRUNC, 0660)
	if os.IsNotExist(err) {
		fmt.Fprintf(os.Stdout, " Error | fail to open %s infofile, create it\n", path)
		file, err = os.OpenFile(path, os.O_CREATE|os.O_WRONLY, 0660)
		if err != nil {
			return nil, fmt.Errorf("Error:\t fail to open or create %s infofile\n", path)
		}
	}
	str, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	count, height := stringToInt(string(str))
	localinforFile.count = count
	localinforFile.height = height
	localinforFile.file = file
	return localinforFile, nil
}

func (i *InfoFile) NewBlock() {
	i.count = i.count + 1
	i.height = i.height + 1
}

func (i *InfoFile) ToString() string {
	return ""
}

func (i *InfoFile) WriteToFile() {
	_, err := i.file.WriteString(i.ToString())
	if err != nil {
		fmt.Fprintf(os.Stdout, "error: %v", err)
	}
	i.file.Close()
	i.count = 0
}

func (i *InfoFile) NewInfoFile(file string) {
	var err error
	i.file, err = os.OpenFile(file, os.O_WRONLY|os.O_TRUNC, 0666)
	if err != nil {
		fmt.Fprintf(os.Stdout, "error: %v", err)
	}
}

func (i *InfoFile) Close() {
	i.WriteToFile()
	i.file.Close()
}
