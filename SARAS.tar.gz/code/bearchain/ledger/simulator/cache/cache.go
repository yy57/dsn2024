package cache

type kv struct {
    k string
    val string
}

type cache struct {
    rset []kv
    wset []kv
}


var localcache *cache

func (c *cache)update() {

}

func (c *cache)Commit() {

}
