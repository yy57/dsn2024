package ledger

//type Ledger interface{}

