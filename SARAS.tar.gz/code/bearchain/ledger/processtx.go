package ledger

//
//import (
//	"bearchain/config"
//	"bearchain/ledger/block"
//	"bearchain/ledger/storage"
//)
//
//
//type Process struct {
//    //l ledger
//
//    size  int
//    txs []block.Transaction
//    count int
//}
//
//func (p *Process) Config(c *config.Condition) {
//    p.size=c.Size
//}
//
//func (p *Process) Block(l *storage.Storage) (*block.Block,error) {
//    b := &block.Block{}
//    b.Payload.Transcations=p.txs
//    var err error
//    b.Header.Prev,err=l.LastBlockHead()
//    if err!=nil {
//        return nil,err
//    }
//    return b,nil
//}
//
//func (p *Process) process() {
//    // TBC
//}
