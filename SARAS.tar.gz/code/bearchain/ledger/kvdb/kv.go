package kvdb

import (
	"strconv"
	"strings"
)

type Version struct {
    modBlock []byte
    modBlockHeight int
    modTx []byte
}

func (ver *Version) ToBytes() []byte {
    h:=strconv.Itoa(ver.modBlockHeight)
    ret:=append(ver.modBlock,[]byte("+++++")...)
    ret=append(ret,[]byte(h)...)
    ret=append(ret,[]byte("+++++")...)
    ret=append(ret,ver.modTx...)
    return ret
}

//func (ver *Version) bytetoVersion(bs []byte) error {
func (ver *Version) BytetoVersion(bs []byte) {
    s:=strings.Split(string(bs), "+++++")
    if len(s)!=3 {
        panic("fail to get value version")
    }

    ver.modBlock=[]byte(s[0])
    var err error
    ver.modBlockHeight,err=strconv.Atoi(string(s[1]))
    if err!=nil  {
        panic("fail to get value version block height")
    }
    ver.modTx=[]byte(s[2])
}

type Value struct {
    value []byte
    version *Version
}

func (val *Value) ToBytes() []byte {
    ret:=append(val.value,[]byte("====")...)
    ret=append(ret,val.version.ToBytes()...)
    return ret
}

func (val *Value) RecoverFromBytes(bs []byte) {
    s:=strings.Split(string(bs), "====")
    if len(s)!=2 {
        panic("fail to get value")
    }
    val.value=[]byte(s[0])
    val.version.BytetoVersion([]byte(s[1]))
}

type KeyValue struct {
    key []byte
    value *Value
}

func (kv *KeyValue) GetValue() []byte {
    return kv.value.ToBytes()
}
