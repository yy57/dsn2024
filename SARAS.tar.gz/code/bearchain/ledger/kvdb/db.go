package kvdb

import (
	//"leveldb"

	"fmt"
	"os"

	"github.com/syndtr/goleveldb/leveldb"
)

const (
    kvfile="kv.db"
)

type Kvdb struct{
    filepath string
    handle *leveldb.DB
}

func Initkvdb(filepath string) (*Kvdb,error) {
    kvdb:=new(Kvdb)
    path:=filepath+"/"+kvfile
    kvdb.filepath=path
    var err error
    kvdb.handle,err=leveldb.OpenFile(path,nil)
    if err!=nil {
        fmt.Fprintf(os.Stdout, " Ledger | kvdb | Fail to init kv db,error info: %v\n", err)
        return nil,err
    }
    fmt.Fprintf(os.Stdout, " INFO | init KeyValue DB at path \"%s\" \n", path)
    return kvdb,nil
}

func (kv *Kvdb) isOpen() bool {
    if kv.handle == nil {
        return false
    }
    return true
}

func (kv *Kvdb) Open() error {
    var err error
    kv.handle,err=leveldb.OpenFile(kv.filepath,nil)
    if err != nil {
        return err
    }
    return nil
}

func (kv *Kvdb) Get(key []byte) ([]byte,error) {
    value,err:=kv.handle.Get(key,nil)
    if err!=nil {
        return nil,err
    }
    return value,nil
}

func (kv *Kvdb) Put(key []byte,value []byte)  error {
    err:=kv.handle.Put(key,value,nil)
    if err!=nil {
        return err
    }
    return nil
}

func (kv *Kvdb)Close() {
    kv.handle.Close()
}
