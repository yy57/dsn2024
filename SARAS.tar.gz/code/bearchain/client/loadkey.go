package client

type Keypath struct {
	Skpath string `yaml:"sk"`
	Pkpath string `yaml:"pk"`
}

//func LoadKey(path string) (*ecdsa.PrivateKey,*ecdsa.PublicKey, error) {
func LoadKey(path string, errchan chan error) (string, string, error) {
//	_, err := os.Stat(path)
//	if err != nil {
//		if os.IsNotExist(err) {
//			//return nil, fmt.Errorf("%s not exist", path)
//			//fmt.Errorf("%s not exist", path)
//			return "", "", fmt.Errorf("%s not exist", path)
//		}
//	}
//	file, err := ioutil.ReadFile(path)
//	if err != nil {
//		//fmt.Errorf("%s not exist", path)
//		return "", "", err
//	}
//	var keypath Keypath
//	err = yaml.Unmarshal(file, &keypath)
//	if err != nil {
//		return "", "", err
//	}
//	_, err = os.Stat(keypath.Skpath)
//	if os.IsNotExist(err) {
//		err := fmt.Errorf("Warning: Missing PrivateKey at %v, generate new sk,pk at %v,%v\n", keypath.Skpath, keypath.Skpath, keypath.Pkpath)
//		errchan <- err
//		sk, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
//		pk := sk.PublicKey
//		//localEcdsa.sk = sk
//		//localEcdsa.pk = &pk
//		crypt.SaveKey(keypath.Skpath, keypath.Pkpath, sk, &pk)
//	}
//	s, p, err := crypt.LoadKey(keypath.Skpath, keypath.Pkpath, errchan)
//	if err != nil {
//		return "", "", err
//	}
//	return s, p, nil
 return "","",nil
}
