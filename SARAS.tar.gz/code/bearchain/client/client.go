package client

import (
	"bearchain/block"
	"bearchain/constdef"
	"bearchain/gossip"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"math/rand"
	"net"
	"os"
	"strings"
	"time"

	"gopkg.in/yaml.v3"
)

type ScInvoke struct {
	Name string `yaml:"name"`
	Para string `yaml:"para"`
}

func RandStr(length int) string {
	str := "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	bytes := []byte(str)
	result := []byte{}
	rand.Seed(time.Now().UnixNano()+ int64(rand.Intn(100)))
	for i := 0; i < length; i++ {
		result = append(result, bytes[rand.Intn(len(bytes))])
	}
	return string(result)
}

func (s *ScInvoke) SplitPare() []string {
	paras := strings.Split(s.Para, ";")
    if len(paras)==0 {
        panic("Error")
    }
    paras[0]=RandStr(5)
    fmt.Printf("%s\n",paras[0])
    paras[1]=RandStr(5)
    paras[2]=RandStr(5)
    paras[3]=RandStr(5)
	return paras
}

type OnNode struct {
	Addr string     `yaml:"addr"`
	Sc   []ScInvoke `yaml:"sc"`
}

type Task struct {
	Nodes []OnNode `yaml:"nodes"`
    //Skpath string
}

func ReadTask(path string) (*Task, error) {
	_, err := os.Stat(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, fmt.Errorf("%s not exist", path)
		}
	}
	file, err := ioutil.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var task Task
	err = yaml.Unmarshal(file, &task)
	if err != nil {
		return nil, err
	}
	return &task, nil
}

//func Sign

func NewTx(pk string, Sc string, Para []string) block.Transaction {
	inner := block.ClientInput{
        Pk:  pk,
		Sc:  Sc,
		Para: Para,
	}
	tx := block.Transaction{
		Inner: &inner,
	}
	return tx
}

func ToMessage(bs []byte, t string) gossip.MessageImp{
	newm := gossip.MessageImp{
		Bs:    bs,
		Ttype: t,
	}
	return newm
}

func (s *ScInvoke) Msg(sk string, pk string) ([]byte, error) {
	tx := NewTx(pk,s.Name, s.SplitPare())
    err:=tx.Complete(sk)
	if err != nil {
		return nil, err
	}
	bs, err := json.Marshal(tx)
	if err != nil {
		return nil, err
	}
	msg := ToMessage(bs, constdef.TX)
	b, err := msg.ToBytes()
	return b, err
}

func invoke(addr string, sc ScInvoke, sk string, pk string) {
	bs, err := sc.Msg(sk,pk)
	conn, err := net.Dial("tcp", addr)
	if err != nil {
		fmt.Println("Error dialing", err.Error())
		return // 终止程序
	}
	defer conn.Close()
    var buf [4]byte
    bufs:=buf[:]
    sendlen:=len(bs)
        //fmt.Printf("Len of send data %d\n",sendlen)
    binary.BigEndian.PutUint32(bufs, uint32(sendlen))
    if _, err := conn.Write(bufs); err != nil {
            //fmt.Printf("write failed , err : %v\n", err)
		fmt.Fprintf(os.Stdout, "ERROR | Send msg error %v\n", err)
    }   
    if _, err = conn.Write(bs); err != nil {
            //fmt.Printf("write failed , err : %v\n", err)
        fmt.Fprintf(os.Stdout, "ERROR | Send msg error %v\n", err)
        //break
    } 
    //p=p+1024
	//conn.Write(bs)
}

func (t *Task) Invoke(sk string,pk string) {
	for _, v := range t.Nodes {
		addr := v.Addr
		for _, tasks := range v.Sc {
			invoke(addr, tasks,sk, pk)
		}
	}
}
