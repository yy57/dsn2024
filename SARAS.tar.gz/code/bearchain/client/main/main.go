package main

import (
	"bearchain/client"
	"bearchain/errorp"
	"fmt"
	"os"
	"time"
)

func main() {
    errchan:=make(chan error,1024)
    errinfo:=errorp.NewErr(errchan)
    go errinfo.Serve()

    path:="./task.yaml"
    t,err:=client.ReadTask(path)
    if err!=nil {
        fmt.Fprintf(os.Stdout,"Error: %v",err)
        return
    }
    sk,pk,err:=client.LoadKey(path,errchan)
    //sk,pk,err:=client.LoadKey(path)
    if err!=nil {
        fmt.Fprintf(os.Stdout,"Error: %v",err)
        return
    }
    //for i:=0;i<1000;i++ {
    //    t.Invoke(sk,pk)
    //}
    ////tricker:=time.NewTicker(10*time.Minute)
    //tricker:=time.NewTicker(10*time.Minute)
    //tricker:=time.NewTicker(3*time.Minute)
    tricker:=time.NewTicker(1*time.Minute)
   // //t.Invoke(sk,pk)
   // //for i:=0;i<100;i++ {
   // //    t.Invoke(sk,pk)
   // //}
    go func(*client.Task) {
        tricker1:=time.NewTicker(1*time.Second)
        //for i:=0;i<10;i++ {
            //t.Invoke(sk,pk)
        //}
        for {
            <-tricker1.C
            for i:=0;i<500;i++ {
                t.Invoke(sk,pk)
            }
            //t.Invoke(sk,pk)
        }
    }(t)//    go func() {
    <-tricker.C
}
