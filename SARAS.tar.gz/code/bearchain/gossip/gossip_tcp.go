package gossip

import (
	"bearchain/constdef"
	"crypto/sha256"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"os"
	"time"
)

func (g *GossipImp) Recv() {
//func (g *GossipImp) Recv(ctx context.Context) {
	//locallog:=log.GetlocalLog()
	for {
		conn, err := (*g.tcp).AcceptTCP()
		if err != nil {
			//fmt.Errorf("accept failed,err:%v",err)
			fmt.Fprintf(os.Stdout, " ERROR | TCP accept failed,err:%v", err)
			return
		}
		go g.processRecv(conn)
	}
}

func (g *GossipImp)AddCacheMsgAndBroadcast(ip string, hash string, b *MessageImp,m []byte ) {
	g.msglck.Lock()
	defer g.msglck.Unlock()
	if _, ok := g.msgCache[hash]; !ok {
		// new message
		msg := new(MsgInst)
		msg.hash = hash
        msg.ip=make([]string,0)
        msg.ip = append(msg.ip, ip)
		msg.time = time.Now()
		msg.msg = b
        msg.sended=false
		g.msgCache[string(hash[:])] = msg
        if b.Ttype!=constdef.TX {
	        for k := range g.nodelist {
	        	d := g.nodelist[k].addr
                if ip == d {
                    continue
                } else {
	        	    go g.send(m, g.nodelist[k].GetTcpAddr())
                }
	        }
        }
        g.recvchan<-b
    }else {
        ifexist:=false
        for _,v:=range g.msgCache[string(hash[:])].ip {
            if v==ip {
                ifexist=true
            }
        }
        if !ifexist {
            g.msgCache[string(hash[:])].ip=append(g.msgCache[string(hash[:])].ip, )
        }
    }
    return
}

func (g *GossipImp)AddCacheMsg(ip string, hash string, b *MessageImp) {
	g.msglck.Lock()
	defer g.msglck.Unlock()
	if _, ok := g.msgCache[hash]; !ok {
		// new message
		msg := new(MsgInst)
		msg.hash = hash
        msg.ip=make([]string,0)
        msg.ip = append(msg.ip, ip)
		msg.time = time.Now()
		msg.msg = b
        msg.sended=false
		g.msgCache[string(hash[:])] = msg
        if b.Ttype!=constdef.TX {
            g.recvchan<-b
        }
    }else {
        ifexist:=false
        for _,v:=range g.msgCache[string(hash[:])].ip {
            if v==ip {
                ifexist=true
            }
        }
        if !ifexist {
            g.msgCache[string(hash[:])].ip=append(g.msgCache[string(hash[:])].ip, )
        }
    }
}

func (g *GossipImp) processRecv(conn net.Conn) {
//func (g *GossipImp) processRecv(ctx context.Context,conn net.Conn) {
	//data := make([]byte, 0, 1024000)
	data := make([]byte, 0, 20480)
//    e := conn.SetReadDeadline(time.Now().Add(3 * time.Second))
//    if e!=nil{
//        fmt.Fprintf(os.Stdout," GOSSIP | processRecv | Fail to set Deadlinet")
//    }
    //fmt.Fprintf(os.Stdout, " GOSSIP | Recv | A connection from %v\n", conn.RemoteAddr().String())
	defer conn.Close()
	for {
		var msgSize int32
		err := binary.Read(conn, binary.BigEndian, &msgSize)
		if err != nil {
            fmt.Fprintf(os.Stdout," GOSSIP | Recv | Error when Recving %v\n",err)
			break
		}
        fmt.Fprintf(os.Stdout," GOSSIP | Recv | Recv data %v from remote %v\n",msgSize,conn.RemoteAddr().String())
		buf := make([]byte, msgSize)
		_, err = io.ReadFull(conn, buf)
		if err != nil {
            fmt.Fprintf(os.Stdout," GOSSIP | Recv | Error when Recving %v\n",err)
			break
		}
        fmt.Fprintf(os.Stdout," GOSSIP | Recv | Recv data %v from remote %v\n",buf,conn.RemoteAddr().String())
		//fmt.Printf("recv: %s len %d, remote %v\n", string(buf), len(buf), conn.RemoteAddr())
		data = append(data, buf...)
	}


    var b MessageImp
    l := len(data)
    err := json.Unmarshal(data[:l], &b)
    if err != nil {
            fmt.Fprintf(os.Stdout, " Gossip | Recv unknom Msg\n")
            return
    }
    fmt.Fprintf(os.Stdout, " Gossip | TCP Recv data from remote addr:%v\n", conn.RemoteAddr())
    g.recvchan <- &b


//    remote:=conn.RemoteAddr().String()
//    r1:=strings.Split(remote,":")
//    ip:=r1[0]
//
//	hash := sha256.Sum256(data[:l])
//    if _, ok := g.msgCache[string(hash[:])]; !ok {
//		// new message
//		msg := new(MsgInst)
//        msg.hash = string(hash[:])
//        msg.ip=make([]string,0)
//        msg.ip = append(msg.ip, ip)
//		msg.time = time.Now()
//		msg.msg = &b
//        msg.sended=false
//		g.msgCache[string(hash[:])] = msg
//    }
//
//    remote:=conn.RemoteAddr().String()
//    r1:=strings.Split(remote,":")
//    ip:=r1[0]
//    //func (g *GossipImp)AddCacheMsgAndBroadcast(ip string, hash string, b *MessageImp,m []byte ) {
//    g.AddCacheMsgAndBroadcast(ip,string(hash[:]), &b, data[:l])
//    //g.AddCacheMsg(ip,string(hash[:]),&b)
//    //g.broadcast(string(hash[:]),data[:l], "")
}

// send message
func (g *GossipImp) send(m []byte, d string) {
//func (g *GossipImp) send(ctx context.Context,m []byte, s string, d string) {
//    g.sem.Acquire(ctx,1)
//    defer g.sem.Release(1)
	var b MessageImp
    var conn *net.TCPConn
    conn=nil
    var err error
    timer:=time.NewTimer(300*time.Millisecond)
    <-timer.C

    err = json.Unmarshal(m, &b)
    //fmt.Fprintf(os.Stdout, " GOSSIP | Send Message %v to remote %v\n",b,d)
	//conn, err = dialer.DialTCP("tcp",nil, d)
    remoteaddr,err:=net.ResolveTCPAddr("tcp",d)
    if err!=nil {
        fmt.Fprintf(os.Stdout,"Unable to resolve IP\n")
    }


	conn, err =net.DialTCP("tcp",nil, remoteaddr)
//    conn, _ := net.DialTimeout("tcp", t.Host, t.Timeout())
    if conn==nil {
        fmt.Fprintf(os.Stdout, " GOSSIP | Error %v: Fail to dial %v, time: %v\n",err,d,time.Now().String())
        fmt.Fprintf(os.Stdout, "Fail to send %v to %s, try send it later, time: %v\n", b,d,err)
        return
    }

    if conn != nil {
        fmt.Fprintf(os.Stdout, " tcp conn to remote %s :%v\n", d,conn)
    } else {
    }
    fmt.Fprintf(os.Stdout, " GOSSIP | Send Message %v to remote %v, local address %v\n",b,d,conn.LocalAddr().String())
    //fmt.Fprintf(os.Stdout, " GOSSIP | local address %v\n",conn.LocalAddr().String())
	defer conn.Close() // 关闭连接
	l := len(m)
	p := 0
	q := 0
	var senddata []byte
	for {
		if p > l {
			break
		}
		q = p + 1024
		if q > l {
			senddata = m[p:l]
		} else {
			senddata = m[p:q]
		}
		var buf [4]byte
		bufs := buf[:]
		sendlen := len(senddata)
		//fmt.Printf("Len of send data %d\n",sendlen)
		binary.BigEndian.PutUint32(bufs, uint32(sendlen))
		//if _, err :=tcpCon.Write(bufs); err != nil {
		if _, err := conn.Write(bufs); err != nil {
			//fmt.Printf("write failed , err : %v\n", err)
			fmt.Fprintf(os.Stdout, "ERROR | Gossip | Send msg error %v\n", err)
			break
		}
	//	if _, err = tcpCon.Write(senddata); err != nil {
		if _, err = conn.Write(senddata); err != nil {
			//fmt.Printf("write failed , err : %v\n", err)
			fmt.Fprintf(os.Stdout, "ERROR | Gossip | Send msg error %v\n", err)
			break
        } else {
     //       fmt.Fprintf(os.Stdout, "GOSSIP | send to %s some data\n",d)
        }
		p = p + 1024
	}
	return
}

// broadcast message
func (g *GossipImp) broadcast(hash string,m []byte, s string) {
//func (g *GossipImp) broadcast(ctx context.Context,m []byte, s string) error {
	fmt.Fprintf(os.Stdout, " broadcast message\n")
    g.msglck.Lock()
    iplist:=g.msgCache[hash].ip
    if g.msgCache[hash].sended==false {
        g.msgCache[hash].sended=true
    } else {
        g.msglck.Unlock()
        return 
    }
    g.msglck.Unlock()


	for k := range g.nodelist {
		d := g.nodelist[k].addr
        sended:=false
        for _,v:=range iplist {
            if d==v {
                sended=true
            }
        }
        if sended==false {
		    go g.send(m,  g.nodelist[k].GetTcpAddr())
        }
		//go g.send(ctx,m, s, d)
	}
	return
}

// Send message module
//func (g *GossipImp) Send(msg *Message,msgtype int, node *Node) error {
func (g *GossipImp) Send() {
//func (g *GossipImp) Send(ctx context.Context) {
	//tricker:=time.NewTicker(300*time.Millisecond)
	for {
		select {
		case msg := <-g.upstream:
     //       <-tricker.C
            //var latency *time.Timer
            //latency:=time.NewTimer(time.Duration(300)*time.Millisecond)
            //if g.unit==constdef.MILLS {
            //    //TBC
            //    //sample:=100
            //    sample:=rand.ExpFloat64()
            //    latency=time.NewTimer(time.Duration(sample)*time.Millisecond)
            //}
            //if g.unit==constdef.SECOND {
            //    //TBC
            //    sample:=rand.ExpFloat64()
            //    latency=time.NewTimer(time.Duration(sample)*time.Second)
            //}
            //if g.unit==constdef.MINITUE {
            //    //TBC
            //    sample:=100
            //    latency=time.NewTimer(time.Duration(sample)*time.Minute)
            //}
            //<-latency.C
			//<-tricker.C
			//fmt.Fprintf(os.Stdout, " GOSSIP | Send message %v\n", msg)

			bs, err := (*msg).ToBytes()
            //g.msglck.Lock()
			if err != nil {
				fmt.Fprintf(os.Stdout, "error to marshal message %v\nerror info: %v\n", msg, err)
				//return  err
			}
            g.msglck.Lock()
            hash:=sha256.Sum256(bs)
	        var b MessageImp
	        //l := len(bs)
	        err = json.Unmarshal(bs, &b)
	        if err != nil {
		        fmt.Fprintf(os.Stdout, " Gossip | Unknom Msg\n")
		        //return
	        }
            if _,ok:=g.msgCache[string(hash[:])]; !ok {
                msg := new(MsgInst)
                msg.hash = string(hash[:])
		        msg.time = time.Now()
                msg.sended=true
		        msg.msg = &b
		        g.msgCache[string(hash[:])] = msg
            }
            g.msglck.Unlock()

			g.lock.Lock()
			for _, v := range g.nodelist {
				if v.state == constdef.Alive {
                    // don't send message to myself
                    if g.addr == v.addr {
                        continue
                    }
					dst := v.GetTcpAddr()
					go g.send(bs,dst)
				}
			}
			g.lock.Unlock()
		}
	}
}

func (g *GossipImp) UpdataMsgCache() {
	tricker := time.NewTicker(10 * time.Second)
	for {
		<-tricker.C
		g.msglck.Lock()
        fmt.Fprintf(os.Stdout, " GOSSIP | Message cache len: %d\n",len(g.msgCache))
		now := time.Now()
		s10, err := time.ParseDuration("10s")
		if err != nil {
			g.msglck.Unlock()
			continue
		}
		for k, v := range g.msgCache {
			end := v.time.Add(s10)
			if end.Before(now) {
				delete(g.msgCache, k)
			}
		}
		g.msglck.Unlock()
	}
}
//


// send message
func (g *GossipImp) resend(m []byte, s string, d string) {
	//fmt.Fprintf(os.Stdout, " Gossip | TCP Send message to %s\n", d)
	//	dst, err := net.ResolveTCPAddr("tcp", d)
	//	if err != nil {
	//		return err
	//	}
	//	src, err := net.ResolveTCPAddr("tcp", s)
	//	if err != nil {
	//		return err
	//	}
    timer:=time.NewTimer(5*time.Second)
    <-timer.C
	var b MessageImp
    var conn net.Conn
    conn=nil
    var err error
    //tricker:=time.NewTicker(1*time.Second)
	        //l := len(bs)
    err = json.Unmarshal(m, &b)
    fmt.Fprintf(os.Stdout, " GOSSIP | Try Re-Send Message %v to remote %v\n",b,d)
	dialer := net.Dialer{
		Timeout: time.Duration(30 * time.Second),
		//LocalAddr: src,
	}
	conn, err = dialer.Dial("tcp", d)
    if conn != nil {
        fmt.Fprintf(os.Stdout, " tcp conn :%v\n", conn)
    } else {
        fmt.Fprintf(os.Stdout, " GOSSIP | Error %v: Fail to dial %v, time: %v\n",err,d,time.Now().String())
        fmt.Fprintf(os.Stdout, "Fail to re-send %v to %s, try send it later, time: %v\n", b,d,err)
        failedmsg:=new(Failsendmsg)
        failedmsg.d=d
        failedmsg.msg = append(failedmsg.msg, m...)
        g.failedsendchan<-failedmsg
        //fmt.Fprintf(os.Stdout, "Fail to send %v to %s, time: %v\n", b,d,err)
        return
    }
	if err != nil {
		fmt.Fprintf(os.Stdout, "Error when dail %s, %v\n", d,err)
        fmt.Fprintf(os.Stdout, "Fail to re-send %v to %s, time: %v\n", b,d,err)
        failedmsg:=new(Failsendmsg)
        failedmsg.d=d
        failedmsg.msg = append(failedmsg.msg, m...)
        g.failedsendchan<-failedmsg
		return
	}
	defer conn.Close() // 关闭连接
	l := len(m)
	//fmt.Printf("data len %d\n", l)
	p := 0
	q := 0
	var senddata []byte
	for {
		if p > l {
			break
		}
		q = p + 1024
		if q > l {
			senddata = m[p:l]
		} else {
			senddata = m[p:q]
		}
		var buf [4]byte
		bufs := buf[:]
		sendlen := len(senddata)
		//fmt.Printf("Len of send data %d\n",sendlen)
		binary.BigEndian.PutUint32(bufs, uint32(sendlen))
		if _, err := conn.Write(bufs); err != nil {
			//fmt.Printf("write failed , err : %v\n", err)
			fmt.Fprintf(os.Stdout, "ERROR | Gossip | Send msg error %v\n", err)
			break
		}
		if _, err = conn.Write(senddata); err != nil {
			//fmt.Printf("write failed , err : %v\n", err)
			fmt.Fprintf(os.Stdout, "ERROR | Gossip | Send msg error %v\n", err)
			break
		}
		p = p + 1024
	}
	//fmt.Fprintf(os.Stdout, " Gossip | TCP Send data to remote addr:%v\n", d)
	return
}

func (g *GossipImp)ReSend() {
    for {
        failmsg:=<-g.failedsendchan
        go g.resend(failmsg.msg,"",failmsg.d)
    }
}


//TBC
//func (g *GossipImp)Broadcast() {
//    //TBC
//    for {
//        select {
//        case msg:=<-g.broadcastchan:
//            //TBC
//            fmt.Fprintf(os.Stdout,"%v\n",msg)
//        }
//
//    }
//}



//func (g *GossipImp) BlockProcess() error {
//    go g.SendBlock(nil)
//    go g.RecvBlock()
//    return nil
//}

func (g *GossipImp) TcpServe() {
//func (g *GossipImp) TcpServe(ctx context.Context) {
	go g.Send()
	go g.Recv()
	//go g.Send(ctx)
	//go g.Recv(ctx)
//	go g.UpdataMsgCache()
//    go g.ReSend()
}
