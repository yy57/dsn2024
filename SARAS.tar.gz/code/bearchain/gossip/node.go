package gossip

import (
	"bearchain/constdef"
	"encoding/binary"
	"fmt"
	"net"
	"time"
)

type Node struct{
    addr string
    udp string
    tcp string
    state string
    heartbeat uint16
    time time.Time
    //lock sync.Mutex
}

func (n *Node) Setaddr(s string) error {
    n.addr=s
    return nil
}

func (n *Node) Settcp(port string) error {
    n.tcp=port
    return nil
}

func (n *Node) Setudp(port string) error {
    n.udp=port
    return nil
}

func (n *Node) SetHeartbeat(hb uint16) error {
    n.heartbeat=hb
    return nil
}

func (n *Node) SetTime(time time.Time) error {
    n.time=time
    return nil
}

func (n *Node) SetState(s string) error {
    switch s {
    case constdef.Alive:
        n.state=s
    case constdef.Suspect:
        n.state=s
    case constdef.Dead:
        n.state=s
    default:
        return fmt.Errorf("Error state %s", s)
    }
    return nil
}

func (n Node) CheckState(time time.Time) (string,error) {
    return "",nil
}

func (n Node) toString() string {
    //return "node listen at: tcp "+n.tcpaddr+" udp "+n.udpaddr+", state:"+n.state+";"
    return "node listen at " +n.addr +", tcp "+n.tcp+" udp "+n.udp+", state:"+n.state+";"
   // return "node:"+n.addr+", state:"+n.state+";"
}

func (node *Node) Nodecheck() error {
//func (node *Node) Nodecheck(udpconn *net.UDPConn) error {
//    buf:=make([]byte,2)
//    n,addr,err:=udpconn.ReadFrom(buf)
//    if err!=nil {
//        return err
//    }
//    heartbeat:=binary.LittleEndian.Uint16(buf)
//    for i,value := range
    return nil
}

func (node Node) GetUdpAddr() string {
    return node.addr+":"+node.udp
}

func (node Node) GetTcpAddr() string {
    return node.addr+":"+node.tcp
}

func (node Node) ping(udpconn *net.UDPConn,addr string) error{
    buf:=make([]byte,2)
    binary.LittleEndian.PutUint16(buf,node.heartbeat)
    laddr,err:=net.ResolveUDPAddr("udp", addr)
    if err!=nil {
        return err
    }
    _,err=udpconn.WriteTo(buf,laddr)
    if err!=nil {
        return err
    }
    return nil
}
