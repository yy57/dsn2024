package gossip

//func (g *GossipImp) SendMessage() error {
//    return nil
//}
//
//func (g *GossipImp) RecvMessage() error {
//    return nil
//}
//
//func (g *GossipImp) MessageProcess() error {
//    go g.SendMessage()
//    go g.RecvMessage()
//    return nil
//}
