package gossip

import (
	"bearchain/config"
	"bearchain/constdef"
	"bearchain/log"
	"errors"
	"fmt"
	"math/big"

	//"math/rand"
	"crypto/rand"
	"net"
	"os"
	"strconv"
	"sync"
	"time"

	"golang.org/x/net/context"
	"golang.org/x/sync/semaphore"
	//"honnef.co/go/tools/config"
)

// ---------------------------------------------------------- GossipImp --------------------------------------------------------
type GossipImp struct {
	//config *Gossip_config
	addr      string
	udpport   string // port udp server listen at
	tcpport   string // port tcp server listen at
	//heartbeat uint16


	caddr      string
	cudpport   string // port udp server listen at
	ctcpport   string // port tcp server listen at
	//mynode *Node
	nodelist map[string]*Node //maintain the node list it connectted
    lock sync.Mutex

	interval uint16 //time to ping other node
	livetime uint16
	deadtime uint16
    uinterval uint16 // interval for update node list
	//    message *Message

	udp *net.UDPConn
	tcp *net.TCPListener

	sendstrategy string
	ratio        float32

    upstream <-chan *MessageImp
	recvchan chan<- *MessageImp
    broadcastchan chan *MessageImp 
    failedsendchan chan *Failsendmsg

    msglck sync.Mutex
    msgCache map[string]*MsgInst

    latency int
    unit string

    sendlck sync.Mutex
    sendlimit int

    readlck sync.Mutex
    readlimit int

    ctx context.Context
    sem *semaphore.Weighted

//    sendlimit chan bool
//    recvlimit chan bool

    Comm *Communication
}


var localGossip *GossipImp

func InitLocalGossip() *GossipImp {
	localGossip = new(GossipImp)
    if localGossip.nodelist==nil {
        localGossip.nodelist=make(map[string]*Node)
    }
    localGossip.msgCache=make(map[string]*MsgInst)
    localGossip.sendlimit=2000
    localGossip.readlimit=2000
    localGossip.ctx=context.Background()
    localGossip.sem=semaphore.NewWeighted(100)

//    localGossip.sendlimit=make(chan bool, 4000)
//    localGossip.recvlimit=make(chan bool, 4000)
	return localGossip
}

func NewGossip() *GossipImp {
    newGossip := new(GossipImp)
    if newGossip.nodelist==nil {
        newGossip.nodelist=make(map[string]*Node)
    }
    newGossip.msgCache=make(map[string]*MsgInst)
    newGossip.sendlimit=2000
    newGossip.readlimit=2000
    newGossip.ctx=context.Background()
    newGossip.sem=semaphore.NewWeighted(100)
    newGossip.Comm=new(Communication)

//    newGossip.sendlimit=make(chan bool, 4000)
//    newGossip.recvlimit=make(chan bool, 4000)
	return newGossip
}

func GetlocalGossip() *GossipImp {
	return localGossip
}

//func GetNewGossip() *GossipImp {
//    g:=new(GossipImp)
//    g.nodelist=make([]Node,constdef.Dc_Size)
//    return g
//}

func (g *GossipImp) SetAddr(str string) error {
    g.addr=str
    return nil
}

func (g *GossipImp) Setudpport(str string) error {
	log := log.GetlocalLog()
	log.Print("set gossip udp server addr at: "+str, constdef.INFO)
	g.udpport = str
	return nil
}

func (g *GossipImp) Settcpport(str string) error {
	log := log.GetlocalLog()
	log.Print("set gossip tcp server addr at: "+str, constdef.INFO)
	g.tcpport = str
	return nil
}

func (g *GossipImp) Initlist(str []config.Nodeaddr) error {
	log := log.GetlocalLog()
	log.Print("Init Node Gossip list", constdef.INFO)
	if g.nodelist != nil {
		log.Error("node list already initiated")
		err := errors.New("node list already initiated")
		return err
	}
	for _, v := range str {
        if g.nodelist==nil {
            return nil
        }
		if _, ok := g.nodelist[v.Addr]; !ok {
			g.nodelist[v.Addr] = &Node{
				addr: v.Addr,
				udp:  v.Udp,
				tcp:  v.Tcp,
			}
		} else {
			log.Error("same node in node list")
			return nil
		}
	}
	return nil
}

func (g *GossipImp) Setlist(str []config.Nodeaddr) error {
	log := log.GetlocalLog()
	log.Print("Set Node Gossip list", constdef.INFO)
	if g.nodelist == nil {
		log.Error("node list not initiated")
		err := errors.New("node list not initiated")
		return err
	}
	for _, v := range str {
        addr:=v.Addr+v.Udp
		if _, ok := g.nodelist[addr]; !ok {
			g.nodelist[addr] = &Node{
				addr: v.Addr,
				udp:  v.Udp,
				tcp:  v.Tcp,
                state: constdef.Alive,
                time: time.Now(),
			}
		} else {
			log.Error("Same node in node list")
		}
	}
	return nil
}

func (g *GossipImp) GetNodeList() map[string]*Node {
	return g.nodelist
}

func (g *GossipImp) SetStrategy(str string, ratio float32) error {
	g.sendstrategy = str
	g.ratio = ratio
	return nil
}

func (g *GossipImp) Set(gconf *config.GossipConfig) error {
	// set Server addr
    addr,udp,tcp:=gconf.GetServer()
    g.addr=addr
    g.udpport=udp
    g.tcpport=tcp
//    g.SetAddr(gconf.Addr)
//	g.Settcpport(gconf.Tcp)
//	g.Setudpport(gconf.Udp)

    //set client addr
    addr,udp,tcp=gconf.GetClient()
    g.caddr=addr
    g.cudpport=udp
    g.ctcpport=tcp
	// set bootstrap
	//g.Initlist(gconf.Bootstrap)
	g.Setlist(gconf.Bootstrap)

	//set ping config
	g.interval = gconf.Interval
	g.livetime = gconf.Livetime
	g.deadtime = gconf.Deadtime
    g.uinterval = gconf.UInterval

	g.SetStrategy(gconf.SendStrategy, gconf.Ratio)

    g.latency=gconf.Latency
    g.unit=gconf.Unit

	return nil
}

func (g *GossipImp) GetList() ([]string, error) {
	l := len(g.nodelist)
	list := make([]string, l)
	i := 0
	for k := range g.nodelist {
		list[i] = g.nodelist[k].toString()
		i = i + 1
	}
	return list, nil
}

func (g *GossipImp) Setudp(udp *net.UDPConn) error {
	g.udp = udp
	return nil
}

func (g *GossipImp) GetUdpAddr() string {
	return g.addr + ":" + g.udpport
}

func (g *GossipImp) GetClientUdpAddr() string {
//    pornt:=rand.Intn(10000)
//    pornt=pornt+30000
//    pornt,err:=rand.Int(rand.Reader,big.NewInt(1000))
//    if err!=nil {
//        fmt.Fprintf(os.Stdout,"Failed to rand\n")
//    }
//    p,err:=strconv.Atoi(pornt.String())
//    if err!=nil {
//        fmt.Fprintf(os.Stdout,"Failed to rand\n")
//    }

//    last:=strings.Split(g.addr,".")
//    l1,er:=strconv.Atoi(last[3]) 
//    if er!=nil {
//        panic("Err")
//    }
//    l2,er:=strconv.Atoi(g.udpport)
//    if er!=nil {
//        panic("Err")
//    }
//    l1=l1+l2
//    rand.Seed(time.Now().UnixNano()+int64(l1))
//    p:=rand.Intn(10000)
//    p=p+30000
	//return g.caddr + ":" + strconv.Itoa(p)
	return g.caddr + ":" + g.udpport
}

func (g *GossipImp) Settcp(tcp *net.TCPListener) error {
	g.tcp = tcp
	return nil
}

func (g *GossipImp) GetTcpAddr() string {
	return g.caddr + ":" + g.ctcpport
}

func (g *GossipImp) GetClientTcpAddr() string {

    pornt,err:=rand.Int(rand.Reader,big.NewInt(20000))
    if err!=nil {
        fmt.Fprintf(os.Stdout,"Failed to rand\n")
    }
    p,err:=strconv.Atoi(pornt.String())
    if err!=nil {
        fmt.Fprintf(os.Stdout,"Failed to rand\n")
    }
    p=p+40000
    //pornt=pornt+
//    p,err:=strconv.Atoi(g.tcpport)
//    //pornt=pornt+p
//    if err!=nil {
//        panic("Err")
//    }

    //p:=rand.Intn(10000)
    //p=p+30000
	return g.addr + ":" + strconv.Itoa(p)
}

func (g *GossipImp) Setchan(upstream <-chan *MessageImp, recv chan<- *MessageImp, resend chan *Failsendmsg) {
    g.upstream=upstream
    g.recvchan=recv
    g.failedsendchan=resend
}

func comparetcpportNode(addr *net.Addr, node *Node) bool {
	if (*addr).String() == node.tcp {
		return true
	} else {
		return false
	}
}
func compareudpportNode(addr *net.Addr, node *Node) bool {
	if (*addr).String() == node.udp {
		return true
	} else {
		return false
	}
}

func (g *GossipImp) Transmit() error {
	return nil
}


func (g *GossipImp) Serve() error {
    go g.SimulatedSend()
	// Membership process
	//go g.Membership()


    //go g.TcpServe(g.ctx)
    //go g.TcpServe()
	// request message

	// Block Process()
	//    go g.BlockProcess()

	// message Process()
	//    go g.MessageProcess()

	return nil
}
