package gossip

import (
	"encoding/json"
	"time"
)

type Message interface{
    ToBytes() ([]byte,error)
    Resolve([]byte) error
    GetDst() string
    Print()
}

type MessageImp struct {
    Bs []byte `json:"bs"`
    Ttype string`json:"ttype"`
    Dst string `json:"dst"`
    Info string `json:"info"`
    TimeStamp string `json:"timestamp"`
}

type MsgInst struct {
    msg *MessageImp
    ip []string
    hash string
    sended bool
    time time.Time
}

//TBC
func (msg *MessageImp) ToBytes() ([]byte,error) {
    return json.Marshal(msg)
}


func (msg *MessageImp) Resolve(bs []byte) error {
    err:=json.Unmarshal(bs,msg)
    if err!=nil {
        return err
    }
    return nil
}

func (msg *MessageImp) Print() {

}

func (msg *MessageImp) GetDst() string {
    return msg.Dst
}
