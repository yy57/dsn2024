package gossip

import "time"

type Gossip_config struct{
    TF uint16
    TC uint16
    interval time.Duration
}
