package gossip

import (
	"bearchain/constdef"
	"bearchain/log"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"strings"
	"time"
)

type Ping struct {
	Heartbeat uint
}

// Flag specify the type of request
// 0: ping for node alive state check
// NOTICE: every Udpmessage can be a ping
// 1: request to a new for its node info, like udpaddr tcp addr
// 2: respoece to a request
// 3: request a block
//
type Udpmessage struct {
	//Flag uint16 `json:"Flag"`
	//Heartbeat uint16 `json:"Heartbeat"`
	Addr    string `json:"Addr"`
	Udpport string `json:"Udpport"`
	Tcpport string `json:"Tcpport"`
	//BlockHeight int `json:"BlockHeight"`
}

func (g *GossipImp) UDPMsg() Udpmessage {
	msg := Udpmessage{
		Addr:    g.addr,
		Udpport: g.udpport,
		Tcpport: g.tcpport,
	}
	return msg
}

func (m Udpmessage) toBytes() ([]byte, error) {
	bs, err := json.Marshal(m)
	return bs, err
}

// ping
// any message can be seen as a ping
//func pingnode(heartbeat uint16, s string, d string) error {
func pingnode(msg Udpmessage, s string, d string) error {
	src, err := net.ResolveUDPAddr("udp", s)
	if err != nil {
		fmt.Fprintf(os.Stdout, "Error | %v\n", err)
		return err
	}
	dst, err := net.ResolveUDPAddr("udp", d)
	if err != nil {
		fmt.Fprintf(os.Stdout, "Error | %v\n", err)
		return err
	}
	conn, err := net.DialUDP("udp", src, dst)
	if err != nil {
		fmt.Printf("error: %v\n", err)
		//fmt.Errorf(err)
		return err
	}
	defer conn.Close()
	//m:=Udpmessage{Flag: 0,Heartbeat: heartbeat}
	//m:=Udpmessage{Flag: "ping"}
	bs, err := msg.toBytes()
	if err != nil {
		fmt.Fprintf(os.Stdout, "Error | %v\n", err)
		return err
	}
	_, err = conn.Write(bs)
	if err != nil {
		fmt.Fprintf(os.Stdout, "Error | %v\n", err)
		return err
	}
	return nil
}

//TBC
func (g *GossipImp) sendPing() error {
	s := g.GetClientUdpAddr()
	msg := g.UDPMsg()
	time := time.NewTicker(time.Duration(g.interval) * time.Second)
	for {
		select {
		case <-time.C:
			g.lock.Lock()
			for _, v := range g.nodelist {
				//v.lock.Lock()
				d := v.GetUdpAddr()
				fmt.Fprintf(os.Stdout, " Gossip | UDP ping node %s\n", d)
				err := pingnode(msg, s, d)
				if err != nil {
					fmt.Fprintf(os.Stdout, "Error | %v\n", err)
					g.lock.Unlock()
					return nil
				}
				//v.lock.Unlock()
			}
			g.lock.Unlock()
		}
		//		return nil
	}
}

//func isNodeExist(addr string,nodelist []Node) (int, bool) {
//    //l :=len(nodelist)
//    for index,val:=range nodelist {
//        if val.udpaddr== addr {
//            return  index,true
//        }
//    }
//    return -1,false
//}

func splitAddr(str string) string {
	s := strings.Split(str, ":")
	return s[0]
}

func splitport(str string) string {
	s := strings.Split(str, ":")
	return s[1]
}

func isNodeExist(addr string, nodelist map[string]*Node) bool {
	//l :=len(nodelist)
	//key:=splitAddr(addr)
	if _, ok := nodelist[addr]; ok {
		return true
	}
	return false
}

func updateNodestate() {

}

func (g *GossipImp) recvPing() error {
	log := log.GetlocalLog()
	var bs [1024]byte
	for {
		n, remote, err := g.udp.ReadFromUDP(bs[:])
		var m Udpmessage
		//fmt.Fprintf(os.Stdout, " Gossip | UDP Recieve ping from a node, %d byte\n", n)
		err = json.Unmarshal(bs[:n], &m)
		if err != nil {
			msg := "unknown udp message from " + remote.String()
			log.Error(msg)
			continue
			//return nil
			//fmt.Errorf("unknown udp message from %s",remote)

		}
		current := time.Now()
		//		if err != nil {
		//			return err
		//		}
		//		if n != 2 {
		//			continue
		//		}
		addr := remote.String()
		fmt.Fprintf(os.Stdout, "Gossip | Recieve ping from node %s\n", addr)
		//recieve ping from exist node
		key := splitAddr(addr)
		//udpport:=splitport(addr)
		g.lock.Lock()
		if isNodeExist(key, g.nodelist) {
			//if _,ok:=g.nodelist[addr]; ok {
			//   hb:= binary.LittleEndian.Uint16(bs)
			//  err=g.nodelist[key].SetHeartbeat(hb)
			//            if err!=nil {
			//                return err
			//            }
			err = g.nodelist[key].SetTime(current)
			if err != nil {
				fmt.Fprintf(os.Stdout, "Error | %v\n", err)
				return err
			}
			err = g.nodelist[key].SetState(constdef.Alive)
			if err != nil {
				fmt.Fprintf(os.Stdout, "Error | %v\n", err)
				return err
			}
		} else {
			//recieve ping from a new node
			// add the new node to node list
			//g.nodelist[addr]=Node{udpaddr:addr,heartbeat: m.Heartbeat}
			//newNode:=Node{udpaddr:addr,heartbeat: m.Heartbeat}
			newNode := Node{
				addr: m.Addr,
				udp:  m.Udpport,
				tcp:  m.Tcpport,
				//heartbeat:
				//m.Heartbeat,
			}
			newNode.SetTime(current)
			newNode.SetState(constdef.Alive)
			g.nodelist[key] = &newNode
			//err=g.RequestNewNode(addr)
		}
		g.lock.Unlock()
	}
}

// Request info about a new node
//func (g *GossipImp) RequestNewNode(udpaddr string) error {
//    s:=g.GetUdpAddr()
//    src,err:=net.ResolveUDPAddr("udp", s)
//    if err!=nil {
//        return err
//    }
//    dst,err:=net.ResolveUDPAddr("udp",udpaddr)
//    if err!=nil {
//        return err
//    }
//    m:=Udpmessage{Flag:1}
//    bs,err:=m.toBytes()
//    conn, err := net.DialUDP("udp",src,dst)
//    if err!=nil {
//        return err
//    }
//    defer conn.Close()
//    if err!=nil {
//        return err
//    }
//    _,err=conn.Write(bs)
//    if err!=nil {
//        return err
//    }
//    return nil
//}

//func (g *GossipImp) ResponeNewNode() error {
//    var bs []byte
//    var m Udpmessage
//    _,remote,err:=g.udp.ReadFromUDP(bs)
//    if err!=nil {
//        return err
//    }
//    err=json.Unmarshal(bs,&m)
//    if err!=nil{
//        return fmt.Errorf("unknown udp message from %s",remote)
//    }
//    current:=time.Now()
//    if err!=nil {
//        return err
//    }
//    udpaddr:=remote.String()
//    addr:=splitAddr(udpaddr)
//    //port:=splitport(udpaddr)
//    //index,ok:=isNodeExist(udpaddr,g.nodelist)
//    //_,ok:=g.nodelist[udpaddr]
//    if m.Flag==1 && isNodeExist(addr, g.nodelist){
//    //if m.Flag==1 && udpaddr==m.Udpaddr && isNodeExist(addr, g.nodelist){
//        resp:=Udpmessage{
//            Flag: 2,
//            Udpport: g.udpport,
//            Tcpport: g.tcpport,
//        }
//
//        src,err:=net.ResolveUDPAddr("udp", g.GetUdpAddr())
//        if err!=nil {
//            return err
//        }
//        conn, err := net.DialUDP("udp",src,remote)
//        if err!=nil {
//            return err
//        }
//        defer conn.Close()
//        bs,err:=json.Marshal(resp)
//        if err!=nil {
//            return err
//        }
//        _,err=conn.Write(bs)
//        if err!=nil {
//            return err
//        }
//        err=g.nodelist[addr].SetTime(current)
//        if err != nil {
//            return err
//        }
//        err=g.nodelist[addr].SetState(constdef.Alive)
//        if err != nil {
//            return err
//        }
//    }
//    return nil
//}

//func (g *GossipImp) ProcessNewNode() error {
//    var bs []byte
//    var m Udpmessage
//    _,remote,err:=g.udp.ReadFromUDP(bs)
//    if err!=nil {
//        return err
//    }
//    err=json.Unmarshal(bs,&m)
//    if err!=nil{
//        return fmt.Errorf("unknown udp message from %s",remote)
//    }
//    current:=time.Now()
//    if err!=nil {
//        return err
//    }
//    udpaddr:=remote.String()
//    addr:=splitAddr(udpaddr)
//    //port:=splitport(udpaddr)
//    ok:=isNodeExist(addr,g.nodelist)
//    //_,ok:=g.nodelist[udpaddr]
//    //if m.Flag==2 && udpaddr==m.Udpaddr && ok{
//    if m.Flag==2 && ok{
//        //udpaddr:=remote.String()
//        err=g.nodelist[addr].Settcp(m.Tcpport)
//        if err != nil {
//            return err
//        }
//        err=g.nodelist[addr].SetTime(current)
//        if err != nil {
//            return err
//        }
//        err=g.nodelist[addr].SetState(constdef.Alive)
//        if err != nil {
//            return err
//        }
//    }
//    return nil
//}

// update node list
func (g *GossipImp) updatelist() error {
	ticker1 := time.NewTicker(time.Duration(g.uinterval) * time.Second)
	for {
		<-ticker1.C
		fmt.Fprintf(os.Stdout, "nodelist: \n")
		current := time.Now()
		g.lock.Lock()
		for k, v := range g.nodelist {
			//fmt.Fprintf(os.Stdout, "check node listen at tcp: %s udp: %s, state: %s, heartbeat: %d, time %v\n", v.GetTcpAddr(), v.GetUdpAddr(), v.state, v.heartbeat, v.time)

			last := v.time
			livetime := last.Add(time.Second * time.Duration(g.livetime))
			deadtime := last.Add(time.Second * time.Duration(g.deadtime))
			if livetime.After(current) {
				g.nodelist[k].SetState(constdef.Alive)
			} else if deadtime.After(current) {
				g.nodelist[k].SetState(constdef.Suspect)
			} else {
				g.nodelist[k].SetState(constdef.Dead)
			}
			//fmt.Fprintf(os.Stdout, "check node listen at tcp: %s udp: %s, state: %s, time %v\n", v.GetTcpAddr(), v.GetUdpAddr(), v.state, v.time.Format("2006.01.02 15:04:05"))
			fmt.Fprintf(os.Stdout, "listen at tcp: %s udp: %s, state: %s, last active time %v\n", g.nodelist[k].GetTcpAddr(), g.nodelist[k].GetUdpAddr(), g.nodelist[k].state, g.nodelist[k].time.Format("2006.01.02 15:04:05"))
		}
		for k, v := range g.nodelist {
			if v.state == constdef.Dead {
				delete(g.nodelist, k)
			}
		}
		g.lock.Unlock()
	}
}

// Membership for maintain node info
func (g *GossipImp) Membership() {
	//go g.sendPing()
	//go g.recvPing()
	//go g.updatelist()
	//return nil
}
