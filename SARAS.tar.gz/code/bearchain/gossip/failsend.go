package gossip

type Failsendmsg struct {
    d string
    msg []byte
}



