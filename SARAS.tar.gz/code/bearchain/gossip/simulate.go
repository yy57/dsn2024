package gossip

import (
	"fmt"
	"math/rand"
	"os"
	"time"
)

type Communication struct{
    ltype string
    latency int
    Index int
    Recvchan chan MessageImp
    SendChan []chan MessageImp

    upstream chan MessageImp
    upstreamactive bool
}

func (g *GossipImp)RandSend(msgs []MessageImp){
    l:=len(msgs)
    if l!=2 {
        fmt.Fprintf(os.Stdout, " Gossip | RandSend | len of message > 2, bias random\n")
    }
    rand.Seed(time.Now().UnixNano())
    for i,ch :=  range g.Comm.SendChan {
        rand.Shuffle(len(msgs),func(i, j int) {msgs[i],msgs[j]=msgs[j],msgs[i]})
        if i!=g.Comm.Index {
            for _,msg:=range msgs {
                go g.ssend(msg,i,ch)
            } 
        }
    }

}

func (g *GossipImp)RecvUpstream(msg MessageImp) {
//    var timer *time.Timer
//    switch g.Comm.ltype{
//    case "Mil":
//        timer=time.NewTimer(time.Duration(g.Comm.latency)*time.Millisecond)
//    case "Sec":
//        timer=time.NewTimer(time.Duration(g.Comm.latency)*time.Second)
//    case "Min":
//        timer=time.NewTimer(time.Duration(g.Comm.latency)*time.Minute)
//    }
//    <-timer.C 
    g.Comm.Recvchan<-msg
    //g.Comm.SetUpstream(upstream, flag)
}

func (Comm *Communication)SetUpstream(upstream chan MessageImp, flag bool) {
    Comm.upstream=upstream
    Comm.upstreamactive=flag
}

func (g *GossipImp)SetUpstream(upstream chan MessageImp,flag bool) {
    g.Comm.SetUpstream(upstream, flag)
}

func (Comm *Communication)SetLatency(ltype string, latency int) {
    Comm.ltype=ltype
    Comm.latency=latency
}

func (g *GossipImp)SetLatency(ltype string, latency int) {
    g.Comm.SetLatency(ltype, latency)
}

func (g *GossipImp)simulatedsend(msg MessageImp) {
    for i,ch :=  range g.Comm.SendChan {
        if i!=g.Comm.Index {
            go g.ssend(msg,i,ch)
        }
    }
}

func (g *GossipImp)ssend( msg MessageImp,index int ,sendchan chan<- MessageImp){
    //var msgtype string
//    switch msg.Ttype {
//    case constdef.QUERY:
//        msgtype="QUERY"
//    case constdef.RESPONE:
//        msgtype="RESPONE"
//    case constdef.NEWPROPOSER:
//        msgtype="NEWPROPOSER"
//    case constdef.BLOCK:
//        msgtype="BLOCK"
//    }
    //fmt.Fprintf(os.Stdout, "index %d | gossip | SimulatedSend | Msg Type %v, Blockhash %v,send message to node %v, its message cache len %d\n",g.Comm.Index,msgtype,msg.Info, index,len(sendchan))
    var timer *time.Timer
    switch g.Comm.ltype{
    case "Mil":
        timer=time.NewTimer(time.Duration(g.Comm.latency)*time.Millisecond)
    case "Sec":
        timer=time.NewTimer(time.Duration(g.Comm.latency)*time.Second)
    case "Min":
        timer=time.NewTimer(time.Duration(g.Comm.latency)*time.Minute)
    }
    //timer:=time.NewTimer(100*time.Millisecond)
    //timer:=time.NewTimer(300*time.Millisecond)
    //timer:=time.NewTimer(3*time.Second)
    <-timer.C 
    sendchan<-msg
    //fmt.Fprintf(os.Stdout, "index %d | gossip | SimulatedSend | send message to node %v, finish send\n",g.Comm.Index, index)
}

func (g *GossipImp)SimulatedSend() {
	for {
		select {
		case msg := <-g.upstream:
            if g.Comm.upstreamactive {
                g.Comm.upstream<-*msg
            }
            g.simulatedsend(*msg)
	    }
    }
}
